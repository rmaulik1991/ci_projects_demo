<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require ("common/Index_Controller.php");

class alerts extends Index_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('alerts_model');
		$this->user_session = $this->session->userdata('user_session');
		is_login();
	}

	public function index() {	
		$data['flash_msg'] = $this->msg_session;
		//$data['branch_list']=$this->alerts_model->selectData(STORE_BRANCH_TABLE,'*');		
		$data['view'] = "index";
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');
	}

	public function sales_update() {	
		$data['flash_msg'] = $this->msg_session;
		//$data['branch_list']=$this->alerts_model->selectData(STORE_BRANCH_TABLE,'*');		
		$data['view'] = "sales_update";
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');
	}

	public function report_listed() {
		$daterange="01/01/1970 - 01/01/2022";
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			if($_POST['daterange']!=''){
			$daterange=$_POST['daterange'];
			}
			else{
			$daterange="01/01/1970 - 01/01/2022";	
			}
		}
		if($_SERVER['REQUEST_METHOD'] == 'GET'){
			if($_GET['daterange']!=NULL){
			$daterange=$_GET['daterange'];
			}
			else{
			$daterange="01/01/1970 - 01/01/2022";	
			}
		}
		$fil_date=explode('-', $daterange);
		$start_date= date('Y-m-d' ,strtotime($fil_date[0]));
		$end_date= date('Y-m-d' ,strtotime($fil_date[1]));
		//date('Y' ,strtotime('2017/11/01');
		$data['data']=$all_list=$this->alerts_model->selectData($start_date,$end_date);
		$data['daterange'] = $daterange;
		$data['view'] = "listed_view";
		if($_SERVER['REQUEST_METHOD'] === 'GET'){
			$this->load->view('alerts/display_alerts', $data);
		} else {	
			//$this->load->view('content', $data);
			echo json_encode($all_list);
		}
		//echo '<pre>';print_r($data);exit();
		//$this->load->view('alerts/display_alerts', $data);
			
	}
	/*public function report_listed() {
		$daterange="01/01/1970 - 01/01/2022";
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			if($_POST['daterange']!=''){
			$daterange=$_POST['daterange'];
			}
			else{
			$daterange="01/01/1970 - 01/01/2022";	
			}
		}
		if($_SERVER['REQUEST_METHOD'] == 'GET'){
			if($_GET['daterange']!=NULL){
			$daterange=$_GET['daterange'];
			}
			else{
			$daterange="01/01/1970 - 01/01/2022";	
			}
		}
		$fil_date=explode('-', $daterange);
		$start_date= date('Y-m-d' ,strtotime($fil_date[0]));
		$end_date= date('Y-m-d' ,strtotime($fil_date[1]));
		//date('Y' ,strtotime('2017/11/01');
		$data['data']=$this->alerts_model->selectData($start_date,$end_date);
		$data['daterange'] = $daterange;
		$data['view'] = "listed_view";
		if($_SERVER['REQUEST_METHOD'] === 'GET'){
			$this->load->view('alerts/display_alerts', $data);
		} else {	
			$this->load->view('content', $data);
		}
		//echo '<pre>';print_r($data);exit();
		//$this->load->view('alerts/display_alerts', $data);
			
	}*/
	public function employee_status(){
		$sel_date=$_POST['sel_date'];
		$sel_date = strtr($sel_date, '/', '-');
		$report_name=$_POST['report_name'];
		if($report_name=='sales'){
		$sel_date1= date('Y-m-d' ,strtotime($sel_date));
		header('Content-Type: application/json');
		$data['emp_list']=$this->alerts_model->selectEmpsales($sel_date1);
		echo json_encode($data);
		}
		if($report_name=='display'){
		$sel_date2= date('Y-m-d' ,strtotime($sel_date));
		header('Content-Type: application/json');
		$data['emp_list']=$this->alerts_model->selectEmpdisplay($sel_date2);
		echo json_encode($data);	
		}
	}
	

}
