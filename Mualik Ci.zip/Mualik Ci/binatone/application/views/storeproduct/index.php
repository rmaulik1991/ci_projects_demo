<section class="content-header">
    <h1>
        <?= translate('STORE_PRODUCT_TITLE') ?>
    </h1>
    <?php
		$this->load->view("template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">
    	<div class="col-md-12">
    		<div class="row">
    			<div class="col-md-3"></div>
			    	<div class="col-md-4">
			<div class="form-group">
                        <?php echo form_label('Store Name:');?>
                        <select class="form-control" name="store_name" id="store_name" onchange="get_branch();">
                            <option value="">Select</option>
                            <?php foreach($store_list as $row){ ?>
                            <option value="<?php echo $row->id; ?>"><?php echo $row->store_name; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
    			<div class="col-md-3"></div>
			    	<div class="col-md-4">
			<div class="form-group">
                        <?php echo form_label('Branch Name:');?>
                        <select class="form-control" name="branch_name" id="branch_name">
                            <option value="">Select</option>
                        </select>
                    </div>
                </div>
            </div>
    		<div id="flash_msg">
			</div>
			<?php //if(accessControl('users','add',$this->user_session['role'])){ ?>
    		<button class="btn btn-default pull-right" id="add_product"><i class="fa fa-plus"></i>&nbsp;<?= translate('STORE_PRODUCT_ADD'); ?></button>
			<?php //} ?>
            <div id="list">
				<div class="box">
					<div class="box-header">
						<h3 class="box-title"><?= translate('STORE_PRODUCT_TITLE') ?></h3>                                    
					</div><!-- /.box-header -->
					<div class="box-body table-responsive">
						<table id="storebranchTable" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>Product name</th>									
									<th>Action</th>
								</tr>
							</thead>
						</table>
					</div><!-- /.box-body -->
				</div><!-- /.box -->
			</div>
    	</div>
    </div>
</section>