<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require ("common/Index_Controller.php");

class category extends Index_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('category_model');
		$this->user_session = $this->session->userdata('user_session');
		is_login();
	}

	public function index() {	
		$where='pcategory_id = 0';
		$data['category'] = $category = $this->category_model->selectData(CATEGORY, '*', $where);
		$data['flash_msg'] = $this->msg_session;		
		$data['view'] = "index";
		//$this->load->view('content', $data);
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');
	}

	public function ajax_list($id,$limit=0) {
		$post = $this->input->post();
		
		$columns = array(
					
			//array( 'db' => 'pcategory_id',  'dt' => 0 ,'field' => 'pcategory_id' ),
			array( 'db' => 'category_name',  'dt' => 0 ,'field' => 'category_name'),
			array( 'db' => 'status','dt'=> 1,'field' => 'status' ),
			array( 'db' => 'id',
			 		 'dt' => 2,
					'formatter' => function( $d, $row ) {
						return '<a href="javascript:void(0);" onclick="delete_category('.$d.')" class="fa fa-trash-o"></a><a href="'.site_url('/category/edit/'.$d).'" class="fa fa-edit" style="padding:5px 10px;"></a>';
					}
			),
		);
		//echo $this->db->last_query(); exit;
		echo json_encode( SSP::simple( $post, CATEGORY, "Id", $columns, array(),"status != 'Inactive' and pcategory_id=".$id."" ));
		exit;
		
	
	
	}

	public function add() {
		$post = $this->input->post();
		if ($post) {					
				
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('<label class="form-error-msg"><i class="fa fa-times-circle-o"></i>', '</label><br/>');
			$this->form_validation->set_rules('category_name', 'Category Name', 'trim');
			$this->form_validation->set_rules('sub_category_name', 'Sub Category Name', 'trim|required');
			$flash_arr=0;
			if ($this->form_validation->run()) {				
					$flash_arr=0;
					$where1='category_name = "'.$post['sub_category_name'].'"';
					$parent_id=($post['category_name'])?$post['category_name']:0;
					$duplicateCheck=$this->category_model->checkDuplicate(CATEGORY, $where1,$parent_id);
					if($duplicateCheck){
						$flash_arr = array('flash_type' => 'error',
											'flash_msg' => 'Category name already exiest.'
										);
						$this->session->set_userdata('msg_session',$flash_arr);
						redirect("category/index");
					}
					else{
						$data=array('pcategory_id'=>$post['category_name']
								,'category_name'=>$post['sub_category_name']
								
						);
						
						$ret = $this->category_model->insertData(CATEGORY, $data);
						
						if ($ret > 0) {						
							$flash_arr = array('flash_type' => 'success',
											'flash_msg' => 'Category added successfully.'
										);
						}else{
							$flash_arr = array('flash_type' => 'error',
											'flash_msg' => 'An error occurred while processing.'
										);
						}
						$this->session->set_userdata('msg_session',$flash_arr);
						redirect("category/index");
						}
					
				}
				$this->session->set_userdata('msg_session',$flash_arr);
			}
			
			$post=(object)$post;
			$data['admin']=array('0'=>$post);
		
		$where='pcategory_id = 0';
		$data['category'] = $category = $this->category_model->selectData(CATEGORY, '*', $where);
		

		$data['flash_msg'] = $this->msg_session;
		$data['view'] = "add_edit";
		$data['current_view'] = "add";
		//$this->load->view('content', $data);
		//$data['user_role'] = $this->user_session['role'];
		$this->load->view('content', $data);
	}
	
	public function edit($id) {
		if ($id == "" || $id <= 0) {
			redirect('category');
		}

		$where = 'id = '.$id;
		$is_error=0;
		$post = $this->input->post();
		
		if ($post) {			
			
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('<label class="form-error-msg"><i class="fa fa-times-circle-o"></i>', '</label><br/>');
			$this->form_validation->set_rules('category_name', 'Category Name', 'trim');
			$this->form_validation->set_rules('sub_category_name', 'Sub Category Name', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			
			if ($this->form_validation->run()) {
				$where1='category_name = "'.$post['sub_category_name'].'"';
				$parent_id=($post['category_name'])?$post['category_name']:0;
					$duplicateCheck=$this->category_model->checkDuplicate(CATEGORY, $where1,$parent_id);
					if($duplicateCheck){
						$flash_arr = array('flash_type' => 'error',
											'flash_msg' => 'Category name already exiest.'
										);
						$this->session->set_userdata('msg_session',$flash_arr);
						redirect("category/index");
					}
					else{				
					$data=array('pcategory_id'=>$post['category_name']
									,'category_name'=>$post['sub_category_name']
									,'status' => $post['status']
									
							);
					
						$ret = $this->category_model->updateData(CATEGORY, $data, $where);

					if ($ret > 0) {
						$flash_arr = array('flash_type' => 'success',
											'flash_msg' => 'Category updated successfully.'
										);
					}else{
						$flash_arr = array('flash_type' => 'error',
											'flash_msg' => 'An error occurred while processing.'
										);
					}
					$this->session->set_userdata('msg_session',$flash_arr);
					redirect("category");
				}
				}
			$this->session->set_userdata('msg_session',$flash_arr);
			}
		
		$data['category'] = $category = $this->category_model->selectData(CATEGORY, '*', $where);
		$where1= 'pcategory_id = 0';
		$data['allcategory'] = $allcategory = $this->category_model->selectData(CATEGORY, '*', $where1);
		if (empty($category)) {
			redirect('category/index');
		}
		$data['flash_msg'] = $this->msg_session;
		$data['view'] = "add_edit";
		$data['current_view'] = "edit";
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');		
	}

	public function delete() {
		$post = $this->input->post();
		$data=array("status"=>"Inactive");

		if ($post) {
			$ret = $this->category_model->updateData(CATEGORY, $data,array('Id' => $post['id'] ));
			//$ret = $this->store_model->deleteData(ADMIN_MASTER, array('Id' => $post['id'] ));
			if ($ret > 0) {
				echo "success";
				exit;
				#echo success_msg_box('User deleted successfully.');;
			}else{
				echo "error";
				exit;
				#echo error_msg_box('An error occurred while processing.');
			}
		}
	}

	

	public function checkduplicatecategory(){
		$post = $this->input->post();
		
		if ($post) {
			$where='category_name = "'.$post['category_name'].'"';
			$parent_id=($post['parent_id'])?$post['parent_id']:0;
			//echo $parent_id;exit;
			//$where1='category_name = "'.$post['category_name'].'"';
			$duplicateCheck=$this->category_model->checkDuplicate(CATEGORY, $where,$parent_id);
			if($duplicateCheck){
			//print_r($category);
			if (isset($duplicateCheck) && !empty($duplicateCheck)) {
				echo 1;
				exit;
				#echo success_msg_box('User deleted successfully.');;
			}else{
				echo 'error';
				exit;
				#echo error_msg_box('An error occurred while processing.');
			}
		}
	}
}
}
