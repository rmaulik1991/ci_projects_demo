<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require ("common/Index_Controller.php");

class brand extends Index_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('brand_model');
		$this->user_session = $this->session->userdata('user_session');
		is_login();
	}

	public function index() {	
		$data['flash_msg'] = $this->msg_session;		
		$data['view'] = "index";
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');
	}

	public function ajax_list($limit=0) {
		$post = $this->input->post();
		$columns = array(
			array( 'db' => 'brand_name', 'dt' => 0 ,'formatter' => function( $d, $row )
					{
						return '<a href="'.site_url('/brand/edit/'.$row['Id']).'" >'.$row['brand_name'].'</a>';
					}),			
			array( 'db' => 'brand_desc',  'dt' => 1 ),
			array( 'db' => 'status','dt'=> 2 ),
			array( 'db' => 'Id',
					'dt' => 3,
					'formatter' => function( $d, $row ) {
						return '<a href="javascript:void(0);" onclick="delete_brand('.$d.')" class="fa fa-trash-o"></a>';
					},
			),
		);
		
		echo json_encode( SSP::simple( $post, BRAND_TABLE, "Id", $columns,array(),"status !='Inactive'") );
		exit;
	}

	public function add() {
		$post = $this->input->post();
		if ($post) {					
			
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('<label class="form-error-msg"><i class="fa fa-times-circle-o"></i>', '</label><br/>');
			$this->form_validation->set_rules('brand_name', 'Brand Name', 'trim|required|min_length[2]');
			$this->form_validation->set_rules('brand_desc', 'Brand Description', 'trim|required|min_length[2]');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			
			if ($this->form_validation->run()) {				
					$flash_arr=0;
					$data=array('brand_name'=>$post['brand_name']
								,'brand_desc'=>$post['brand_desc']
								,'status' => $post['status']
						);
					$ret = $this->brand_model->insertData(BRAND_TABLE, $data);
					
					if ($ret > 0) {						
						$flash_arr = array('flash_type' => 'success',
										'flash_msg' => 'Brand added successfully.'
									);
					}else{
						$flash_arr = array('flash_type' => 'error',
										'flash_msg' => 'An error occurred while processing.'
									);
					}
					$this->session->set_userdata('msg_session',$flash_arr);
					redirect("brand/index");
				}
				$this->session->set_userdata('msg_session',$flash_arr);
			}
			$post=(object)$post;
			$data['admin']=array('0'=>$post);
		
		$data['flash_msg'] = $this->msg_session;
		$data['view'] = "add_edit";
		$data['current_view'] = "add";
		$data['user_role'] = $this->user_session['role'];
		$this->load->view('content', $data);
	}
	
	public function edit($id) {
		if ($id == "" || $id <= 0) {
			redirect('brand');
		}

		$where = 'id = '.$id;
		$is_error=0;
		$post = $this->input->post();
		
		if ($post) {			
			
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('<label class="form-error-msg"><i class="fa fa-times-circle-o"></i>', '</label><br/>');
			$this->form_validation->set_rules('brand_name', 'Brand Name', 'trim|required|min_length[2]');
			$this->form_validation->set_rules('brand_desc', 'Brand Description', 'trim|required|min_length[2]');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			
			if ($this->form_validation->run()) {				
				
				$data=array('brand_name'=>$post['brand_name']
								,'brand_desc'=>$post['brand_desc']
								,'status' => $post['status']
						);
					$ret = $this->brand_model->updateData(BRAND_TABLE, $data, $where);

				if ($ret > 0) {
					$flash_arr = array('flash_type' => 'success',
										'flash_msg' => 'Brand updated successfully.'
									);
				}else{
					$flash_arr = array('flash_type' => 'error',
										'flash_msg' => 'An error occurred while processing.'
									);
				}
				$this->session->set_userdata('msg_session',$flash_arr);
				redirect("brand");
				}
			$this->session->set_userdata('msg_session',$flash_arr);
			}
		
		$data['brand'] = $brand = $this->brand_model->selectData(BRAND_TABLE, '*', $where);
		
		if (empty($brand)) {
			redirect('brand/index');
		}
		$data['flash_msg'] = $this->msg_session;
		$data['view'] = "add_edit";
		$data['current_view'] = "edit";
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');		
	}

	public function delete() {
		$post = $this->input->post();
		$data=array("status"=>"Inactive");

		if ($post) {
			$ret = $this->brand_model->updateData(BRAND_TABLE, $data,array('Id' => $post['id'] ));
			//$ret = $this->brand_model->deleteData(ADMIN_MASTER, array('Id' => $post['id'] ));
			if ($ret > 0) {
				echo "success";
				exit;
				#echo success_msg_box('User deleted successfully.');;
			}else{
				echo "error";
				exit;
				#echo error_msg_box('An error occurred while processing.');
			}
		}
	}
}
