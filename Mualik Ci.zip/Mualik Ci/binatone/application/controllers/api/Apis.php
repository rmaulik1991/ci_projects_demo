<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Apis extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('apis_model');
        error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE);
     
    }

    function index()
    {
        
        //header('Content-Type: application/json');
        $dataPOST = trim(file_get_contents('php://input'));
        
        $requestData = date("Y-m-d H:i:s")."\nRequest params: ".$dataPOST."\n\n";
        $file = DOC_ROOT_APPLICATION_PATH.'\controllers\api\request.log';
        $fp = fopen($file, 'a');
        fwrite($fp, $requestData);
        fclose($fp);
        
        $data=json_decode($dataPOST,true);
        //print_r($data); exit();
        $function_name = $data['nameValuePairs']['function'];
        if(isset($data['nameValuePairs']['data']['nameValuePairs']) && !empty($data['nameValuePairs']['data']['nameValuePairs'])){
            $data=$data['nameValuePairs']['data']['nameValuePairs'];
        }
        
        switch ($function_name) {
            case "user_login":
                echo $this->user_login($data);
                break;
            case "getCategory":
                echo $this->getCategory();
                break;
            case "getProduct":
                echo $this->getProduct($data);
                break;
            case "getBrand":
                echo $this->getBrand();
                break;
            case "insertDisplayStatus":
                echo $this->insertDisplayStatus($data);
                break;
            case "insertSalesStatus":
                echo $this->insertSalesStatus($data);
                break;
            case "getProfile":
                echo $this->getProfile($data);
                break;
            case "insertCompetitorProduct":
                echo $this->insertCompetitorProduct($data);
                break;
            case "insertAttendance":
                echo $this->insertAttendance($data);
                break;
            case "getProductDetails":
                echo $this->getProductDetails($data);
                break;
            case "forgotpassword":
                echo $this->forgotpassword($data);
                break;
            case "tallyclientlist":
                echo $this->tallyclientlist($data);
                break;
            case "checkqtyavailability":
                echo $this->checkqtyavailability($data);
                break;
            case "placeorder":
                echo $this->placeorder($data);
                break;
            case "changepassword":
                echo $this->changepassword($data);
                break;
            default:
                echo $this->error_handle();
                break;
        }
        exit;
    }

    public function user_login($data){
        $this->load->model('apis_model');
        $user=$this->apis_model->api_login($data['identity'],$data['password']);
        
        if($user == FALSE){
            $ResponseData = array("code" => 402,'message'=>"Invalid UserName or Password",'status'=>'error');
            $this->responseFun($ResponseData);   
        }else{
            
            $ResponseData = array("code" => 100,'message'=>"User logged in successfully",'status'=>'success','data'=>$user);
            $this->responseFun($ResponseData);
        }
        exit;
    }

    public function getCategory(){
       
       
        $this->load->model('apis_model');
       
        $category=$this->apis_model->getCategory();
        
        if($category == FALSE){
            $ResponseData = array("code" => 402,'message'=>"No category available",'status'=>'error');
            $this->responseFun($ResponseData);  
        }else{
            $ResponseData = array("code" => 100,'message'=>"Category fetched successfully",'status'=>'success','data'=>$category);
            $this->responseFun($ResponseData);           
        }
        exit;
    }    

    public function getProduct($data){
       
       // print_r($data);exit;
        $this->load->model('apis_model');
        if(!isset($data['user_id']) && empty($data['user_id'])){
            $ResponseData = array("code" => 402,'message'=>"invalid parameter",'status'=>'error');
            $this->responseFun($ResponseData);  
            exit;
        }
        $product=$this->apis_model->getProduct($data['user_id']);
        
        if($product == FALSE){
            $ResponseData = array("code" => 402,'message'=>"No product available ",'status'=>'error');
            $this->responseFun($ResponseData);  
        }else{
            
            $ResponseData = array("code" => 100,'message'=>"Product fetched successfully",'status'=>'success','data'=>$product);
            $this->responseFun($ResponseData);           
        }
        exit;
    }   

    public function getBrand(){
       
       
        $this->load->model('apis_model');
       
        $brand=$this->apis_model->getBrand();
        
        if($brand == FALSE){
            $ResponseData = array("code" => 402,'message'=>"No brand available",'status'=>'error');
            $this->responseFun($ResponseData);  
        }else{
            $ResponseData = array("code" => 100,'message'=>"Brand fetched successfully",'status'=>'success','data'=>$brand);
            $this->responseFun($ResponseData);           
        }
        exit;
    }    

    public function insertDisplayStatus($data){
       
       
        $this->load->model('apis_model');
       
        if(!isset($data) && empty($data)){
            $ResponseData = array("code" => 402,'message'=>"invalid parameter",'status'=>'error');
            $this->responseFun($ResponseData);  
            exit;
        }
        
        $insert=$this->apis_model->insertDisplayStatus($data);
        
        if($insert == FALSE){
            $ResponseData = array("code" => 402,'message'=>"No data inserted",'status'=>'error');
            $this->responseFun($ResponseData);  
        }else{
            $ResponseData = array("code" => 100,'message'=>"Display status insert successfully",'status'=>'success');
            $this->responseFun($ResponseData);           
        }
        exit;
    }

    public function insertSalesStatus($data){
       
       
        $this->load->model('apis_model');
       
        if(!isset($data) && empty($data)){
            $ResponseData = array("code" => 402,'message'=>"invalid parameter",'status'=>'error');
            $this->responseFun($ResponseData);  
            exit;
        }
        
        $insert=$this->apis_model->insertSalesStatus($data);
        
        if($insert == FALSE){
            $ResponseData = array("code" => 402,'message'=>"No data inserted or update on daily sales tracker",'status'=>'error');
            $this->responseFun($ResponseData);  
        }else{
            $ResponseData = array("code" => 100,'message'=>"Sales recorded",'status'=>'success');
            $this->responseFun($ResponseData);           
        }
        exit;
    }

    public function getProfile($data){
       
       
        $this->load->model('apis_model');
        $profile=$this->apis_model->getProfile($data['user_id']);
        
        if($profile == FALSE){
            $ResponseData = array("code" => 402,'message'=>"No data found",'status'=>'error');
            $this->responseFun($ResponseData);  
        }else{
            $ResponseData = array("code" => 100,'message'=>"Profile fetched successfully",'status'=>'success','data'=>$profile);
            $this->responseFun($ResponseData);           
        }
        exit;
    }    


// Insert Compititor Product Detail 

    public function insertCompetitorProduct(){
        $user_id=$this->input->post('user_id');
        $is_own_product=$this->input->post('is_own_product');
        $description=$this->input->post('description');
        $product_id=$this->input->post('product_id');
        $data=array('user_id'=>$user_id,'is_own_product'=>$is_own_product,'description'=>$description,'product_id'=>$product_id);
        $this->load->model('apis_model');
        if(!isset($user_id) && empty($user_id) && !isset($is_own_product) && empty($is_own_product) && !isset($description) && empty($description) && !isset($_FILES['file']['name']) && empty($_FILES['file']['name'])){
            $ResponseData = array("code" => 402,'message'=>"invalid parameter",'status'=>'error');
            $this->responseFun($ResponseData);  
            exit;
        }
        if(isset($_FILES['file']['name']) && !empty($_FILES['file']['name'])){
            $name3=$_FILES['file']['name'];
            $name3=explode('.',$_FILES['file']['name']);
            $_FILES['file']['name']='com_pro_'.time().'.'.$name3[1];
        }
        $config['upload_path'] = './public/uploads/comproduct';
        $config['allowed_types'] = '*'; 
        $this->load->library('upload', $config);                    

        if(isset($_FILES['file']) && $_FILES['file'] != ''){                      
            if ( ! $this->upload->do_upload('file'))
            {
                $error = array('error' => $this->upload->display_errors());
                $ResponseData = array("code" => 402,'message'=>"invalid file",'status'=>'error');
                $this->responseFun($ResponseData);  
                exit;
            }
            else
            {
                $upload_data =  $this->upload->data();
                //$this->responseFun($data);                  
            }                           
        }
        if(isset($upload_data) && !empty($upload_data)){
        $insert=$this->apis_model->insertCompetitorProduct($data,$upload_data['file_name']);
        }
        if($insert == FALSE){
            $ResponseData = array("code" => 402,'message'=>"No data inserted on competitor product",'status'=>'error');
            $this->responseFun($ResponseData);  
        }else{
            $ResponseData = array("code" => 100,'message'=>"Competitor Product recorded",'status'=>'success');
            $this->responseFun($ResponseData);           
        }
    }

    // Insert Product Display Detail 

    public function insertProductDisplay(){
        $user_id=$this->input->post('user_id');
        $is_own_product=$this->input->post('is_own_product');
        $description=$this->input->post('description');
        $product_id=$this->input->post('product_id');
        $data=array('user_id'=>$user_id,'is_own_product'=>$is_own_product,'description'=>$description,'product_id'=>$product_id);
        $this->load->model('apis_model');
        if(!isset($user_id) && empty($user_id) && !isset($is_own_product) && empty($is_own_product) && !isset($description) && empty($description) && !isset($_FILES['file']['name']) && empty($_FILES['file']['name'])){
            $ResponseData = array("code" => 402,'message'=>"invalid parameter",'status'=>'error');
            $this->responseFun($ResponseData);  
            exit;
        }
        if(isset($_FILES['file']['name']) && !empty($_FILES['file']['name'])){
            $name3=$_FILES['file']['name'];
            $name3=explode('.',$_FILES['file']['name']);
            $_FILES['file']['name']='com_pro_'.time().'.'.$name3[1];
        }
        $config['upload_path'] = './public/uploads/display_product';
        $config['allowed_types'] = '*'; 
        $this->load->library('upload', $config);                    

        if(isset($_FILES['file']) && $_FILES['file'] != ''){                      
            if ( ! $this->upload->do_upload('file'))
            {
                $error = array('error' => $this->upload->display_errors());
                $ResponseData = array("code" => 402,'message'=>"invalid file",'status'=>'error');
                $this->responseFun($ResponseData);  
                exit;
            }
            else
            {
                $upload_data =  $this->upload->data();
                //$this->responseFun($data);                  
            }                           
        }
        if(isset($upload_data) && !empty($upload_data)){
        $insert=$this->apis_model->insertProductDisplay($data,$upload_data['file_name']);
        }
        if($insert == FALSE){
            $ResponseData = array("code" => 402,'message'=>"No data inserted on competitor product",'status'=>'error');
            $this->responseFun($ResponseData);  
        }else{
            $ResponseData = array("code" => 100,'message'=>"Display Product recorded",'status'=>'success');
            $this->responseFun($ResponseData);           
        }
    }

    public function insertAttendance($data){
       
       
        $this->load->model('apis_model');
       
        if(!isset($data) && empty($data)){
            $ResponseData = array("code" => 402,'message'=>"invalid parameter",'status'=>'error');
            $this->responseFun($ResponseData);  
            exit;
        }
        
        $insert=$this->apis_model->insertAttendance($data);
        
        if($insert == FALSE){
            $ResponseData = array("code" => 402,'message'=>"No data inserted or update on daily sales tracker",'status'=>'error');
            $this->responseFun($ResponseData);  
        }else{
            if($data['status']=='IN'){
            $ResponseData = array("code" => 100,'message'=>"You have Pinch-In",'status'=>'success');
            $this->responseFun($ResponseData);
            }
            if($data['status']=='OUT'){
            $ResponseData = array("code" => 100,'message'=>"You have Pinch-Out",'status'=>'success');
            $this->responseFun($ResponseData);
            }            
        }
        exit;
    }

    public function getProductDetails($data){
       
       
        $this->load->model('apis_model');
        $product_details=$this->apis_model->getProductDetails($data);
        if($product_details == FALSE || $product_details[0]->product_desc==''){
            $ResponseData = array("code" => 402,'message'=>"No data found",'status'=>'error');
            $this->responseFun($ResponseData);  
        }else{
            $ResponseData = array("code" => 100,'message'=>"Product Details fetched successfully",'status'=>'success','data'=>$product_details[0]->product_desc);
            $this->responseFun($ResponseData);           
        }
        exit;
    }

    public function changepassword($data){
       
       
        $this->load->model('apis_model');
        $change_pwd=$this->apis_model->changepassword($data);
        if($change_pwd == FALSE ){
            $ResponseData = array("code" => 402,'message'=>"Invalid old credential",'status'=>'error');
            $this->responseFun($ResponseData);  
        }else{
            $ResponseData = array("code" => 100,'message'=>"Password updated successfully",'status'=>'success');
            $this->responseFun($ResponseData);           
        }
        exit;
    }

    public function forgotpassword($data)
    {   $this->load->model('adminmaster_model');
        if(!isset($data) && empty($data)){
            $ResponseData = array("code" => 402,'message'=>"invalid parameter",'status'=>'error');
            $this->responseFun($ResponseData);  
            exit;
        }

        $data1 = '';
        if ($data['email']) {
            $error = array();
            $e_flag=0;
            if(!valid_email(trim($data['email'])) && trim($data['email']) == ''){
                $error['email'] = 'Please enter email.';
                $e_flag=1;
            }

            if ($e_flag == 0) {
                $where = array('email' => trim($data['email']));
                $user = $this->adminmaster_model->selectData(EMPLOYEE, '*', $where);
                if (count($user) > 0) {

                    $newpassword = random_string('alnum', 8);
                    $data1 = array('password' => sha1($newpassword));
                    $userUpdate = $this->adminmaster_model->updateData(EMPLOYEE,$data1,$where);

                    $login_details = array('username' => $user[0]->username,'password' => $newpassword);
                    $emailTpl = $this->get_forgotpassword_tpl($login_details);
                    $ret = sendEmail($user[0]->email, SUBJECT_LOGIN_INFO, $emailTpl);
                    if ($ret) {
                        $ResponseData = array("code" => 100,'message'=>"Login details sent successfully",'status'=>'success');
                        $this->responseFun($ResponseData);
                        exit;
                    }else{
                        $ResponseData = array("code" => 402,'message'=>"An error occurred while processing",'status'=>'error');
                        $this->responseFun($ResponseData);  
                        exit;
                    }
                    $data1['flash_msg'] = $flash_arr;
                }else{
                    $ResponseData = array("code" => 402,'message'=>"Invalid email address",'status'=>'error');
                    $this->responseFun($ResponseData);  
                    exit;
                }
            }
        }
    }


    public function get_forgotpassword_tpl($details)
    {
        $html = '<p>Your login details are: </p>
                <p>
                    Username: '.$details['username'].'<br/>
                    Password: '.$details['password'].'
                </p>
                <p>
                    Thank you
                </p>
                ';

        return $html;
    }

    public function tallyclientlist(){
       
        $sqlQuery1 = "SELECT Ledger.`\$Name`  FROM 'PAREX.TECH'.`TallyUser`.Ledger  WHERE Ledger.`\$_PrimaryGroup` = 'Sundry Debtors'";
        $LedgerArray = $this->fetch_data_ODBC('',$sqlQuery1);
        $clientlist=array();
        foreach ($LedgerArray as $key => $value) {
            $clientlist[]=$value['Ledger.`$Name`'];
        }
       
        
        if(empty($clientlist)){
            $ResponseData = array("code" => 402,'message'=>"No clients available",'status'=>'error');
            $this->responseFun($ResponseData);  
        }else{
            $ResponseData = array("code" => 100,'message'=>"Clientlist fetched successfully",'status'=>'success','data'=>$clientlist);
            $this->responseFun($ResponseData);           
        }
        exit;
    }

    public function checkqtyavailability($data){
        $this->load->model('apis_model');
        $avail_data=array();
        foreach ($data['product'] as $key => $value) {
            $order_insert=array("user_id"=>$data['user_id'],"client_name"=>$data['client_name'],"product_id"=>$value['product_id'],"product_name"=>$value['name'],"qty"=>$value['qty']);
            $ret=$this->apis_model->insert_order($order_insert);

            if($ret>0){
            $sqlQuery = "SELECT StockItem.`\$Parent`, StockItem.`\$Name`, StockItem.`\$BaseUnits`, StockItem.`\$OpeningBalance`, StockItem.`\$_InwardQuantity`, StockItem.`\$_OutwardQuantity`, StockItem.`\$_ClosingBalance` FROM 'PAREX.TECH'.`TallyUser`.StockItem WHERE StockItem.`\$Name` = '".$value['name']."'";
                $LedgerArray = $this->fetch_data_ODBC('',$sqlQuery);
                if($LedgerArray[0]['StockItem.`$_ClosingBalance`']>0){
                   //$avail_data[$value['name']]="Available";
                    $avail_data[]=array('product_name'=>$value['name'],'available'=>$LedgerArray[0]['StockItem.`$_ClosingBalance`']);
                }else{
                   // $avail_data[$value['name']]="Not Available";
                    $avail_data[]=array('product_name'=>$value['name'],'available'=>'Currently Not available');
                }

            }
        }
        if(empty($avail_data)){
            $ResponseData = array("code" => 402,'message'=>"No clients available",'status'=>'error');
            $this->responseFun($ResponseData);  
        }else{
            $ResponseData = array("code" => 100,'message'=>"Record fetched successfully",'status'=>'success','data'=>$avail_data);
            $this->responseFun($ResponseData);           
        }
        exit;
    }

    public function placeorder($data){
        $this->load->model('apis_model');
        $avail_data=array();
        $xml_list="";
        $main_debit=0;
        foreach ($data['product'] as $key => $value) {

        $sqlQuery = "SELECT StockItem.`\$Parent`, StockItem.`\$Name`, StockItem.`\$BaseUnits`, StockItem.`\$OpeningBalance`, StockItem.`\$_InwardQuantity`, StockItem.`\$_OutwardQuantity`, StockItem.`\$_ClosingBalance` FROM 'PAREX.TECH'.`TallyUser`.StockItem WHERE StockItem.`\$Name` = '".$value['name']."'";
            $LedgerArray = $this->fetch_data_ODBC('',$sqlQuery);
            if($LedgerArray[0]['StockItem.`$_ClosingBalance`']>$value['qty']){
                $xml_list=$xml_list."<ALLINVENTORYENTRIES.LIST><STOCKITEMNAME>".$value['name']."</STOCKITEMNAME><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><ISLASTDEEMEDPOSITIVE>No</ISLASTDEEMEDPOSITIVE><ISAUTONEGATE>No</ISAUTONEGATE><ISCUSTOMSCLEARANCE>No</ISCUSTOMSCLEARANCE><ISTRACKCOMPONENT>No</ISTRACKCOMPONENT><ISTRACKPRODUCTION>No</ISTRACKPRODUCTION><ISPRIMARYITEM>No</ISPRIMARYITEM><ISSCRAP>No</ISSCRAP><RATE>".$value['rate']."</RATE><AMOUNT>".$value['rate']*$value['qty']."</AMOUNT><ACTUALQTY>".$value['qty']."</ACTUALQTY><BILLEDQTY>".$value['qty']."</BILLEDQTY><BATCHALLOCATIONS.LIST><MFDON>20170301</MFDON><GODOWNNAME>Main Location</GODOWNNAME><BATCHNAME>Primary Batch</BATCHNAME><DESTINATIONGODOWNNAME>Main Location</DESTINATIONGODOWNNAME><INDENTNO/><DYNAMICCSTISCLEARED>No</DYNAMICCSTISCLEARED><AMOUNT>".$value['rate']*$value['qty']."</AMOUNT><ACTUALQTY>".$value['qty']."</ACTUALQTY><BILLEDQTY>".$value['qty']."</BILLEDQTY><ORDERDUEDATE>2 Days</ORDERDUEDATE></BATCHALLOCATIONS.LIST><ACCOUNTINGALLOCATIONS.LIST><LEDGERNAME>Sales Register</LEDGERNAME><GSTCLASS/><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><LEDGERFROMITEM>No</LEDGERFROMITEM><REMOVEZEROENTRIES>No</REMOVEZEROENTRIES><ISPARTYLEDGER>No</ISPARTYLEDGER><ISLASTDEEMEDPOSITIVE>No</ISLASTDEEMEDPOSITIVE><AMOUNT>".$value['rate']*$value['qty']."</AMOUNT></ACCOUNTINGALLOCATIONS.LIST></ALLINVENTORYENTRIES.LIST>";
                $avail_data[]=array('product_name'=>$value['name'],'Orderinfo'=>"Order Placed successfull",'Quentity'=>$value['qty']);
                $main_debit=$main_debit+($value['rate']*$value['qty']);

            }else{
                $avail_data[]=array('product_name'=>$value['name'],'Orderinfo'=>"Order failed");
            }
        }
        $vat=($main_debit*4)/100; 
        $add_tax=($main_debit*1)/100;
        $main_debit=$main_debit+$vat+$add_tax;
        $xml_order="<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA><REQUESTDESC><REPORTNAME>All Masters</REPORTNAME><STATICVARIABLES>
                    <SVCURRENTCOMPANY>PAREX.TECH</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC><REQUESTDATA><TALLYMESSAGE xmlns:UDF='TallyUDF'><VOUCHER VCHTYPE='Sales' ACTION='Create'><DATE>20170301</DATE><CLASSNAME>Sales  @ 4% + 1%</CLASSNAME><PARTYNAME>Aadesh Stationers</PARTYNAME><VOUCHERTYPENAME>Sales</VOUCHERTYPENAME><ISINVOICE>Yes</ISINVOICE><PARTYLEDGERNAME>Sales Register</PARTYLEDGERNAME><BASICBASEPARTYNAME>Aadesh Stationers</BASICBASEPARTYNAME><FBTPAYMENTTYPE>Default</FBTPAYMENTTYPE><BASICBUYERNAME>Aadesh Stationers</BASICBUYERNAME><LEDGERENTRIES.LIST><LEDGERNAME>".$data['client_name']."</LEDGERNAME><ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE><LEDGERFROMITEM>No</LEDGERFROMITEM><REMOVEZEROENTRIES>No</REMOVEZEROENTRIES><ISPARTYLEDGER>Yes</ISPARTYLEDGER><ISLASTDEEMEDPOSITIVE>Yes</ISLASTDEEMEDPOSITIVE><AMOUNT>-".$main_debit."</AMOUNT></LEDGERENTRIES.LIST><LEDGERENTRIES.LIST><ROUNDTYPE/><LEDGERNAME>VAT</LEDGERNAME><METHODTYPE>On VAT Rate</METHODTYPE><CLASSRATE>4%</CLASSRATE><GSTCLASS/><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><LEDGERFROMITEM>No</LEDGERFROMITEM><REMOVEZEROENTRIES>Yes</REMOVEZEROENTRIES><ISPARTYLEDGER>No</ISPARTYLEDGER><ISLASTDEEMEDPOSITIVE>No</ISLASTDEEMEDPOSITIVE><RATEOFADDLVAT> 1</RATEOFADDLVAT><AMOUNT>".$vat."</AMOUNT></LEDGERENTRIES.LIST><LEDGERENTRIES.LIST><ROUNDTYPE/><LEDGERNAME>Addl.Tax</LEDGERNAME><METHODTYPE>Additional Tax</METHODTYPE><CLASSRATE>1%</CLASSRATE><GSTCLASS/><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><LEDGERFROMITEM>No</LEDGERFROMITEM><REMOVEZEROENTRIES>Yes</REMOVEZEROENTRIES><ISPARTYLEDGER>No</ISPARTYLEDGER><ISLASTDEEMEDPOSITIVE>No</ISLASTDEEMEDPOSITIVE><AMOUNT>".$add_tax."</AMOUNT></LEDGERENTRIES.LIST>".$xml_list."</VOUCHER></TALLYMESSAGE></REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>";
                    $xml_ret=$this->curlcommon($xml_order);         
        if($xml_ret['CREATED']!=1){
            $ResponseData = array("code" => 402,'message'=>"Tally server not running or Quantity not available",'status'=>'error');
            $this->responseFun($ResponseData);  
        }else{
            $ResponseData = array("code" => 100,'message'=>"Order placed successfully",'status'=>'success','data'=>$avail_data);
            $this->responseFun($ResponseData);           
        }
        exit;
    } 

    function error_handle(){
        $ResponseData = array("code" => 402,'message'=>"No function name provided ",'status'=>'error');
        $this->responseFun($ResponseData);   
        exit;
    }


    public function responseFun($ResponseData)
    {
        $responseData = date("Y-m-d H:i:s")."\nResponse: "."\n".json_encode($ResponseData)."\n\n";
        $file = DOC_ROOT_APPLICATION_PATH.'\controllers\api\response.log';
        $fp = fopen($file, 'a');
        fwrite($fp, $responseData);
        fclose($fp);
        echo json_encode($ResponseData);
    }

    function fetch_data_ODBC($tallyIP = 'localhost',$sqlQuery = '')
    {
     $connect = odbc_connect("PORT=9000;DRIVER=Tally ODBC Driver;SERVER={(".$tallyIP.")}", "", "") or die('1');
     //echo $connect;
         $result = odbc_exec($connect, $sqlQuery);
         $resultData = array();
         if($result){
         while($myRow = odbc_fetch_array( $result ))
      { 
          $resultData[] = $myRow; 
      }
    }
    return $resultData;
    }

    function curlcommon($req_pera)
    {
        $server = "http://localhost:9000";
        $headers = array( "Content-type: text/xml"  ,"Connection: close" );

        $ch = curl_init(); 
        curl_setopt($ch, CURLOPT_URL,$server);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $req_pera);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $server_output = curl_exec($ch);
        //echo "<pre>";
        //print_r(json_decode(json_encode(simplexml_load_string($server_output)), true));
        $server_outputArray= json_decode(json_encode(simplexml_load_string($server_output)), true);
        return $server_outputArray;
    }

}
