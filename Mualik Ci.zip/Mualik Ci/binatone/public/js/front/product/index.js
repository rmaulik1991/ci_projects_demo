var oTable;
$(document).ready(function() {

	oTable = $('#productTable').dataTable( {
		"processing": true,
		"serverSide": true,
		"ajax": {
			"url": base_path()+'product/ajax_list/',
			"type": "POST"
		},
		aoColumnDefs: [
		  {
			 bSortable: false,
			 aTargets: [ -1 ]
		  }
		]
	} );

	
	$('#productFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		 fields: {
            product_name: {
                 message: 'The Product Name is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Product Name is required and cannot be empty'
                    },
                    stringLength: {
                        min: 2,
                        max: 500,
                        message: 'The Product Name must be more than 2 and less than 30 characters long'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The firstname can only consist of alphabetical'
                    // }
                }
            },
            category: {
                 message: 'The category is not valid',
                validators: {
                    notEmpty: {
                        message: 'The category is required and cannot be empty'
                    },
                    stringLength: {
                        min: 1,
                        max: 30,
                        message: 'The category must be more than 2 and less than 30 characters long'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The firstname can only consist of alphabetical'
                    // }
                }
            },
            brand_name: {
                 message: 'The Brand Name is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Brand Name is required and cannot be empty'
                    },
                    stringLength: {
                        min: 1,
                        max: 30,
                        message: 'The Brand Name must be more than 2 and less than 30 characters long'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The firstname can only consist of alphabetical'
                    // }
                }
            },
            product_desc: {
                 message: 'The Product Description is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Product Description is required and cannot be empty'
                    },
                    stringLength: {
                        min: 2,
                        max: 200,
                        message: 'The Product Description must be more than 2 and less than 200 characters long'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The lastname can only consist of alphabetical'
                    // }
                }
            },
            product_code: {
                 message: 'The Product code is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Product code is required and cannot be empty'
                    },
                    stringLength: {
                        min: 2,
                        max: 200,
                        message: 'The Product code must be more than 2 and less than 200 characters long'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The lastname can only consist of alphabetical'
                    // }
                }
            },
            status: {
                message: 'The status is not valid',
                validators: {
                    notEmpty: {
                        message: 'The status is required and cannot be empty'
                    }
                }
            }
		 }
    });
} );

function delete_product(del_id) {
bootbox.confirm("Are you sure to delete product?", function(result) {
	if(result){
	startLoading();
	$.ajax({
		type: 'post',
		url: base_path()+'product/delete',
		data: 'id='+del_id,
		success: function (data) {
			if (data == "success") {
				oTable.fnClearTable(0);
				oTable.fnDraw();
				$("#flash_msg").html(success_msg_box ('Store deleted successfully.'));
			}else{
				$("#flash_msg").html(error_msg_box ('An error occurred while processing.'));
			}
			stopLoading();
		}
	});
	}
	});
}

function get_subcat(subcat_id=null) {
    var cat_id=$('#category').val();
    $('#sub_category')
    .find('option')
    .remove()
    .end()
    .append('<option value="">Select</option>');
    $('#subcat_div').hide();
    $.ajax({
        type: 'post',
        url: base_path()+'product/get_subcat/'+cat_id,
        success: function (data) {
            if(data['category_list']!=''){
                $('#subcat_div').show();
            var i=0;
             $.each(data['category_list'], function(id, category_name) {
                $('#sub_category').append("<option value='" +data['category_list'][i]['id'] + "'>" + data['category_list'][i]['category_name'] + "</option>");
                i++;
            });
             if(subcat_id!=null){
                $("#sub_category").val(subcat_id);
             }
         }
         else{
          $('#subcat_div').hide();  
         }
        }
    });
    
} 