<?php 
//load our new PHPExcel library
$this->load->library('excel');
//activate worksheet number 1
$this->excel->setActiveSheetIndex(0);
//name the worksheet
$this->excel->getActiveSheet()->setTitle('Not Listed Product');
//set cell A1 content with some text
$this->excel->getActiveSheet()->setCellValue('A2','Store Name');
$this->excel->getActiveSheet()->setCellValue('B2','Branch Name');
$this->excel->getActiveSheet()->setCellValue('C2','Product');
$this->excel->getActiveSheet()->setCellValue('D2','Date');
$this->excel->getActiveSheet()->setCellValue('E2','Status');
$this->excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
$this->excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
$this->excel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
$this->excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
$this->excel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
$this->excel->getActiveSheet()->getStyle('A2:E2')->getFont()->setBold(true);
//$this->excel->getActiveSheet()->fromArray($data, NULL, 'C6');
//echo '<pre>';print_r($data);
$flag1='';
$c_product=3;
$filldata=array();
foreach ($data as $key => $value) {
	$this->excel->getActiveSheet()->setCellValue('A'.$c_product,$key);
	foreach ($value as $key1 => $value1) {
		if($flag1!=$key1){
		$this->excel->getActiveSheet()->setCellValue('B'.$c_product,$key1);	
	}
	
		foreach ($value1 as $key2 => $value2) {
			//echo '<pre>';print_r($value2);
			$this->excel->getActiveSheet()->fromArray($value2, NULL, 'C'.$c_product);
			$c_product++;
		}
	
	
	}
}

//exit();
$filename='Not Listed Report.xlsx'; //save our workbook as this file name
	ob_end_clean();		
 header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename='.$filename.'');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($this->excel,'Excel2007');

$objWriter->save('php://output');
?>