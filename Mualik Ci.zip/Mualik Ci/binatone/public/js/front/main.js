function changeLanguage(lang)
{
	var str =window.location.href;
	var url=str.split("?");
	window.location.href=url[0]+"?lang="+lang;
}

function closemessage()
{
	jQuery('#msg_contant').html('');
	$('#flash_msg').removeClass();
}

function startLoading(){
  $.blockUI({
		message: 'Please Wait...',	
		css: { 
            border: 'none', 
            padding: '20px',
            backgroundColor: '#000', 
            '-webkit-border-radius': '10px', 
            '-moz-border-radius': '10px', 
            opacity: .5, 
            color: '#fff' 
        } });
}
function stopLoading(){
  $.unblockUI();
}

$(document).ready(function(){
	$(window).scroll(function(){
	  var sticky = $('.content-header'),
		  scroll = $(window).scrollTop();

	  if (scroll >= 100) sticky.addClass('fixed');
	  else sticky.removeClass('fixed');
	});
});