<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require ("common/Index_Controller.php");

class Reports extends Index_Controller {
	function __construct() {
		parent::__construct();
		$this->load->model('report_model');
		$this->load->model('storeemp_model');
		$this->load->library('excel');
		is_login();
	}
	public function index() 
	{
		$data['store_list']=$this->storeemp_model->selectData(STORE,'*');
		$data['view'] = "index"; 
		$this->load->view('content',$data); 
	}

	public function get_branch($id){
		header('Content-Type: application/json');
		$where = 'sts_store_id = '.$id;
		$data['branch_list']=$this->storeemp_model->selectData(STORE_BRANCH_TABLE,'*',$where);
		echo json_encode($data);
	}

	public function generate_report(){
		$branch_name=$this->input->post('branch_name');
		$store_name=$this->input->post('store_name');
		$daterange=$this->input->post('daterange');
		if($daterange!=''){
		$date_sep = explode('-', $daterange);
		$start_date=date('Y-m-d',strtotime($date_sep[0]));
		$end_date=date('Y-m-d',strtotime($date_sep[1]));

		//print_r($date_sep); exit();
		//echo $start_date."<br>".$end_date;exit();
		//if()

		}
		$report_name=$this->input->post('report_name');
		if($report_name=="daily_sales"){
			if(isset($branch_name) && !empty($branch_name)){
				$where=$branch_name;
				$data['data'] = $this->report_model->selectSalesDatasingle($where,$start_date,$end_date);
				$this->load->view('reports/daily_sales_single_branch',$data);
			} else {
			$where=$store_name;
			$data['data'] = $this->report_model->selectSalesData($where,$start_date,$end_date);
			$this->load->view('reports/daily_sales_all_branch',$data);
			}
		}
		if($report_name=="display_tracker"){
			if(isset($branch_name) && !empty($branch_name)){
			$where=$branch_name;
			$data['data'] = $this->report_model->selectDisplayData($where,$start_date,$end_date);
			$this->load->view('reports/display_status_tracker',$data);
			} else {
			$where=$store_name;
			$data['data'] = $this->report_model->selectDisplayDataAll($where,$start_date,$end_date);
			//echo "<pre>";print_r($data);exit();
			$this->load->view('reports/display_status_tracker_all_branch',$data);
			}
		}
		if($report_name=="weekly_sales_tracker"){
			$where=$store_name;
			$data['data'] = $this->report_model->selectWeeklySalesData($where,$start_date,$end_date);
			$this->load->view('reports/weeklysales',$data);
		}
	}
	
	 // Government Reports Listing	
}
?>