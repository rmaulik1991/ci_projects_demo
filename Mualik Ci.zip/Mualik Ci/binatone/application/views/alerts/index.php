<section class="content-header">
    <h1>
        <?= translate('ALERT_TITLE') ?>
    </h1>
    <?php
		$this->load->view("template/bread_crumb");
	?>
</section>
			
<section class="content">
	<div class="row">
    	<div class="col-md-12">

            <div id="flash_msg">
            </div>
            <form action="<?=base_url()?>alerts/report_listed" method="post">
    		<div class="row">
    			
			    <div class="col-md-3">

                    <label>Report :</label>
			         <div class="form-group">
                       1)Listed Stocked but not Displayed<br>
                       2)Listed but no Stocks
                    </div>
                </div>
                <div class="col-md-4">
                     <div class="form-group">
                    <label>Select Date :</label>
                    <div class="input-group">
                        <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
                        <input type="text" class="form-control pull-right" id="daterange" name="daterange">
                    </div></div>
                </div>
                <div class="col-md-3" style="margin-top: 25px;">
                     <div class="form-group">
                        <button class="btn btn-primary btn-flat" id="filter_data" onclick="view_data();" type="button">View</button>
                        <button class="btn btn-primary btn-flat" id="filter_data" onclick="export_data();" type="button">Export</button>
                    </div>
                </div>
            </div>
        </form>
            <div class="row" id="list_div" style="display: none;">
                <div id="list">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">List</h3>                                    
                    </div><!-- /.box-header -->
                    <div class="box-body table-responsive" style="height: 500px;overflow-y: scroll;">
                        <table id="lists" class="table table-bordered table-striped" >
                            <thead>
                                <tr>
                                    <th>Sr no</th>                                 
                                    <th>Store Name</th>                                 
                                    <th>Branch Name</th>                                    
                                    <th>Product</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div><!-- /.box-body -->
                </div><!-- /.box -->
            </div>
            </div>
        		
    	</div>
    </div>
   
</section>
<script type="text/javascript">
     $(function() {
        $('#date').datepicker({format: "dd/mm/yyyy"}); 
    $('input[name="daterange"]').daterangepicker({
        timePicker: false,
        timePickerIncrement: 30,
        locale: {
            format: 'DD/MM/YYYY'
        }
    });
});

     function view_data(id){
        $('#list_div').hide();
        $("#lists tbody").empty();
        //$('#lists tbody').remove();
    var daterange=$('#daterange').val();
    var table_data='';
    if(daterange != ''){
    $.ajax({
        type: 'post',
        url: base_path()+'alerts/report_listed/',
        data: {daterange:daterange},
        success: function (data) {
            var data = $.parseJSON(data);
            var sr_no=1;
            $.each(data, function( index, value ) {
              $.each(value, function( index1, value1 ) {
                $.each(value1, function( index2, value2 ) {
                 table_data += '<tr><td>' + sr_no + '</td><td>' + index + '</td><td>' + index1 + '</td><td>' + value2[0] + '</td><td>' + value2[1] + '</td><td>' + value2[2] + '</td></tr>';
                 sr_no++;
            });            
            });
            });
            
            $('#lists tbody').append(table_data);
            $('#list_div').show();
        }
    });
}
   }
   function clear_report(){
        $('#emp_main_div').hide();
        $('#emp_list tbody').remove();
   }
   function export_data() {
    var data_date=$("#daterange").val();
    window.location.assign(base_path()+'alerts/report_listed?daterange='+data_date);
} 
</script>

