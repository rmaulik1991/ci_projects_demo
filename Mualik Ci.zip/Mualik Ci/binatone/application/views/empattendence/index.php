<section class="content-header">
    <h1>
        <?= translate('ATTENDENCE_TITLE') ?>
    </h1>
    <?php
		$this->load->view("template/bread_crumb");
	?>
</section>
			
<section class="content">
	<div class="row">
    	<div class="col-md-12">
    		<div class="row">
    			<div class="col-md-3"></div>
			    	<div class="col-md-4">
			         <div class="form-group">
                        <?php echo form_label('Employee Name:');?>
                        <select class="form-control" name="emp_name" id="emp_name">
                            <option value="">Select</option>
                            <?php foreach($employee_list as $row){ ?>
                            <option value="<?php echo $row->id; ?>"><?php echo $row->first_name.' '.$row->last_name; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
            </div>
    		<div id="flash_msg">
			</div>
			<div id="list">
				<div class="box">
					<div class="box-header">
						<h3 class="box-title"><?= translate('ATTENDENCE_TITLE') ?></h3>                                    
					</div><!-- /.box-header -->
					<div class="box-body table-responsive">
						<table id="attTable" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>Date Time</th>									
                                    <th>Longitude</th>                                  
									<th>Latitude</th>
									<th>Status</th>
									<th>Action</th>
								</tr>
							</thead>
						</table>
					</div><!-- /.box-body -->
				</div><!-- /.box -->
			</div>
    	</div>
    </div>
</section>
<script type="text/javascript">
	$(document).ready(function() {
		oTable = $('#attTable').dataTable();
	$( "#emp_name" ).change(function() {
    var emp_id = $('#emp_name').val();
    if(emp_id!=''){
    $('#attTable').DataTable().destroy();
    oTable = $('#attTable').dataTable( {
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": base_path()+'empattendence/ajax_list/'+emp_id,
            "type": "POST"
        },
        aoColumnDefs: [
          {
             bSortable: false,
             aTargets: [ -1 ]
          }
        ]
    });
    }
    }).change();
    });
</script>