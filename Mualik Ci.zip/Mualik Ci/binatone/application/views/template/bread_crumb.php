<ol class="breadcrumb">
    <li><a href="<?="dashboard"?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="<?=$this->router->fetch_class()?>"><?=$this->router->fetch_class()?></a></li>
    <li class="active"><?=$this->router->fetch_method()?></li>
</ol>