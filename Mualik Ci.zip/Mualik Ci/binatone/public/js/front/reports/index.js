var oTable;
$(document).ready(function() {
    $( "#branch_name" ).change(function() {
        var branch=$('#branch_name').val();
      $('#storebranchTable').DataTable().destroy();  
	oTable = $('#storebranchTable').dataTable( {
		"processing": true,
		"serverSide": true,
		"ajax": {
			"url": base_path()+'storeproduct/ajax_list/'+branch,
			"type": "POST"
		},
		aoColumnDefs: [
		  {
			 bSortable: false,
			 aTargets: [ -1 ]
		  }
		]
    } );
	} );

	
	$('#reportFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		 fields: {
            report_name: {
                 message: 'The Repoer Name is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Report Name is required and cannot be empty'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The firstname can only consist of alphabetical'
                    // }
                }
            },
            store_name: {
                 message: 'The Store Name is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Store Name is required and cannot be empty'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The firstname can only consist of alphabetical'
                    // }
                }
            }
            /*branch_name: {
                 message: 'The Store Name is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Store Name is required and cannot be empty'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The firstname can only consist of alphabetical'
                    // }
                }
            }*/
		 }
    });
} );

function delete_storebranch(del_id) {
bootbox.confirm("Are you sure to delete branch?", function(result) {
	if(result){
	startLoading();
	$.ajax({
		type: 'post',
		url: base_path()+'storebranch/delete',
		data: 'id='+del_id,
		success: function (data) {
			if (data == "success") {
				oTable.fnClearTable(0);
				oTable.fnDraw();
				$("#flash_msg").html(success_msg_box ('Store deleted successfully.'));
			}else{
				$("#flash_msg").html(error_msg_box ('An error occurred while processing.'));
			}
			stopLoading();
		}
	});
	}
	});
}

$('#add_product').click(function(){
   var branch_id=$('#branch_name').val();
   if(branch_id!=''){
   window.location.href=base_path()+'storeproduct/assign_product/'+branch_id;
    }
    else{
        alert('Please Select branch to add product');
    }
})

function get_branch() {
    var store_id=$('#store_name').val();
    $('#branch_name')
    .find('option')
    .remove()
    .end()
    .append('<option value="">All</option>');
    $.ajax({
        type: 'post',
        url: base_path()+'storeproduct/get_branch/'+store_id,
        success: function (data) {
            if(data['branch_list']!=''){
            var i=0;
             $.each(data['branch_list'], function(id, category_name) {
                $('#branch_name').append("<option value='" +data['branch_list'][i]['id'] + "'>" + data['branch_list'][i]['branch_name'] + "</option>");
                i++;
            });
         }
        }
    });
    
}