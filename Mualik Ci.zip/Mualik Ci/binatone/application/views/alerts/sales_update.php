<section class="content-header">
    <h1>
        Sales Update
    </h1>
    <?php
		$this->load->view("template/bread_crumb");
	?>
</section>
			
<section class="content">
	<div class="row">
    	<div class="col-md-12">

            <div id="flash_msg">
            </div>
           
            <div class="row">
                
                <div class="col-md-3">

                    <label>Report :</label>
                     <div class="form-group">
                       1)Employee List Who not update sales
                    </div>
                </div>
                <div class="col-md-2">
                     <div class="form-group">
                    <label>Select Date :</label>
                    <div class="input-group">
                        <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
                        <input type="text" class="form-control pull-right" id="date" name="date">
                    </div></div>
                </div>
                <div class="col-md-2">
                     <div class="form-group">
                    <label>Select Report :</label>
                    <div class="input-group">
                        <select class="form-control" name="report_name" id="report_name">
                                    <option value="sales">Sales Tracker</option>
                                    <option value="display">Display Tracker</option>
                                </select>
                    </div></div>
                </div>
                <div class="col-md-3" style="margin-top: 25px;">
                     <div class="form-group">
                        <button class="btn btn-primary btn-flat" onclick="view_data();" id="filter_data">Show</button>
                        <button class="btn btn-primary btn-flat" onclick="clear_report();" id="filter_data">Clear</button>
                    </div>
                </div>
            </div>			
    	</div>
    </div>
    <div class="row" id="emp_main_div" style="display: none;">
   
    <div class="col-md-12" style="text-align: center;">
              <div class="box">
                <div class="box-header with-border">
                  <h3 class="box-title">Employee List</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table class="table table-bordered" id="emp_list">
                    <thead>
                    <tr>
                      <th style="text-align: center;">#</th>
                      <th style="text-align: center;">Employee Name</th>
                      <th style="text-align: center;">Store Name</th>
                      <th style="text-align: center;">Branch Name</th>
                    </tr>
                </thead>
                    <tbody>
                  </tbody></table>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
</section>
<script type="text/javascript">
     $(function() {
        $('#date').datepicker({format: "dd/mm/yyyy"}); 
    $('input[name="daterange"]').daterangepicker({
        timePicker: false,
        timePickerIncrement: 30,
        locale: {
            format: 'DD/MM/YYYY'
        }
    });
});

     function view_data(id){
        $('#emp_main_div').hide();
        $('#emp_list tbody').remove();
    var sel_date=$('#date').val();
    var report_name=$('#report_name').val();
    var table_data='';
    var url="<?php echo base_url(); ?>";
    if(sel_date != ''){
    $.ajax({
        type: 'post',
        url: base_path()+'alerts/employee_status/',
        data: {sel_date:sel_date,report_name:report_name},
        success: function (data) {
            $('#emp_main_div').show();
            var i=0;
            $.each(data['emp_list'], function(first_name,store_name,branch_name) {
                table_data += '<tr><td>'+(i+1)+'<td>' + data['emp_list'][i]['first_name'] + '</td><td>' + data['emp_list'][i]['store_name'] + '</td><td>' + data['emp_list'][i]['branch_name'] + '</td></tr>';
                i++;
            });
            $('#emp_list').append(table_data);
        }
    });
}
   }
   function clear_report(){
        $('#emp_main_div').hide();
        $('#emp_list tbody').remove();
   }
</script>

