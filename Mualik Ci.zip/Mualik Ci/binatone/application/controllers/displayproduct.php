<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require ("common/Index_Controller.php");

class displayproduct extends Index_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('displayproduct_model');
		$this->user_session = $this->session->userdata('user_session');
		is_login();
	}

	public function index() {	
		$data['flash_msg'] = $this->msg_session;
		$data['branch_list']=$this->displayproduct_model->selectData(STORE_BRANCH_TABLE,'*');		
		$data['view'] = "index";
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');
	}

	public function ajax_list($limit=0) {
		$branch_id=$_POST['branch_id'];
		$product=$_POST['product'];
		$daterange="01/01/1970 - 01/01/2022";
		if($_POST['daterange']!=''){
			$daterange=$_POST['daterange'];
		}
		$fil_date=explode('-', $daterange);
		$start_date= date('Y-m-d' ,strtotime($fil_date[0]));
		$end_date= date('Y-m-d' ,strtotime($fil_date[1]));
		//date('Y' ,strtotime('2017/11/01');
		$post = $this->input->post();
		$columns = array(		
			array( 'db' => 'e`.`first_name',  'dt' => 0,'field' => 'first_name' ),
			array( 'db' => 'p`.`product_name',  'dt' => 1,'field' => 'product_name' ),
			array( 'db' => 'sb`.`branch_name',  'dt' => 2,'field' => 'branch_name' ),
			array( 'db' => 'dp`.`is_own_product','dt'=> 3,'field' => 'is_own_product' ),
			array( 'db' => 'dp`.`create_date','dt'=> 4,'formatter' => function( $d, $row ) {
						return date('d-m-Y' ,strtotime($row['create_date']));
					},'field' => 'create_date' ),
			array( 'db' => 'dp`.`Id',
					'dt' => 5,
					'formatter' => function( $d, $row ) {
						return '<button class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal" onclick="view_data('.$d.')">View</button>&nbsp&nbsp&nbsp<a href="javascript:void(0);" onclick="approve_data('.$d.')" class="fa fa-check"></a>';
					},'field' => 'Id'
			),
		);
		$join1 = array(STORE_BRANCH_TABLE.' as sb','dp.sts_branch_id = sb.id','left');
		$join2 = array(PRODUCT_TABLE.' as p','dp.sts_product_id = p.id','left');
		$join3 = array(EMPLOYEE.' as e','dp.sts_employee_id	 = e.id','left');
		if($branch_id!='' && $product!=''){
		echo json_encode( SSP::simple( $post, DISPLAY_PRODUCT.' as dp', "dp.Id", $columns,array($join1,$join2,$join3),"dp.sts_employee_id !=' ' AND dp.status !='Approve' AND dp.sts_branch_id=".$branch_id." AND dp.sts_product_id=".$product." AND date(dp.create_date) BETWEEN '".$start_date."' AND '".$end_date."'" ) );
		}elseif($branch_id!=''){
		echo json_encode( SSP::simple( $post, DISPLAY_PRODUCT.' as dp', "dp.Id", $columns,array($join1,$join2,$join3),"dp.sts_employee_id !=' ' AND dp.status !='Approve' AND dp.sts_branch_id=".$branch_id." AND date(dp.create_date) BETWEEN '".$start_date."' AND '".$end_date."'" ) );	
		}
		else{
		echo json_encode( SSP::simple( $post, DISPLAY_PRODUCT.' as dp', "dp.Id", $columns,array($join1,$join2,$join3),"dp.sts_employee_id !=' ' AND dp.status !='Approve' AND date(dp.create_date) BETWEEN '".$start_date."' AND '".$end_date."'") );	
		//echo $this->db->last_query();exit;
		}

		exit;
	}
	public function get_product($id){
		header('Content-Type: application/json');
		$where = 'sts_branch_id = '.$id;
		$data['product_list']=$this->displayproduct_model->selectProduct(STORE_PRODUCT_INT,$where);
		echo json_encode($data);
	}
	public function view_data($id){
		header('Content-Type: application/json');
		$where = 'id = '.$id;
		$data['view_data']=$this->displayproduct_model->selectData(DISPLAY_PRODUCT,'*',$where);
		echo json_encode($data);	
	}
	public function approve_data(){
		$post = $this->input->post();
		$data=array("status"=>"Approve");

		if ($post) {
			$ret = $this->displayproduct_model->updateData(DISPLAY_PRODUCT, $data,array('Id' => $post['id'] ));
			//$ret = $this->product_model->deleteData(ADMIN_MASTER, array('Id' => $post['id'] ));
			if ($ret > 0) {
				echo "success";
				exit;
				#echo success_msg_box('User deleted successfully.');;
			}else{
				echo "error";
				exit;
				#echo error_msg_box('An error occurred while processing.');
			}
		}
	}

}
