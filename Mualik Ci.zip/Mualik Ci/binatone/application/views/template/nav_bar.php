<body class="skin-blue">
    <!-- header logo: style can be found in header.less -->
   <header class="header">
            <a class="logo" href="<?=base_url()?>dashboard">
                <!-- Add the class icon to your logo image or logo icon to add the margining -->
                <img src="<?php echo base_url(); ?>public\images\binatone-logo.png" style="width: 90%">
            </a>
            <!-- Header Navbar: style can be found in header.less -->
            <nav role="navigation" class="navbar navbar-static-top">
                <!-- Sidebar toggle button-->
                <a role="button" data-toggle="offcanvas" class="navbar-btn sidebar-toggle" href="#">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <div class="navbar-right">
                    <ul class="nav navbar-nav">
                        <!-- User Account: style can be found in dropdown.less -->
                        <li class="dropdown user user-menu">
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <i class="glyphicon glyphicon-user"></i>
                                <span><?=$this->user_session['username']?> <i class="caret"></i></span>
                            </a>
                            <ul class="dropdown-menu">
                                <!-- User image -->
                                <li class="user-header bg-light-blue">
									<?php if(isset($this->user_session['profilepic']) && $this->user_session['profilepic']!=''){ ?>
										<img alt="User Image" class="img-circle" src="<?php echo profile_img_path().$this->user_session['profilepic'];?>"> 
									<?php } ?>
                                    <p>
                                        <?=$this->user_session['username']?> - Admin
                                        <small>Member since <?=date("M. Y", strtotime($this->user_session['create_date']))?></small>
                                    </p>
                                </li>
                               
                                <li class="user-footer">
                                    <div class="pull-left">
                                        <a class="btn btn-default btn-flat" href="<?php echo base_url()?>adminmaster/adminprofile">Profile</a>
                                    </div>
                                    <div class="pull-right">
                                        <a class="btn btn-default btn-flat" href="<?php echo index_path() ?>logout">Sign out</a>
                                    </div>
                                </li>
                            </ul>
                        </li>
						<!--li class="dropdown user user-menu">
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <i class="glyphicon glyphicon-font"></i>
                                <span><?= translate('ADMIN_LANGUAGE_LABLE_LANGUAGE') ?> <i class="caret"></i></span>
                            </a>
                            <ul class="dropdown-menu">
                                
                                <li class="user-body bg-light-blue">
                                    <img alt="User Image" class="img-circle" src="img/avatar3.png">
                                    <div class="col-xs-12 text-center">
                                        <?= translate('ADMIN_LANGUAGE_LABLE_SELECT_LANGUAGE') ?>
                                    </div>
                                </li>
                                
                                <li class="user-body">
                                    <div class="col-xs-6 text-center">
                                        <a href="javascript:void(0);" onclick="javascript:changeLanguage('english');">English</a>
                                    </div>
                                    <div class="col-xs-6 text-center">
                                        <a href="javascript:void(0);" onclick="javascript:changeLanguage('spanish');">Spanish</a>
                                    </div>
                                </li>
                            </ul>
                        </li-->
                    </ul>
                </div>
            </nav>
        </header>