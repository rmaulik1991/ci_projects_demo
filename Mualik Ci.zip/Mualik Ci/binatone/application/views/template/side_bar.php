<!-- Left side column. contains the logo and <span></span>idebar -->
<aside class="left-side sidebar-offcanvas" style="min-height: 2038px;">
	<!-- sidebar: style can be found in sidebar.less -->
	<section class="sidebar">
		<!-- Sidebar user panel -->
		<div class="user-panel">
			<?php if(isset($this->user_session['profilepic']) && $this->user_session['profilepic']!=''){ ?>
				<div class="pull-left image">
					<img alt="User Image" class="img-circle" src="<?php echo profile_img_path().$this->user_session['profilepic'];?>">
				</div>
			<?php } ?>
			<div class="pull-left info">
				<p>Hello, <?php echo $this->user_session['username'];?></p>
			</div>
		</div>
		
		<!-- sidebar menu: : style can be found in sidebar.less -->
		<ul class="sidebar-menu">
			<li class="<?=get_active_tab("dashboard")?>">
				<a href="<?=base_url()?>dashboard">
					<i class="fa fa-dashboard"></i> <span><?= translate('ADMIN_SIDEBAR_LABLE_DASHBOARD') ?></span>
				</a>
			</li>

			

			<li class="<?=get_active_tab("adminmaster")?>">
				<a href="<?=base_url()?>adminmaster">
					<i class="fa fa-lock"></i> <span>Employee</span>
				</a>
			</li>
			<li class="treeview <?=get_active_tab("store")?> <?=get_active_tab("storebranch")?> ">
                <a href="#">
                    <i class="fa fa-shopping-cart"></i> <span>Store Details</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class="<?=get_active_tab("store")?>"><a href="<?=base_url()?>store"><i class="fa fa-shopping-cart"></i> <span>Store</span></a></li>
                    <li class="<?=get_active_tab("storebranch")?>"><a href="<?=base_url()?>storebranch"><i class="fa fa-code-fork"></i> <span>Store Branch</span></a></li>
                    
                </ul>
            </li>

            <li class="treeview <?=get_active_tab("category")?> <?=get_active_tab("brand")?> <?=get_active_tab("product")?> ">
                <a href="#">
                    <i class="fa fa-list-ol"></i> <span>Product Info</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class="<?=get_active_tab("brand")?>">
						<a href="<?=base_url()?>brand">
							<i class="fa fa-dribbble"></i><span>Brand</span>
						</a>
					</li>
                    <li class="<?=get_active_tab("category")?>">
						<a href="<?=base_url()?>category">
							<i class="fa fa-list-alt"></i> <span><?= translate('ADMIN_SIDEBAR_LABLE_CATEGORY') ?></span>
						</a>
					</li>
					<li class="<?=get_active_tab("product")?>">
						<a href="<?=base_url()?>product">
							<i class="fa fa-list-ol"></i> <span>Product</span>
						</a>
					</li>
                    
                </ul>
            </li>
            <li class="treeview <?=get_active_tab("storeproduct")?> <?=get_active_tab("storeemp")?> ">
                <a href="#">
                    <i class="fa fa-retweet"></i> <span>Assignment</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class="<?=get_active_tab("storeproduct")?>">
						<a href="<?=base_url()?>storeproduct">
							<i class="fa fa-retweet"></i> <span>Assign Store Product</span>
						</a>
					</li>
                    
                    <li class="<?=get_active_tab("storeemp")?>">
						<a href="<?=base_url()?>storeemp">
							<i class="fa fa-male"></i> <span>Assign Store Employee</span>
						</a>
					</li>
                </ul>
            </li>
			

			<li class="<?=get_active_tab("empattendence")?>">
				<a href="<?=base_url()?>empattendence">
					<i class="fa fa-signal"></i> <span>Attendence</span>
				</a>
			</li>
			<li class="<?=get_active_tab("displayproduct")?>">
				<a href="<?=base_url()?>displayproduct">
					<i class="fa fa-desktop"></i> <span>Display Product</span>
				</a>
			</li>
			<!-- <li class="<?=get_active_tab("alerts")?>">
				<a href="<?=base_url()?>alerts">
					<i class="fa fa-bell-o"></i> <span>Alerts</span>
				</a>
			</li> -->

			<li class="treeview <?=get_active_tab("alerts")?>">
                <a href="#">
                    <i class="fa fa-list-ol"></i> <span>Alerts</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class="<?=get_active_tab("alerts")?>">
						<a href="<?=base_url()?>alerts">
							<i class="fa fa-dribbble"></i><span>Listed Stocked</span>
						</a>
					</li>
                    <li class="<?=get_active_tab("alerts")?>">
						<a href="<?=base_url()?>alerts/sales_update">
							<i class="fa fa-list-alt"></i> <span>Sales Update</span>
						</a>
					</li>
                    
                </ul>
            </li>
			<!-- <li class="<?=get_active_tab("comproduct")?>">
				<a href="<?=base_url()?>comproduct">
					<i class="fa fa-level-up"></i> <span>Competitor Product</span>
				</a>
			</li> -->

			
			<li class="<?=get_active_tab("reports")?>">
				<a href="<?=base_url()?>reports">
					<i class="fa fa-file-text-o"></i> <span><?= translate('ADMIN_SIDEBAR_LABLE_REPORTS') ?></span>
				</a>
			</li>                                                              
            
		</ul>
	</section>    
</aside>
