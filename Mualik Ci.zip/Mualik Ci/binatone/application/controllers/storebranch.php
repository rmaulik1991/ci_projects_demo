<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require ("common/Index_Controller.php");

class storebranch extends Index_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('storebranch_model');
		$this->user_session = $this->session->userdata('user_session');
		is_login();
	}

	public function index() {	
		$data['flash_msg'] = $this->msg_session;
		$data['store_list']=$this->storebranch_model->storelistData(STORE);		
		$data['view'] = "index";
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');
	}

	/*public function ajax_list($limit=0) {
		$post = $this->input->post();
		$columns = array(
			array( 'db' => 'branch_name', 'dt' => 0 ,'formatter' => function( $d, $row )
					{
						return '<a href="'.site_url('/storebranch/edit/'.$row['Id']).'" >'.$row['branch_name'].'</a>';
					}),			
			array( 'db' => 'address',  'dt' => 1 ),
			array( 'db' => 'contact_person',  'dt' => 2 ),
			array( 'db' => 'contact_number',  'dt' => 3 ),
			array( 'db' => 'status','dt'=> 4 ),
			array( 'db' => 'Id',
					'dt' => 5,
					'formatter' => function( $d, $row ) {
						return '<a href="javascript:void(0);" onclick="delete_storebranch('.$d.')" class="fa fa-trash-o"></a>';
					},
			),
		);
		
		echo json_encode( SSP::simple( $post, STORE_BRANCH_TABLE, "Id", $columns,array(),"status !='Inactive'" ) );
		exit;
	}*/

	public function ajax_branch_list($store_id,$limit=0) {
		$post = $this->input->post();
		$columns = array(
			array( 'db' => 'branch_name', 'dt' => 0 ,'formatter' => function( $d, $row )
					{
						return '<a href="'.site_url('/storebranch/edit/'.$row['Id']).'" >'.$row['branch_name'].'</a>';
					}),			
			array( 'db' => 'address',  'dt' => 1 ),
			array( 'db' => 'contact_person',  'dt' => 2 ),
			array( 'db' => 'contact_number',  'dt' => 3 ),
			array( 'db' => 'status','dt'=> 4 ),
			array( 'db' => 'Id',
					'dt' => 5,
					'formatter' => function( $d, $row ) {
						return '<a href="javascript:void(0);" onclick="delete_storebranch('.$d.')" class="fa fa-trash-o"></a> <a href="'.site_url('/storeproduct/assign_product/'.$row['Id']).'" > | Assign Product</a>';
					},
			),
		);
		
		echo json_encode( SSP::simple( $post, STORE_BRANCH_TABLE, "Id", $columns,array(),"status !='Inactive' AND sts_store_id=".$store_id."" ) );
		exit;
	}

	public function branch($id) {
		if ($id == "" || $id <= 0) {
			redirect('storebranch');
		}	
		$data['flash_msg'] = $this->msg_session;		
		$data['view'] = "branch";
		$data['store_id'] = $id;
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');
	}

	public function add() {
		$post = $this->input->post();
		if ($post) {					
			
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('<label class="form-error-msg"><i class="fa fa-times-circle-o"></i>', '</label><br/>');
			$this->form_validation->set_rules('store_name', 'Store Name', 'trim|required');
			$this->form_validation->set_rules('branch_name', 'Branch Name', 'trim|required|min_length[2]');
			$this->form_validation->set_rules('contact_person', 'Contact Person', 'trim|required|min_length[2]');
			$this->form_validation->set_rules('contact_number', 'Contact no', 'trim|required|numeric|min_length[10]|max_length[10]');
			$this->form_validation->set_rules('latitude', 'Latitude', 'trim|required');
			$this->form_validation->set_rules('longitude', 'Longitude', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			
			if ($this->form_validation->run()) {				
					$flash_arr=0;
					$data=array('sts_store_id'=>$post['store_name']
								,'branch_name'=>$post['branch_name']
								,'contact_person'=>$post['contact_person']
								,'contact_number'=>$post['contact_number']							
								,'address'=>$post['address']							
								,'latitude'=>$post['latitude']							
								,'longitude'=>$post['longitude']							
								,'create_date' => date('Y-m-d H:i:s')
								,'update_date' => date('Y-m-d H:i:s')
								,'status' => $post['status']
						);
					$ret = $this->storebranch_model->insertData(STORE_BRANCH_TABLE, $data);
					
					if ($ret > 0) {						
						$flash_arr = array('flash_type' => 'success',
										'flash_msg' => 'Admin added successfully.'
									);
					}else{
						$flash_arr = array('flash_type' => 'error',
										'flash_msg' => 'An error occurred while processing.'
									);
					}
					$this->session->set_userdata('msg_session',$flash_arr);
					redirect("storebranch/index");
				}
				$this->session->set_userdata('msg_session',$flash_arr);
			}
			$data['store_list']=$this->storebranch_model->storelistData(STORE);
			$post=(object)$post;
			$data['admin']=array('0'=>$post);
		
		$data['flash_msg'] = $this->msg_session;
		$data['view'] = "add_edit";
		$data['current_view'] = "add";
		$data['user_role'] = $this->user_session['role'];
		$this->load->view('content', $data);
	}
	
	public function edit($id) {
		if ($id == "" || $id <= 0) {
			redirect('storebranch');
		}

		$where = 'id = '.$id;
		$is_error=0;
		$post = $this->input->post();
		
		if ($post) {			
			
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('<label class="form-error-msg"><i class="fa fa-times-circle-o"></i>', '</label><br/>');
			$this->form_validation->set_rules('store_name', 'Store Name', 'trim|required');
			$this->form_validation->set_rules('branch_name', 'Branch Name', 'trim|required|min_length[2]');
			$this->form_validation->set_rules('contact_person', 'Contact Person', 'trim|required|min_length[2]');
			$this->form_validation->set_rules('contact_number', 'Contact no', 'trim|required|numeric|min_length[10]|max_length[10]');
			$this->form_validation->set_rules('latitude', 'Latitude', 'trim|required');
			$this->form_validation->set_rules('longitude', 'Longitude', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			
			if ($this->form_validation->run()) {				
				
				$data=array('sts_store_id'=>$post['store_name']
								,'branch_name'=>$post['branch_name']
								,'contact_person'=>$post['contact_person']
								,'contact_number'=>$post['contact_number']							
								,'address'=>$post['address']
								,'latitude'=>$post['latitude']							
								,'longitude'=>$post['longitude']							
								,'create_date' => date('Y-m-d H:i:s')
								,'update_date' => date('Y-m-d H:i:s')
								,'status' => $post['status']
						);
					$ret = $this->storebranch_model->updateData(STORE_BRANCH_TABLE, $data, $where);

				if ($ret > 0) {
					$flash_arr = array('flash_type' => 'success',
										'flash_msg' => 'Admin updated successfully.'
									);
				}else{
					$flash_arr = array('flash_type' => 'error',
										'flash_msg' => 'An error occurred while processing.'
									);
				}
				$this->session->set_userdata('msg_session',$flash_arr);
				redirect("storebranch");
				}
			$this->session->set_userdata('msg_session',$flash_arr);
			}
		$data['store_list']=$this->storebranch_model->storelistData(STORE);
		$data['store_branch'] = $store_branch = $this->storebranch_model->selectData(STORE_BRANCH_TABLE, '*', $where);
		
		if (empty($store_branch)) {
			redirect('storebranch/index');
		}
		$data['flash_msg'] = $this->msg_session;
		$data['view'] = "add_edit";
		$data['current_view'] = "edit";
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');		
	}

	public function delete() {
		$post = $this->input->post();
		$data=array("status"=>"Inactive");

		if ($post) {
			$ret = $this->storebranch_model->updateData(STORE_BRANCH_TABLE, $data,array('Id' => $post['id'] ));
			//$ret = $this->storebranch_model->deleteData(ADMIN_MASTER, array('Id' => $post['id'] ));
			if ($ret > 0) {
				echo "success";
				exit;
				#echo success_msg_box('User deleted successfully.');;
			}else{
				echo "error";
				exit;
				#echo error_msg_box('An error occurred while processing.');
			}
		}
	}
}
