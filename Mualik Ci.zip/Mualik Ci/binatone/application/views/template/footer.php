	<!-- jQuery 2.0.2 -->
    
    <!-- jQuery UI 1.10.3 -->
    <script src="<?=public_path()?>js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
    <!-- Bootstrap -->
    <script src="<?=public_path()?>js/bootstrap.min.js" type="text/javascript"></script>
    <!-- <script src="http://cdnjs.cloudflare.com/ajax/libs/moment.js/2.5.1/moment.min.js"></script> -->
    <script src="<?=public_path()?>js/bootbox.min.js" type="text/javascript"></script>
    <!-- Morris.js charts -->
    <!-- script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="<?=public_path()?>js/plugins/morris/morris.min.js" type="text/javascript"></script -->
    <!-- Sparkline -->
    <!-- script src="<?=public_path()?>js/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script !-->
    <!-- jvectormap -->
    <!-- script src="<?=public_path()?>js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
    <script src="<?=public_path()?>js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script-->
    <!-- fullCalendar -->
    <!-- script src="<?=public_path()?>js/plugins/fullcalendar/fullcalendar.min.js" type="text/javascript"></script-->
    <!-- jQuery Knob Chart -->
    <script src="<?=public_path()?>js/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>
    <!-- daterangepicker -->
    <script src="<?=public_path()?>js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script> 
    <script src="<?=public_path()?>js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="<?=public_path()?>js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <!-- <script src="<?=public_path()?>js/plugins/datepicker/bootstrap-datepicker.js?1" type="text/javascript"></script> -->
    <script src="<?=public_path()?>js/plugins/datepicker/bootstrap-datepicker.min.js" type="text/javascript"></script>   
    <script src="<?=public_path()?>js/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script> 
    <!-- <script type="text/javascript" src="//192.168.100.171/bookmytrip\public/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script> -->
    <script src="<?=public_path()?>js/plugins/datepicker/jquery.inputmask.js" type="text/javascript"></script>
    <script src="<?=public_path()?>js/plugins/datepicker/jquery.inputmask.date.extensions.js" type="text/javascript"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="<?=public_path()?>js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
	<!-- chartjs -->
	<script src="<?=public_path()?>js/plugins/chartjs/Chart.min.js" type="text/javascript"></script>
    <!-- iCheck -->
    <!-- <script src="<?=public_path()?>js/plugins/iCheck/icheck.min.js" type="text/javascript"></script>-->
	
    <script type="text/javascript">
        function admin_path () {
            return '<?=admin_path()?>';
        }

         function base_path(){
            return '<?=base_path()?>';   
        }


        function success_msg_box (msg) {
            var html = '<div class="alert alert-success alert-dismissable"> \n\
                            <i class="fa fa-check"></i> \n\
                            <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button> \n\
                            '+msg+' \n\
                        </div>';
            return html;
        }

        function error_msg_box(msg)
        {
            var html = '<div class="alert alert-danger alert-dismissable"> \n\
                            <i class="fa fa-ban"></i> \n\
                            <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button> \n\
                            '+msg+' \n\
                        </div>';
            return html;
        }
    </script>
	
    <?php if ($this->router->fetch_class() == "dashboard") { ?>
<!--        <script src="<?=public_path()?>js/admin/dashboard/deals.js" type="text/javascript"></script>-->
    <?php } ?>

    <?php if ($this->router->fetch_class() == "users") { ?>
		<script src="<?=public_path()?>js/admin/users/index.js" type="text/javascript"></script>
    <?php } ?>

    <!-- <?php if ($this->router->fetch_class() == "category") { ?><script src="<?=public_path()?>js/admin/category/index.js" type="text/javascript"></script>
    <?php } ?> -->
	 <?php if ($this->router->fetch_class() == "product") { ?>
		<script src="<?=public_path()?>js/front/product/index.js" type="text/javascript"></script>
        <script src="<?=public_path()?>js/plugins/ckeditor/ckeditor.js" type="text/javascript"></script>
    <?php } ?>
    <?php if ($this->router->fetch_class() == "dashboard") { ?>
        <script src="<?=public_path()?>js/front/dashboard/index.js" type="text/javascript"></script>
    <?php } ?>
    <?php if ($this->router->fetch_class() == "company") { ?>
        <script src="<?=public_path()?>js/front/company/index.js" type="text/javascript"></script>
    <?php } ?>
    <?php if ($this->router->fetch_class() == "storeemp") { ?>
        <script src="<?=public_path()?>js/front/storeemp/index.js" type="text/javascript"></script>
    <?php } ?>
    <?php if ($this->router->fetch_class() == "storeproduct") { ?>
        <script src="<?=public_path()?>js/front/storeproduct/index.js" type="text/javascript"></script>
    <?php } ?>
    <?php if ($this->router->fetch_class() == "dashboard") { ?>
<!--		<script src="<?=public_path()?>js/admin/dashboard/deals.js" type="text/javascript"></script>-->
    <?php } ?>
	 <?php if ($this->router->fetch_class() == "language") { ?>
		<script src="<?=public_path()?>js/admin/language/index.js" type="text/javascript"></script>
    <?php } ?>
	<?php if ($this->router->fetch_class() == "store") { ?>
		<script src="<?=public_path()?>js/front/store/index.js" type="text/javascript"></script>
    <?php } ?>

    <?php if ($this->router->fetch_class() == "brand") { ?>
        <script src="<?=public_path()?>js/front/brand/index.js" type="text/javascript"></script>
    <?php } ?>
    <?php if ($this->router->fetch_class() == "storebranch") { ?>
        <script src="<?=public_path()?>js/front/storebranch/index.js" type="text/javascript"></script>
    <?php } ?>

    <?php if ($this->router->fetch_class() == "category") { ?>
        <script src="<?=public_path()?>js/front/category/index.js" type="text/javascript"></script>
    <?php } ?>

    <?php if ($this->router->fetch_class() == "adminmaster") { ?>
        <script src="<?=public_path()?>js/front/adminmaster/index.js" type="text/javascript"></script>
    <?php } ?>
    <?php if ($this->router->fetch_class() == "sendemail") { ?>
             <script src="<?=public_path()?>js/plugins/ckeditor/ckeditor.js" type="text/javascript"></script>
         <script src="<?=public_path()?>js/front/sendemail/index.js" type="text/javascript"></script>
       
     <script type="text/javascript">
            $(function() {
                CKEDITOR.replace('emailContent');
            });
     </script>
    <?php } ?>
    
    <?php if ($this->router->fetch_class() == "emailtemplate" && ($this->router->fetch_method() == "add" || $this->router->fetch_method() == "edit")) { ?>
        
        <script src="<?=public_path()?>js/plugins/ckeditor/ckeditor.js" type="text/javascript"></script>
     <script type="text/javascript">
            $(function() {
                CKEDITOR.replace('emailContent');
            });
     </script>
    <?php } ?>

     <?php if ($this->router->fetch_class() == "emailtemplate" ) { ?>
        <script src="<?=public_path()?>js/front/emailtemplate/index.js" type="text/javascript"></script>
    <?php } ?>

    <?php if ($this->router->fetch_class() == "tender" ) { ?>
        <script src="<?=public_path()?>js/front/tender/index.js" type="text/javascript"></script>
    <?php } ?>
   <?php if ($this->router->fetch_class() == "privatetender" ) { ?>
        <script src="<?=public_path()?>js/front/privatetender/index.js" type="text/javascript"></script>

    <?php } ?>
	<?php if ($this->router->fetch_class() == "reports" ) { ?>
        <script src="<?=public_path()?>js/front/reports/index.js" type="text/javascript"></script>

    <?php } ?>
	<?php if ($this->router->fetch_class() == "pages" && ($this->router->fetch_method() == "add" || $this->router->fetch_method() == "edit")) { ?>
	 <script src="<?=public_path()?>js/plugins/ckeditor/ckeditor.js" type="text/javascript"></script>
	 <script type="text/javascript">
            $(function() {
                CKEDITOR.replace('pageContent');
            });
     </script>

	<?php } ?>
	<script src="<?=public_path()?>js/front/main.js" type="text/javascript"></script>
	<!-- Block UI -->
	<script src="<?=public_path()?>js/jquery.blockUI.js" type="text/javascript"></script>
    <!-- AdminLTE App -->
    <script src="<?=public_path()?>js/AdminLTE/app.js" type="text/javascript"></script>
    <script src="<?=public_path()?>js/image_crop/components/imgareaselect/scripts/jquery.imgareaselect.js" type="text/javascript"></script>
    <script src="<?=public_path()?>js/image_crop/build/jquery.awesome-cropper.js" type="text/javascript"></script>

    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="<?=public_path()?>js/AdminLTE/dashboard.js" type="text/javascript"></script>

    <!-- AdminLTE for demo purposes -->
    <script src="<?=public_path()?>js/AdminLTE/demo.js" type="text/javascript"></script>
    <!-- form validation -->
	<script src="<?=public_path()?>js/bootstrapValidator.js" type="text/javascript"></script>
	
	<script>
		<?php if (isset($flash_msg['flash_msg'])) {  
				if($flash_msg['flash_type']=='success')
				{ ?>
					$('#flash_msg').html(success_msg_box('<?php echo $flash_msg['flash_msg'] ?>'));
				<?php }
				else if($flash_msg['flash_type']=='error')
				{?>
					$('#flash_msg').html(error_msg_box('<?php echo $flash_msg['flash_msg'] ?>'));
				<?php }
					 
		 } else { ?>
			$('#flash_msg').html('');
		 <?php } ?>
	</script>

    </body>
</html>
