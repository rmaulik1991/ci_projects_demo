<section class="content-header">
    <h1>
        
        <small>
            <?=($this->router->fetch_method() == 'add')?'Add Store branch':'Edit Store branch'?>            
        </small>
    </h1>
    <?php
		$this->load->view("/template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">
    	<div class="col-md-6">
    		<div class="box-body">
                 <div id="flash_msg"></div>
                 <?php echo form_open('',array('name'=>"storeFrm",'id'=>"storeFrm")); ?>
                    <div class="form-group">
                        <?php echo form_error('store_name'); ?>    
                        <?php echo form_label('Store Name:');?>
                        <select class="form-control" name="store_name" id="store_name">
                            <option value="">Select</option>
                            <?php foreach($store_list as $row){ ?>
                            <option value="<?php echo $row->id; ?>" <?=(@$store_branch[0]->sts_store_id == $row->id)?'selected':''?> ><?php echo $row->store_name; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('branch_name'); ?>    
                        <?php echo form_label('Branch Name:');?>
                        <?php echo form_input(array('id' => 'branch_name', 'name' => 'branch_name' , 'class'=>'form-control', 'placeholder'=>'Enter Branch Name...','value'=>@$store_branch[0]->branch_name)); ?>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('address'); ?>    
                        <?php echo form_label('Address:');?>
                        <?php echo form_input(array('id' => 'address', 'type'=>'textarea' ,'name' => 'address' , 'class'=>'form-control', 'placeholder'=>'Enter Address...','value'=>@$store_branch[0]->address)); ?>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('latitude'); ?>    
                        <?php echo form_label('Latitude:');?>
                        <?php echo form_input(array('id' => 'latitude', 'name' => 'latitude' , 'class'=>'form-control', 'placeholder'=>'Enter Latitude...','value'=>@$store_branch[0]->latitude)); ?>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('longitude'); ?>    
                        <?php echo form_label('Longitude:');?>
                        <?php echo form_input(array('id' => 'longitude', 'name' => 'longitude' , 'class'=>'form-control', 'placeholder'=>'Enter Longitude...','value'=>@$store_branch[0]->longitude)); ?>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('contact_person'); ?>    
                        <?php echo form_label('Contact Person:');?>
                        <?php echo form_input(array('id' => 'contact_person', 'name' => 'contact_person' , 'class'=>'form-control', 'placeholder'=>'Enter Contact Person Name...','value'=>@$store_branch[0]->contact_person)); ?>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('contact_number'); ?>    
                        <?php echo form_label('Contact Number:');?>
                        <?php echo form_input(array('id' => 'contact_number', 'name' => 'contact_number' , 'class'=>'form-control', 'placeholder'=>'Enter Mobile Number...','value'=>@$store_branch[0]->contact_number)); ?>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('status'); ?>    
                        <?php echo form_label('Status :');?>
                        <select class="form-control" name="status" id="status">
                            <option value="">Select</option>
                            <option value="Active" <?=(@$store_branch[0]->status == 'Active')?'selected':''?> >Active</option>
                            <option value="Inactive" <?=(@$store_branch[0]->status == 'Inactive')?'selected':''?> >Inactive</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary btn-flat" type="submit" >Submit</button>
                        <a href="<?=base_url()?>adminmaster/" class="btn btn-defauly btn-flat">Cancel</a>
                    </div>    
				<?php echo form_close(); ?>
             </div>
    	</div>
    </div>
</section>    	