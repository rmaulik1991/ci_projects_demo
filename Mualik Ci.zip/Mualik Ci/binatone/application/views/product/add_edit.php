<section class="content-header">
    <h1>
        
        <small>
            <?=($this->router->fetch_method() == 'add')?'Add Brand':'Edit Brand'?>            
        </small>
    </h1>
    <?php
		$this->load->view("/template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">
    	<div class="col-md-6">
    		<div class="box-body">
                 <div id="flash_msg"></div>
                 <?php echo form_open_multipart('',array('name'=>"productFrm",'id'=>"productFrm")); ?>
                    <div class="form-group">
                        <?php echo form_error('product_name'); ?>    
                        <?php echo form_label('Product Name:');?>
                        <?php echo form_input(array('id' => 'product_name', 'name' => 'product_name' , 'class'=>'form-control', 'placeholder'=>'Enter Product Name...','value'=>@$product[0]->product_name)); ?>
                    </div>

                    <div class="form-group">
                        <?php echo form_error('category'); ?>    
                        <?php echo form_label('Category :');?>
                        <select class="form-control" name="category" id="category" onchange="get_subcat();">
                            <option value="">Select</option>
                            <?php foreach($category_list as $row){ ?>
                            <option value="<?php echo $row->id; ?>"><?php echo $row->category_name; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <input type="hidden" name="cat_id_temp" id="cat_id_temp" value="<?php echo @$product[0]->sts_category_id; ?>">
                    <div class="form-group" id="subcat_div">
                        <?php echo form_error('sub_category'); ?>    
                        <?php echo form_label('Sub Category :');?>
                        <select class="form-control" name="sub_category" id="sub_category">
                            <option value=""></option>
                        </select>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('brand_name'); ?>    
                        <?php echo form_label('Brand Name :');?>
                        <select class="form-control" name="brand_name" id="brand_name">
                            <option value="">Select</option>
                            <?php foreach($brand_list as $row){ ?>
                            <option value="<?php echo $row->id; ?>" <?=(@$product[0]->sts_brand_id == $row->id)?'selected':''?> ><?php echo $row->brand_name; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('product_image'); ?>    
                        <?php echo form_label('Product Image:');?>
                        <input id="sample_input" type="hidden" name="product_image">
                        <?php if($this->router->fetch_method() == 'edit' && @$product[0]->product_image!='') { ?>
                        <p><img src="<?php echo base_url(); ?>public/uploads/product/<?php echo @$product[0]->product_image; ?>" width="200" height="200">
                        <?php } ?>
                    </div>
                    <div class="form-group">
                    <?php echo form_label('Product Description:');?>
                    <?php echo form_textarea(array('name' =>'product_desc','id'=>'product_desc','class'=>"ckeditor",'value'=>@$product[0]->product_desc)); ?>
                    
                    </div>
                    <div class="form-group">
                        <?php echo form_error('product_code'); ?>    
                        <?php echo form_label('Product Code:');?>
                        <?php echo form_input(array('id' => 'product_code', 'name' => 'product_code' , 'class'=>'form-control', 'placeholder'=>'Enter Product Code...','value'=>@$product[0]->product_code)); ?>
                    </div>

                    <div class="form-group">
                        <?php echo form_error('status'); ?>    
                        <?php echo form_label('Status :');?>
                        <select class="form-control" name="status" id="status">
                            <option value="">Select</option>
                            <option value="Active" <?=(@$product[0]->status == 'Active')?'selected':''?> >Active</option>
                            <option value="Inactive" <?=(@$product[0]->status == 'Inactive')?'selected':''?> >Inactive</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary btn-flat" type="submit" >Submit</button>
                        <a href="<?=base_url()?>product/" class="btn btn-defauly btn-flat">Cancel</a>
                    </div>    
				<?php echo form_close(); ?>
             </div>
    	</div>
    </div>
</section>
<script>
<?php if($this->router->fetch_method() == 'edit') { ?>
$(document).ready(function() {
    var cat_id=$('#cat_id_temp').val();
    $.ajax({
        type: 'post',
        url: base_path()+'product/get_subcat_edit/'+cat_id,
        success: function (data) {
            if(data!=null){
                if(data['category_list'][0]['pcategory_id']!=0){
                    $("#category").val(data['category_list'][0]['pcategory_id']);
                    get_subcat(cat_id);
                }
                 else{
                    
                     $("#category").val(cat_id);
                     $('#subcat_div').hide();  
                }
        
            }
         }
    });
    });
<?php } ?>
    </script>
    <script>
    $(document).ready(function () {
        $('#sample_input').awesomeCropper(
        { width: 150, height: 150, debug: true }
        );
    });
    </script> 
