<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require ("common/Index_Controller.php");

class storeemp extends Index_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('storeemp_model');
		$this->user_session = $this->session->userdata('user_session');
		is_login();
	}

	public function index() {	
		$data['flash_msg'] = $this->msg_session;		
		$data['view'] = "index";
		$data['store_list']=$this->storeemp_model->selectData(STORE,'*');
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');
	}
	public function get_branch($id){
		header('Content-Type: application/json');
		$where = 'sts_store_id = '.$id;
		$data['branch_list']=$this->storeemp_model->selectData(STORE_BRANCH_TABLE,'*',$where);
		echo json_encode($data);
	}
	public function assign_emp() {
	  	
		$post = $this->input->post();

		if ($post) {	
			$branch_id=$post['branch_name'];		
			$emp_id=$post['emp_id'];
					$where = 'sts_branch_id = '.$branch_id.' and status="Active"';
					$result=$this->storeemp_model->selectData(STORE_EMP_INT,'*',$where);
					if(count($result)>0){
						$data=array('status'=>'Inactive' 
									);
						$ret = $this->storeemp_model->updateData(STORE_EMP_INT,$data,array('sts_branch_id' => $branch_id));
						$where1= 'sts_branch_id = '.$branch_id.' and sts_employee_id='.$emp_id;
						$result1=$this->storeemp_model->selectData(STORE_EMP_INT,'*',$where1);
						if(count($result1)>0){
							$where2 = 'id = '.$result1[0]->id;
							$data=array('status'=>'Active' 
										);
							$ret = $this->storeemp_model->updateData(STORE_EMP_INT,$data,$where2);
						}
						else{
							$data=array('sts_branch_id' =>$branch_id,
									'sts_employee_id' =>$emp_id,
									'status'=>'Active' 
									);
							$ret = $this->storeemp_model->insertData(STORE_EMP_INT, $data);
						}
					}
					else{

						$data=array('sts_branch_id' =>$branch_id,
									'sts_employee_id' =>$emp_id,
									'status'=>'Active' 
									);
						
							$ret = $this->storeemp_model->insertData(STORE_EMP_INT, $data);	
						
						
					}
					/*else{
						$data=array('sts_branch_id' =>$branch_id,
									'sts_employee_id' =>$emp_id,
									'status'=>'Active' 
									);
						$ret = $this->storeemp_model->insertData(STORE_EMP_INT, $data);
					}*/
					if ($ret > 0) {						
						$flash_arr = array('flash_type' => 'success',
										'flash_msg' => 'Store Assigned successfully.'
									);
					}else{
						$flash_arr = array('flash_type' => 'error',
										'flash_msg' => 'An error occurred while processing.'
									);
					}
					$this->session->set_userdata('msg_session',$flash_arr);
					redirect("storeemp/index");
				
				$this->session->set_userdata('msg_session',$flash_arr);
			}	
		$data['flash_msg'] = $this->msg_session;		
		$data['view'] = "index";
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');
	}

	public function ajax_list($limit=0) {
		$post = $this->input->post();
		$columns = array(
			array( 'db' => 'e`.`first_name', 'dt' => 0,'field' => 'first_name' ),
			array( 'db' => 'st`.`store_name', 'dt' => 1,'field' => 'store_name' ),
			array( 'db' => 'sb`.`branch_name', 'dt' => 2,'field' => 'branch_name' ),
			array( 'db' => 'e`.`Id',
					'dt' => 3,
					'formatter' => function( $d, $row ) {
						return '<button class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal" onclick="assign_branch('.$d.')">Assign</button>';
					},'field' => 'Id'
			),
		);
		$join1 = array(STORE_EMP_INT.' as ein','e.id = ein.sts_employee_id and ein.status=e.status','left');
		$join2 = array(STORE_BRANCH_TABLE.' as sb','ein.sts_branch_id = sb.id','left');
		$join3 = array(STORE.' as st','sb.sts_store_id = st.id','left');
		echo json_encode( SSP::simple( $post, EMPLOYEE.' as e', "e.Id", $columns,array($join1,$join2,$join3),"e.status !='Inactive'") );
		exit;
	}

	public function delete() {
		$post = $this->input->post();
		$data=array("status"=>"Inactive");

		if ($post) {
			$ret = $this->storeemp_model->updateData(BRAND_TABLE, $data,array('Id' => $post['id'] ));
			//$ret = $this->storeemp_model->deleteData(ADMIN_MASTER, array('Id' => $post['id'] ));
			if ($ret > 0) {
				echo "success";
				exit;
				#echo success_msg_box('User deleted successfully.');;
			}else{
				echo "error";
				exit;
				#echo error_msg_box('An error occurred while processing.');
			}
		}
	}
}
