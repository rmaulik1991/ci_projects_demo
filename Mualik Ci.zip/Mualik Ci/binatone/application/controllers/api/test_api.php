<?php defined('BASEPATH') OR exit('No direct script access allowed');

class test_api extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('apis_model');
     
    }

    function index()
    {
        
        $this->load->model('apis_model');
        if(isset($_FILES['file']['name']) && !empty($_FILES['file']['name'])){
            $name3=$_FILES['file']['name'];
            $name3=explode('.',$_FILES['file']['name']);
            $_FILES['file']['name']='com_pro_'.time().'.'.$name3[1];
        }
        $config['upload_path'] = './public/uploads/comproduct';
        $config['allowed_types'] = '*'; 
        $this->load->library('upload', $config);                    

        if(isset($_FILES['file']) && $_FILES['file'] != ''){                      
            if ( ! $this->upload->do_upload('file'))
            {
                $error = array('error' => $this->upload->display_errors());
                $this->responseFun($error);
            }
            else
            {
                $data = array('upload_data' => $this->upload->data());
                $this->responseFun($data);                  
            }                           
        }
        if(!isset($data) && empty($data)){
            $ResponseData = array("code" => 402,'message'=>"invalid parameter",'status'=>'error');
            $this->responseFun($ResponseData);  
            exit;
        }
        $insert=$this->apis_model->insertCompetitorProduct($data);
        if($insert == FALSE){
            $ResponseData = array("code" => 402,'message'=>"No data inserted on competitor product",'status'=>'error');
            $this->responseFun($ResponseData);  
        }else{
            $ResponseData = array("code" => 100,'message'=>"Competitor Product recorded",'status'=>'success');
            $this->responseFun($ResponseData);           
        }
        exit;
        
    }

   
    public function insertCompetitorProduct($data){
       
       
        exit;
    }


    public function responseFun($ResponseData)
    {
        $responseData = date("Y-m-d H:i:s")."\nResponse: "."\n".json_encode($ResponseData)."\n\n";
        $file = DOC_ROOT_APPLICATION_PATH.'\controllers\api\response.log';
        $fp = fopen($file, 'a');
        fwrite($fp, $responseData);
        fclose($fp);
        echo json_encode($ResponseData);
    }

}
