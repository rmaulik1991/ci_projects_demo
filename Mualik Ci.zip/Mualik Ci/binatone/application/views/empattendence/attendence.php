<section class="content-header">
    <h1>
        <?= translate('ATTENDENCE_TITLE') ?>
    </h1>
    <?php
		$this->load->view("template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">
    	<div class="col-md-12">
    		<div id="flash_msg">
			</div>
			
            <div id="list">
				<div class="box">
					<div class="box-header">
						<h3 class="box-title"><?php echo $lat_lon[0]->attendance_time.'  Status:'.$lat_lon[0]->attendance_status ?></h3>                                    
					</div><!-- /.box-header -->
					<div class="box-body table-responsive">
						<div id ="map" style="height: 500px" >
					</div><!-- /.box-body -->
				</div><!-- /.box -->
			</div>
    	</div>
    </div>
</section>

<script language="javascript" type="text/javascript">
	var lat=<?php echo $lat_lon[0]->location_lat; ?>;
	var lon=<?php echo $lat_lon[0]->location_lon; ?>;
    var map;
    var geocoder;
    function InitializeMap() {

        var latlng = new google.maps.LatLng(lat, lon);
        
        var myOptions =
        {
            zoom: 18,
            center: latlng,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            //disableDefaultUI: true
        };
        map = new google.maps.Map(document.getElementById("map"), myOptions);
        var marker = new google.maps.Marker({
                    position: latlng,
                    title:"1",
                    visible: true
                });
                marker.setMap(map);
        geocoder = new google.maps.Geocoder();   
}

    window.onload = InitializeMap;

</script>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>