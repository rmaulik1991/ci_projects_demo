
var oTable;
$(document).ready(function()
{
    oTable = $('#privateTable').dataTable( {
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": base_path()+'Privatetender/ajax_list_private/',
            "type": "POST"
        },
        aoColumnDefs: [
          {
             bSortable: false,
             aTargets: [ -1 ]
          }
        ]
    } );

/*--------------- | Step:1 Validation for Genarate Inquiry | ---------------*/

     $('#PrivateTenderDetailsFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
        fields: 
		{
            tender_date: {
                message: 'The Inquiry Date is not valid',
                validators: {
                     notEmpty: {
                        message: 'The Inquiry Date is required and cannot be empty'
                    } 
                }
            }
			,inquiry_no: {
                message: 'The Inquiry No is not valid',
                validators: {
                     notEmpty: {
                        message: 'The Inquiry No is required and cannot be empty'
                    } 
                }
            }
			,company_name: {
                message: 'The Company Name is not valid',
                validators: {
                     notEmpty: {
                        message: 'The Company Name is required and cannot be empty'
                    } 
                }
            }
			,inquiry_generat_from: {
                message: 'The Inquiry Generat Form is not valid',
                validators: {
                     notEmpty: {
                        message: 'The Inquiry Generat Form is required and cannot be empty'
                    } 
                }
            }
            ,mobile_no: {
                message: 'The Mobile No is not valid',
                validators: {
                    stringLength: {
                        min: 10,
                        max: 13,
                        message: 'The Mobile No must be 10 digits'
                    },
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The Mobile No can only number'
                    }
                }
            }
			,mobile_no_2: {
                message: 'The Mobile No is not valid',
                validators: {
                    stringLength: {
                        min: 10,
                        max: 13,
                        message: 'The Mobile No must be 10 digits'
                    },
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The Mobile No can only number'
                    }
                }
            }
			,mobile_no_3: {
                message: 'The Mobile No is not valid',
                validators: {
                    stringLength: {
                        min: 10,
                        max: 13,
                        message: 'The Mobile No must be 10 digits'
                    },
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The Mobile No can only number'
                    }
                }
            }
          
         }
    });
	
	/*--------------- | Step:2 Validation for Proposal Details | ---------------*/

     $('#privatetenderProposalDetailsFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
        fields: 
		{
            total_quot_rate: {
                message: 'The Total Quotation rate is not valid',
                validators: {
                     notEmpty: {
                        message: 'The Total Quotation rate is required and cannot be empty'
                    } 
                }
            }
		}
    });
	
	/*--------------- | Step:7 Validation for Reminder | ---------------*/

     $('#privatereminderDetailsFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
        fields: 
		{
            revised_total_value_pm: {
                message: 'The Revised Total Value PM is not valid',
                validators: {
                     notEmpty: {
                        message: 'The Revised Total Value PM is required and cannot be empty'
                    } 
                }
            }
		}
    });

} );    


// function delete_private_tender(del_id) 
// {
//     bootbox.confirm("Are you sure to delete user?", function(result) {
//         if(result){
//         startLoading();
//         $.ajax({
//             type: 'post',
//             url: base_path()+'privatetender/delete_private_tender',
//             data: 'id='+del_id,
//             success: function (data) {
//                 if (data == "success") {
//                     oTable.fnClearTable(0);
//                     oTable.fnDraw();
//                     $("#flash_msg").html(success_msg_box ('Contract deleted successfully.'));
//                 }else{
//                     $("#flash_msg").html(error_msg_box ('An error occurred while processing.'));
//                 }
//                 stopLoading();
//             }
//         });
//         }
//     });
// }