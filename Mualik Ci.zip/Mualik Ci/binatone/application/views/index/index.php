<!DOCTYPE html>
<html class="bg-black">
    <head>
        <meta charset="UTF-8">
        <title>Store Sales</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- bootstrap 3.0.2 -->
        <link href="<?=public_path()?>css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="<?=public_path()?>css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="<?=public_path()?>css/AdminLTE.css" rel="stylesheet" type="text/css" />

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="bg-black">
        <div class="form-box" id="login-box">
            <div class="header"><?= translate('ADMIN_LOGIN_PAGE_TITLE') ?></div>
            <form action="<?=base_url()?>index" method="post" id="login">
                <div class="body bg-gray">
                    <?php
                        if(@$error_msg['invalid_login'] != ''){
                    ?>
                        <div class="box box-solid box-danger">
                            <div class="box-header">
                                <h3 class="box-title"><?=$error_msg['invalid_login']?></h3>
                                <div class="box-tools pull-right">
                                    <button data-widget="collapse" class="btn btn-danger btn-sm"><i class="fa fa-minus"></i></button>
                                    <button data-widget="remove" class="btn btn-danger btn-sm"><i class="fa fa-times"></i></button>
                                </div>
                            </div>
                        </div>
                    <?php
                        }
                    ?>
                    <div class="form-group <?=(@$error_msg['userid'] != '')?'has-error':'' ?>">
                        <?php
                            if(@$error_msg['userid'] != ''){
                        ?>
                            <label for="inputError" class="control-label"><i class="fa fa-times-circle-o"></i><?=$error_msg['userid']?></label>
                        <?php
                            }
                        ?>
                        <input type="text" name="userid" id="userid" class="form-control" placeholder="User ID" value="<?php echo @$_COOKIE['remember_me_u']; ?>"/>
                    </div>
                    <div class="form-group <?=(@$error_msg['password'] != '')?'has-error':'' ?>">
                        <?php
                            if(@$error_msg['password'] != ''){
                        ?>
                            <label for="inputError" class="control-label"><i class="fa fa-times-circle-o"></i><?=$error_msg['password']?></label>
                        <?php
                            }
                        ?>
                        <input type="password" name="password" id="password" class="form-control" placeholder="Password" value="<?php echo @$_COOKIE['remember_me_pass']; ?>"/>
                    </div>
                    <div class="form-group">
                        <input type="checkbox" name="remember_me" /> <?= translate('ADMIN_LOGIN_REMEMBER_ME') ?>
                    </div>
                </div>
                <div class="footer">
                    <button type="submit" class="btn bg-olive btn-block"><?= translate('ADMIN_LOGIN_SUBMIT_SIGNIN') ?></button>

                    <p><a href="<?=base_url()?>index/forgotpassword"><?= translate('ADMIN_LOGIN_FORGOT_PASSWORD') ?></a></p>

                </div>
            </form>

        </div>


        <!-- jQuery 2.0.2 -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
        <!-- Bootstrap -->
        <script src="<?=public_path()?>js/bootstrap.min.js" type="text/javascript"></script>
        <!-- AdminLTE App -->
        <script src="<?=public_path()?>js/AdminLTE/app.js" type="text/javascript"></script>

    <script>
   $(document).keypress(function(e) {
    if(e.which == 13) {
        $('#login').submit();
    }

    $("#password").on('keyup', function (e) {
    if (e.keyCode == 13) {
        $('#login').submit();
    }
    });
    $("#userid").on('keyup', function (e) {
    if (e.keyCode == 13) {
        $('#login').submit();
    }
    });


});

    </script>
    </body>
</html>
