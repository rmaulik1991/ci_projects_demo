<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require ("common/Index_Controller.php");

class product extends Index_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('product_model');
		$this->user_session = $this->session->userdata('user_session');
		is_login();
	}

	public function index() {	
		$data['flash_msg'] = $this->msg_session;		
		$data['view'] = "index";
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');
	}

	public function ajax_list($limit=0) {
		$post = $this->input->post();
		$columns = array(
			array( 'db' => 'p`.`product_name', 'dt' => 0 ,'formatter' => function( $d, $row )
					{
						return '<a href="'.site_url('/product/edit/'.$row['Id']).'" >'.$row['product_name'].'</a>';
					},'field' => 'product_name'),			
			array( 'db' => 'c`.`category_name',  'dt' => 1,'field' => 'category_name' ),
			array( 'db' => 'b`.`brand_name',  'dt' => 2,'field' => 'brand_name' ),
			array( 'db' => 'p`.`product_code',  'dt' => 3,'field' => 'product_code' ),
			array( 'db' => 'p`.`status','dt'=> 4,'field' => 'status' ),
			array( 'db' => 'p`.Id',
					'dt' => 5,
					'formatter' => function( $d, $row ) {
						return '<a href="javascript:void(0);" onclick="delete_product('.$d.')" class="fa fa-trash-o"></a>';
					},'field' => 'Id'
			),
		);
		$join1 = array(BRAND_TABLE.' as b','p.sts_brand_id = b.id','left');
		$join2 = array(PRODUCT_CATEGORY_TABLE.' as c','p.sts_category_id = c.id','left');
		echo json_encode( SSP::simple( $post, PRODUCT_TABLE.' as p', "p.id", $columns,array($join1,$join2),"p.status !='Inactive'") );
		exit;
	}

	public function add() {
		$post = $this->input->post();
		if ($post) {					
			
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('<label class="form-error-msg"><i class="fa fa-times-circle-o"></i>', '</label><br/>');
			$this->form_validation->set_rules('product_name', 'Product Name', 'trim|required|min_length[2]');
			$this->form_validation->set_rules('brand_name', 'Brand Name', 'trim|required');
			//$this->form_validation->set_rules('product_desc', 'Product Desc', 'trim|required');
			$this->form_validation->set_rules('product_code', 'Product Desc', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			//echo "<pre>".$post['product_desc']; exit();
			if ($this->form_validation->run()) {				
					$flash_arr=0;
					$data=array('product_name'=>$post['product_name']
								,'sts_brand_id'=>$post['brand_name']
								,'product_desc'=>$post['product_desc']
								,'product_code'=>$post['product_code']
								,'status' => $post['status']
						);
					if(isset($post['category'])  && $post['category']!='' && isset($post['sub_category']) && $post['sub_category']!=''){
						$data['sts_category_id']=$post['sub_category'];
					}
					else{
						$data['sts_category_id']=$post['category'];
					}

						$image_base64=$_POST['product_image'];
					  $img = str_replace('data:image/png;base64',"",$image_base64);
					
						if(isset($_POST['product_image']) && $_POST['product_image']!=''){
						$config['upload_path'] = './public/uploads/product/';
						//print_r($config['upload_path'].time().'png'); 
						file_put_contents($config['upload_path'].time().'.png', base64_decode($img));
						$data['product_image']=time().'.png';
						}
					$ret = $this->product_model->insertData(PRODUCT_TABLE, $data);
					
					if ($ret > 0) {						
						$flash_arr = array('flash_type' => 'success',
										'flash_msg' => 'product added successfully.'
									);
					}else{
						$flash_arr = array('flash_type' => 'error',
										'flash_msg' => 'An error occurred while processing.'
									);
					}
					$this->session->set_userdata('msg_session',$flash_arr);
					redirect("product/index");
				}
				$this->session->set_userdata('msg_session',$flash_arr);
			}
			$post=(object)$post;
			$pcategory_id=0;
			$where = 'pcategory_id = '.$pcategory_id;
			$data['admin']=array('0'=>$post);
		$data['category_list'] = $this->product_model->selectData(PRODUCT_CATEGORY_TABLE, '*', $where);
		$data['brand_list'] = $this->product_model->selectData(BRAND_TABLE, '*');
		$data['flash_msg'] = $this->msg_session;
		$data['view'] = "add_edit";
		$data['current_view'] = "add";
		$data['user_role'] = $this->user_session['role'];
		$this->load->view('content', $data);
	}
	
	public function edit($id) {
		if ($id == "" || $id <= 0) {
			redirect('product');
		}

		$where = 'id = '.$id;
		$is_error=0;
		$post = $this->input->post();
		
		if ($post) {			
			
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('<label class="form-error-msg"><i class="fa fa-times-circle-o"></i>', '</label><br/>');
			$this->form_validation->set_rules('product_name', 'Product Name', 'trim|required|min_length[2]');
			$this->form_validation->set_rules('brand_name', 'Brand Name', 'trim|required');
			//$this->form_validation->set_rules('product_desc', 'Product Desc', 'trim|required');
			$this->form_validation->set_rules('product_code', 'Product Desc', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			
			if ($this->form_validation->run()) {				
				
				$data=array('product_name'=>$post['product_name']
								,'sts_brand_id'=>$post['brand_name']
								,'product_desc'=>$post['product_desc']
								,'product_code'=>$post['product_code']
								,'status' => $post['status']
						);
				if(isset($post['category'])  && $post['category']!='' && isset($post['sub_category']) && $post['sub_category']!=''){
						$data['sts_category_id']=$post['sub_category'];
					}
					else{
						$data['sts_category_id']=$post['category'];
					}
					  $image_base64=$_POST['product_image'];
					  $img = str_replace('data:image/png;base64',"",$image_base64);
					
						if(isset($_POST['product_image']) && $_POST['product_image']!=''){
						$config['upload_path'] = './public/uploads/product/';
						//print_r($config['upload_path'].time().'png'); 
						file_put_contents($config['upload_path'].time().'.png', base64_decode($img));
						$data['product_image']=time().'.png';
						}
						/*$config['allowed_types'] = '*'; 
						$this->load->library('upload', $config);					

						if(isset($_FILES['product_image']) && $_FILES['product_image'] != ''){						
							if ( ! $this->upload->do_upload('product_image'))
							{
								$error = array('error' => $this->upload->display_errors());
							}
							else
							{
								$uploaddata = $this->upload->data();
								$data['product_image']=$uploaddata['file_name'];				
							}							
						}*/
					$ret = $this->product_model->updateData(PRODUCT_TABLE, $data, $where);

				if ($ret > 0) {
					$flash_arr = array('flash_type' => 'success',
										'flash_msg' => 'product updated successfully.'
									);
				}else{
					$flash_arr = array('flash_type' => 'error',
										'flash_msg' => 'An error occurred while processing.'
									);
				}
				$this->session->set_userdata('msg_session',$flash_arr);
				redirect("product");
				}
			$this->session->set_userdata('msg_session',$flash_arr);
			}
		
		$data['product'] = $product = $this->product_model->selectData(PRODUCT_TABLE, '*', $where);
		//$data['current_cat'] =$this->product_model->selectcurrentCat(PRODUCT_TABLE, $product[0]->sts_category_id);
		if (empty($product)) {
			redirect('product/index');
		}
		$pcategory_id=0;
			$where = 'pcategory_id = '.$pcategory_id;
		$data['category_list'] = $this->product_model->selectData(PRODUCT_CATEGORY_TABLE, '*', $where);
		$data['brand_list'] = $this->product_model->selectData(BRAND_TABLE, '*');
		$data['flash_msg'] = $this->msg_session;
		$data['view'] = "add_edit";
		$data['current_view'] = "edit";
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');		
	}

	public function delete() {
		$post = $this->input->post();
		$data=array("status"=>"Inactive");

		if ($post) {
			$ret = $this->product_model->updateData(PRODUCT_TABLE, $data,array('Id' => $post['id'] ));
			//$ret = $this->product_model->deleteData(ADMIN_MASTER, array('Id' => $post['id'] ));
			if ($ret > 0) {
				echo "success";
				exit;
				#echo success_msg_box('User deleted successfully.');;
			}else{
				echo "error";
				exit;
				#echo error_msg_box('An error occurred while processing.');
			}
		}
	}

	function get_subcat_edit($id){
		header('Content-Type: application/json');
		$pcategory_id=$id;
			$where = 'id = '.$pcategory_id;
		$data['category_list'] = $this->product_model->selectData(PRODUCT_CATEGORY_TABLE, '*',$where);

		echo json_encode($data);
	}

	public function get_subcat($id){
		header('Content-Type: application/json');
		$pcategory_id=$id;
			$where = 'pcategory_id = '.$pcategory_id;
		$data['category_list'] = $this->product_model->selectData(PRODUCT_CATEGORY_TABLE, '*', $where);

		echo json_encode($data);
	}
}
