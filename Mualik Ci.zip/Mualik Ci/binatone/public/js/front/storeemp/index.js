var oTable;
$(document).ready(function() {
	oTable = $('#storebranchTable').dataTable( {
		"processing": true,
		"serverSide": true,
		"ajax": {
			"url": base_path()+'storeemp/ajax_list/',
			"type": "POST"
		},
		aoColumnDefs: [
		  {
			 bSortable: false,
			 aTargets: [ -1 ]
		  }
		]
    } );

	
	$('#storeFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		 fields: {
            store_name: {
                 message: 'The Store Name is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Store Name is required and cannot be empty'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The firstname can only consist of alphabetical'
                    // }
                }
            },
            branch_name: {
                 message: 'The Store Name is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Store Name is required and cannot be empty'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The firstname can only consist of alphabetical'
                    // }
                }
            }
		 }
    });
} );

function delete_storebranch(del_id) {
bootbox.confirm("Are you sure to delete branch?", function(result) {
	if(result){
	startLoading();
	$.ajax({
		type: 'post',
		url: base_path()+'storebranch/delete',
		data: 'id='+del_id,
		success: function (data) {
			if (data == "success") {
				oTable.fnClearTable(0);
				oTable.fnDraw();
				$("#flash_msg").html(success_msg_box ('Store deleted successfully.'));
			}else{
				$("#flash_msg").html(error_msg_box ('An error occurred while processing.'));
			}
			stopLoading();
		}
	});
	}
	});
}

function assign_branch(id){
   if(id!=''){
   $('#emp_id').val(id);
    }
    else{
        $('#emp_id').val(0);
    }
}

function get_branch() {
    var store_id=$('#store_name').val();
    $('#branch_name')
    .find('option')
    .remove()
    .end()
    .append('<option value="">Select</option>');
    $.ajax({
        type: 'post',
        url: base_path()+'storeemp/get_branch/'+store_id,
        success: function (data) {
            if(data['branch_list']!=''){
            var i=0;
             $.each(data['branch_list'], function(id, category_name) {
                $('#branch_name').append("<option value='" +data['branch_list'][i]['id'] + "'>" + data['branch_list'][i]['branch_name'] + "</option>");
                i++;
            });
         }
        }
    });
    
}