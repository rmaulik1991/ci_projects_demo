var oTable;
$(document).ready(function() {

	oTable = $('#serviceTable').dataTable({
		"processing": true,
		"serverSide": true,
		"ajax": {
			"url": base_path()+'service/ajax_list/',
			"type": "POST"
		},
		aoColumnDefs: [
		  {
			 bSortable: false,
			 aTargets: [ -1 ]             
		  }
		]
	});
	
$('#serviceFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		 fields: {
            service_name: {
                 message: 'The Service Name is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Service Name is required and cannot be empty'
                    },
                    stringLength: {
                        min: 2,
                        max: 30,
                        message: 'The Service Name must be more than 2 and less than 30 characters long'
                    },
                    regexp: {
                        regexp: /^[a-zA-Z]+$/,
                        message: 'The Service Name can only consist of alphabetical'
                    }
                }
            },
            service_type: {
                validators: {
                    notEmpty: {
                        message: 'The Service Type is required and cannot be empty'
                    }
                }
            },
                       
            duration: {
                message: 'The duration no is not valid',
                validators: {
                    notEmpty: {
                        message: 'The duration no is required and cannot be empty'
                    },
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The duration no can only number'
                    }
                }
            },
            duration_type: {
                validators: {
                    notEmpty: {
                        message: 'The Duration Type is required and cannot be empty'
                    }
                }
            },
            licence_type: {
                validators: {
                    notEmpty: {
                        message: 'The Licence Type is required and cannot be empty'
                    }
                }
            },		
			licence_duration: {
                message: 'The Licence Duration no is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Licence Duration no is required and cannot be empty'
                    },
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The Licence Duration no can only number'
                    }
                }
            },
            licence_duration_type: {
                validators: {
                    notEmpty: {
                        message: 'The Licence Duration Type is required and cannot be empty'
                    }
                }
            },	
            status: {
                message: 'The status is not valid',
                validators: {
                    notEmpty: {
                        message: 'The status is required and cannot be empty'
                    }
                }
            }            
		 }
    });
} );

function delete_service (del_id) 
{
	bootbox.confirm("Are you sure to delete Service?", function(result)
	{
		if(result)
		{
			startLoading();
			$.ajax({
			type: 'post',
			url: base_path()+'service/delete',
			data: 'id='+del_id,
			success: function (data) 
			{
				if (data == "success") 
				{
					oTable.fnClearTable(0);
					oTable.fnDraw();
					$("#flash_msg").html(success_msg_box ('Admin deleted successfully.'));
				}
				else
				{
					$("#flash_msg").html(error_msg_box ('An error occurred while processing.'));
				}
				stopLoading();
			}
			});
		}
	});
}

$(document).on('click','.status_checks',function(e)
{
	var id = $(this).attr('ser_id');
  	var status = ($(this).hasClass("btn-success")) ? 'Active' : 'Inactive';
 	var msg = (status=='Active')? 'Inactive' : 'Active';
 	
	bootbox.confirm("Are you sure to chnage status?", function(result)
	{
		if(result)
		{
			$.ajax({
			type: 'post',
			url: base_path()+'service/statuschange',
			data: {id:id,status:status},
			success: function (data) 
			{
				if(data == 'success')
				{
					$('#ser_suc'+id).text(msg);
					if(status == 'Active')
					{
						$('#ser_suc'+id).removeClass('btn btn-success status_checks').addClass('btn btn-danger status_checks');
					}
					else
					{
						$('#ser_suc'+id).removeClass('btn btn-danger status_checks').addClass('btn btn-success status_checks');	
					}
				}
			}

			});
		}
	});
});


