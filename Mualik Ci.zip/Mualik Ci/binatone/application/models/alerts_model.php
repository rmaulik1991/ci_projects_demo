<?php
class alerts_model extends CI_Model{
		var $table;
	public function  __construct(){
		parent::__construct();
		$this->load->database();
		//$this->table ='admin_master';
	}


	/*
	| -------------------------------------------------------------------
	| Select data
	| -------------------------------------------------------------------
	|
	| general function to get result by passing nesessary parameters
	|
	*/
	public function selectData($start_date,$end_date)
	{
		$query=$this->db->select('ssb.branch_name,st.store_name,sp.product_name,sdt.added_date,sds.symbol')
		->from('sts_display_tracker as sdt','left')
		->join('sts_store_branch as ssb','sdt.sts_store_branch_id=ssb.id', 'left')
		->join('sts_store as st','ssb.sts_store_id=st.id', 'left')
		->join('sts_product as sp','sdt.sts_product_id=sp.id', 'left')
		->join('sts_display_status as sds','sdt.sts_display_status_id=sds.id', 'left')
		->where('sdt.added_date BETWEEN "'.$start_date.'" AND "'.$end_date.'"')
		->where("(sdt.sts_display_status_id=1 OR sdt.sts_display_status_id=2)")
		->group_by('sp.product_name')
		->group_by('sdt.added_date')
		->group_by('ssb.branch_name')
		->get();

		/*$sql="select ssb.branch_name,st.store_name,sp.product_name,sdt.added_date,sds.symbol from sts_display_tracker as sdt left join sts_store_branch as ssb on sdt.sts_store_branch_id=ssb.id left join sts_store as st on ssb.sts_store_id=st.id left join sts_product as sp on sdt.sts_product_id=sp.id left join sts_display_status as sds on sdt.sts_display_status_id=sds.id where sdt.added_date BETWEEN '2017-11-01' AND '2017-11-30' and (sdt.sts_display_status_id='1' OR sdt.sts_display_status_id='2') group by sp.product_name,sdt.added_date,ssb.branch_name";*/
		//$query= $this->db->query($sql);
		//echo $this->db->last_query();exit();
		$alldata = $query->result_array();
		$myexcel=array();
		foreach ($alldata as $key => $value) {
			//$date[$i++]=date('M d' ,strtotime($value['added_date']));
			$myexcel[$value['store_name']][$value['branch_name']][]=array($value['product_name'],$value['added_date'],$value['symbol']);
		}
		return $myexcel; //echo '<pre>';print_r($myexcel);exit();
	}
	function selectEmpsales($sel_date){
		$sql="select emp.first_name,sdst.added_date,ssb.branch_name,st.store_name from sts_employee as emp left join sts_daily_sales_tracker as sdst on emp.id=sdst.sts_employee_id and sdst.added_date='".$sel_date."' left join sts_store_employee_int as ssei on emp.id=ssei.sts_employee_id and ssei.status='Active' left join sts_store_branch as ssb on ssei.sts_branch_id=ssb.id left join sts_store as st on ssb.sts_store_id=st.id where st.store_name IS NOT NULL and sdst.added_date IS NULL group by emp.first_name";
		$query=$this->db->query($sql);
		//echo $this->db->last_query(); exit();
		return $query->result();
	}
	function selectEmpdisplay($sel_date){
		$sql="select emp.first_name,sdt.added_date,ssb.branch_name,st.store_name from sts_employee as emp left join sts_display_tracker as sdt on emp.id=sdt.sts_employee_id and sdt.added_date='".$sel_date."' left join sts_store_employee_int as ssei on emp.id=ssei.sts_employee_id and ssei.status='Active' left join sts_store_branch as ssb on ssei.sts_branch_id=ssb.id left join sts_store as st on ssb.sts_store_id=st.id where st.store_name IS NOT NULL and sdt.added_date IS NULL group by emp.first_name";
		$query=$this->db->query($sql);
		//echo $this->db->last_query(); exit();
		return $query->result();
	}
}
?>
