<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Apis_model extends CI_Model
{

/*
Login Api
*/
    public function api_login($identity, $password)
    {
       

        if (empty($identity) || empty($password)) {
            return FALSE;
        }
   
        $query = $this->db->select('id,first_name,last_name,username,email,contact_number as mobile')
        ->where("username",$identity)
        ->where("password",sha1(trim($password)))
        ->where("status","Active")
        ->limit(1)
        ->get('sts_employee');
       // echo $this->db->last_query();exit;
        if ($query->num_rows() === 1) {
            $user = $query->row();
            /*$name=$user->first_name." ".$user->last_name;
            $user->name=$name;
            return $user;*/
            $query = $this->db->select('b.branch_name,b.latitude,b.longitude,b.address,b.contact_person,b.contact_number,s.store_name,s.contact_person as store_contact_person,s.contact_number as store_contact_number')
            ->from('sts_store_branch as b')
            ->join('sts_store_employee_int as sei','sei.sts_branch_id=b.id and sei.status="Active"')
            ->join('sts_store as s','s.id=sei.id')
            ->where("sei.sts_employee_id",$user->id)
            ->where("b.status","Active")
            ->get();
            $branch = $query->row();
           
            $query = $this->db->select('id,first_name,last_name,username,
                email,contact_number as mobile,r.role_code,r.role_id')
            ->from('sts_employee')
            ->join('sts_role_master as r','r.role_id=sts_employee.sts_role_id')
            ->where("id",$user->id)
            ->where("sts_employee.status","Active")
            ->limit(1)
            ->get();
    
        
        if ($query->num_rows() === 1) {
            $user = $query->row();
            $name=$user->first_name." ".$user->last_name;
            $user->name=$name;
            $branchDetail=array();
            if(isset($branch) && !empty($branch)){
              $branchDetail=array("code" => 100,'message'=>"branch detail",'status'=>'success','data'=>$branch);
            }else{
              $branchDetail=array("code" => 402,'message'=>"no any branch define to this user",'status'=>'error');  
            }
           $user->branchDetail=$branchDetail; 
           
            return $user;
          
        }
          
        }

        
       
        return FALSE;
    }

/*
Get Category Api
*/
    public function getCategory()
    {
       

        $query = $this->db->select('id,category_name')
        //->where("pcategory_id",'0')
        ->where("status","Active")
        ->get('sts_category');
    
        //echo $this->db->last_query();exit;
        if ($query->num_rows() > 0) {
            $category = $query->result();
            return $category;
          
        }
       
        return FALSE;
    }

/*
Get Product Api
*/
    public function getProduct($user_id)
    {
        
        $path=base_path()."public/uploads/product/";
        //echo $path;exit;
        $query = $this->db->select('sts_branch_id')
        ->where("sts_employee_id",$user_id)
        ->where("status","Active")
        ->limit(1)
        ->get('sts_store_employee_int');
        $product1 = $query->row();
        //print_r($product1);exit;
        $i=0;
        $dataSendArray = array();
        $notInProductId = array();
        if(isset($product1) && !empty($product1))
        {
            $query = $this->db->select('p.*,sb.brand_name')
            ->from('sts_product as p')
            ->join('sts_brand as sb', 'sb.id=p.sts_brand_id')
            ->join('sts_store_product_int as spi', 'spi.sts_product_id=p.id')
            ->where("spi.sts_branch_id",$product1->sts_branch_id)
            ->where("p.status","Active")
            ->get();
            $product = $query->result_array();

            if(isset($product) && !empty($product)){
                foreach ($product as $key => $value) {
                    $dataSendArray[$i]=$value;
                    $dataSendArray[$i]['product_image']="";
                    if(isset($value['product_image']) && !empty($value['product_image']))
                    {
                        $dataSendArray[$i]['product_image'] = $path.$value['product_image'];
                    }
                    $dataSendArray[$i++]['in_branch'] = true;
                    $notInProductId[]=$value['id'];
                }

                $query = $this->db->select('p.*,sb.brand_name')
                ->from('sts_product as p')
                ->join('sts_brand as sb', 'sb.id=p.sts_brand_id')
                ->where_not_in("p.id ",$notInProductId)
                ->where("p.status","Active")
                ->get();
                $product2 = $query->result_array();
               
                if(isset($product2) && !empty($product2)){
                    foreach ($product2 as $key => $value) {
                        $dataSendArray[$i]=$value;
                        $dataSendArray[$i]['product_image']="";
                        if(isset($value['product_image']) && !empty($value['product_image']))
                        {
                            $dataSendArray[$i]['product_image'] = $path.$value['product_image'];
                        }
                        $dataSendArray[$i++]['in_branch'] = false;
                    }
                    
                    return $dataSendArray;    
                }else{
                    return $dataSendArray;
                }
                return FALSE;
                
            }else{
                $query = $this->db->select('p.*,sb.brand_name')
                ->from('sts_product as p')
                ->join('sts_brand as sb', 'sb.id=p.sts_brand_id')
                ->where("p.status","Active")
                ->get();
                $product2 = $query->result_array();
                if(isset($product2) && !empty($product2)){
                    foreach ($product2 as $key => $value) {
                        $dataSendArray[$i]=$value;
                        $dataSendArray[$i]['product_image']="";
                        if(isset($value['product_image']) && !empty($value['product_image']))
                        {
                            $dataSendArray[$i]['product_image'] = $path.$value['product_image'];
                        }
                        $dataSendArray[$i++]['in_branch'] = false;
                    }
                
                    return $dataSendArray;    
                }
                return FALSE;
                }
           
            
              
        }else{
             
            $query = $this->db->select('p.*,sb.brand_name')
            ->from('sts_product as p')
            ->join('sts_brand as sb', 'sb.id=p.sts_brand_id')
            ->where("p.status","Active")
            ->get();
            $product2 = $query->result_array();
            if(isset($product2) && !empty($product2)){
                foreach ($product2 as $key => $value) {
                    $dataSendArray[$i]=$value;
                    $dataSendArray[$i]['product_image']="";
                    if(isset($value['product_image']) && !empty($value['product_image']))
                    {
                        $dataSendArray[$i]['product_image'] = $path.$value['product_image'];
                    }
                    $dataSendArray[$i++]['in_branch'] = false;
                }
            
                return $dataSendArray;    
            }
            return FALSE;
        }    
    }
        
/*
Get Brand Api
*/
    public function getBrand()
    {
       

        $query = $this->db->select('id,brand_name')
        ->where("status","Active")
        ->get('sts_brand');
    
        //echo $this->db->last_query();exit;
        if ($query->num_rows() > 0) {
            $brand = $query->result();
            return $brand;
          
        }
       
        return FALSE;
    }

/*
Insert Display Status Api
*/

    public function insertDisplayStatus($data)
    {
        $table="sts_display_tracker";
        $query = $this->db->select('sts_branch_id')
        ->where("sts_employee_id",$data['user_id'])
        ->get('sts_store_employee_int');
        $branch_id = $query->row_array();
        
        $insert=array(
            "sts_store_branch_id"=>$branch_id['sts_branch_id'],
            "sts_product_id"=>$data['sts_product_id'],
            "sts_display_status_id"=>$data['sts_display_status_id'],
            "sts_employee_id"=>$data['user_id'],
            "added_date"=>$data['date']

        );
        
        $result = $this->db->insert($table, $insert);
         // echo "<pre>";
         // print_r($result);exit();
        if($result == 1){
            return $this->db->insert_id();
        }

        return FALSE;
        
    }
    
/*
Insert Sales Status Api
*/

    public function insertSalesStatus($data)
    {
        $table="sts_daily_sales_tracker";

        $query = $this->db->select('sts_branch_id')
        ->where("sts_employee_id",$data['user_id'])
        ->get('sts_store_employee_int');
        $branch_id = $query->row_array();
       // print_r($branch_id);exit;
        if($branch_id)
        {
            $checkSales = $this->db->select()
            ->where("sts_employee_id",$data['user_id'])
            ->where("sts_store_branch_id",$branch_id['sts_branch_id'])
            ->where("sts_product_id",$data['sts_product_id'])
            ->where("added_date",$data['date'])
            ->limit(1)
            ->get($table);
            $result = $checkSales->row_array();
         
            $insert=array(
                "sts_store_branch_id"=>$branch_id['sts_branch_id'],
                "sts_product_id"=>$data['sts_product_id'],
               // "qty"=>$data['qty'],
                "sts_employee_id"=>$data['user_id'],
                "added_date"=>$data['date']

            );

            if ($checkSales->num_rows() === 1) {
                $insert['qty']=$data['qty']+$result['qty'];
                $this->db->where('id',$result['id']);
                $this->db->update($table,$insert);
                return TRUE;
            }else{
               // echo $data['qty'];exit;
                $insert['qty']=$data['qty'];
                $result = $this->db->insert($table, $insert);
                if($result == 1){
                    return $this->db->insert_id();
                }
            }
        }

        return FALSE;
        
    }
    
/*
Get User Profile Api
*/

    public function getProfile($userID)
    {
       

        if (empty($userID)) {
            return FALSE;
        }

        $query = $this->db->select('b.branch_name,
            b.address,b.contact_person,b.contact_number,s.store_name,s.contact_person as store_contact_person,s.contact_number as store_contact_number')
        ->from('sts_store_branch as b')
        ->join('sts_store_employee_int as sei','sei.sts_branch_id=b.id and sei.status="Active"')
        ->join('sts_store as s','s.id=sei.id')
        ->where("sei.sts_employee_id",$userID)
        ->where("b.status","Active")
        ->get();
        $branch = $query->row();
       
        $query = $this->db->select('id,first_name,last_name,username,
            email,contact_number as mobile')
        ->from('sts_employee')
        ->where("id",$userID)
        ->where("status","Active")
        ->limit(1)
        ->get();
    
        
        if ($query->num_rows() === 1) {
            $user = $query->row();
            $name=$user->first_name." ".$user->last_name;
            $user->name=$name;
            $branchDetail=array();
            if(isset($branch) && !empty($branch)){
              $branchDetail=array("code" => 100,'message'=>"branch detail",'status'=>'success','data'=>$branch);
            }else{
              $branchDetail=array("code" => 402,'message'=>"no any branch define to this user",'status'=>'error');  
            }
           $user->branchDetail=$branchDetail; 
           
            return $user;
          
        }
        
        return FALSE;
    }

/*
Insert Competitor Product Api
*/

    public function insertCompetitorProduct($data,$filename=0)
    {
        $table="sts_competitor_product";
        $query = $this->db->select('sts_branch_id')
        ->where("sts_employee_id",$data['user_id'])
        ->get('sts_store_employee_int');
        $branch_id = $query->row_array();
        
        $insert=array(
            "sts_employee_id"=>$data['user_id'],
            "sts_branch_id"=>$branch_id['sts_branch_id'],
            "is_own_product"=>$data['is_own_product'],
            "image"=>$filename,
            "product_detail"=>$data['description']

        );
        if($data['product_id']==NULL){
        $insert['sts_product_id']=0;
        }
        else{
        $insert['sts_product_id']=$data['product_id'];
        }
        $result = $this->db->insert($table, $insert);
         // echo "<pre>";
         // print_r($result);exit();
        if($result == 1){
            return $this->db->insert_id();
        }

        return FALSE;
        
    }

    /*
Insert Product Display Api
*/

    public function insertProductDisplay($data,$filename=0)
    {
        $table="sts_display_product";
        $query = $this->db->select('sts_branch_id')
        ->where("sts_employee_id",$data['user_id'])
        ->get('sts_store_employee_int');
        $branch_id = $query->row_array();
        
        $insert=array(
            "sts_employee_id"=>$data['user_id'],
            "sts_branch_id"=>$branch_id['sts_branch_id'],
            "is_own_product"=>$data['is_own_product'],
            "image"=>$filename,
            "product_detail"=>$data['description'],
            "status"=>'Pending'

        );
        if($data['product_id']==NULL){
        $insert['sts_product_id']=0;
        }
        else{
        $insert['sts_product_id']=$data['product_id'];
        }
        $result = $this->db->insert($table, $insert);
         // echo "<pre>";
         // print_r($result);exit();
        if($result == 1){
            return $this->db->insert_id();
        }

        return FALSE;
        
    }

        /*
Insert Attendance Api
*/

    public function insertAttendance($data)
    {    
        $table="sts_employee_attendance";
        $insert=array(
            "sts_employee_id"=>$data['user_id'],
            "location_lat"=>$data['latitude'],
            "location_lon"=>$data['longitude'],
            "attendance_status"=>$data['status']

        );
        $result = $this->db->insert($table, $insert);
         // echo "<pre>";
         // print_r($result);exit();
        if($result == 1){
            return $this->db->insert_id();
        }

        return FALSE;
        
    }

    /*
    Get Product Details
    */

    public function getProductDetails($data){
        $query = $this->db->select('id,product_desc')
        ->where("id",$data['product_id'])
        ->where("status","Active")
        ->get('sts_product');
    
        //echo $this->db->last_query();exit;
        if ($query->num_rows() > 0) {
            $product_desc = $query->result();
            return $product_desc;
          
        }
       
        return FALSE;
    }

     /*
    Get Product Details
    */

    public function insert_order($data){
        $this->db->insert('sts_order',$data);
       $query = $this->db->insert_id();
        if ($query > 0) {
            return $query;
        }
       
        return FALSE;
    }

    /*
    Change password
    */

    public function changepassword($data){
       $query = $this->db->select('id,first_name,last_name,username,email,contact_number as mobile')
        ->where("id",$data['user_id'])
        ->where("password",sha1(trim($data['old_password'])))
        ->where("status","Active")
        ->limit(1)
        ->get('sts_employee');
       // echo $this->db->last_query();exit;
        if ($query->num_rows() === 1) {
            $this->db->set('password', sha1(trim($data['new_password']))); 
            $this->db->where('id', $data['user_id']); 
            $this->db->update('sts_employee'); 
            return TRUE;
        }
        else{
            return FALSE;
        }
    }
    

}
