<?php
$this->load->view('template/header');
$this->load->view('template/nav_bar');
$this->load->view('template/middle');
$this->load->view('template/footer');
?>