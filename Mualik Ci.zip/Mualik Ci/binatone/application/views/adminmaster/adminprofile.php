<section class="content-header">
    <h1>
        <?= translate('ADMIN_MASTER_PROFILE') ?>
    </h1>
    <?php
		//$this->load->view("template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">
    	<div class="col-md-12">
    		<div id="flash_msg">
			</div>
			<?php //if(accessControl('users','add',$this->user_session['role'])){ ?>
    		<!-- <a class="btn btn-default pull-right" href="<?php echo base_path()?>adminmaster/adminprofileedit">
            <i class="fa fa-plus"></i>&nbsp;<?= translate('ADMIN_BUTTON_PROFILE_EDIT') ?></a> -->
			<?php //} ?>
            <div id="list">
				<div class="box">
					<div class="box-header">
						<h3 class="box-title"><?= translate('ADMIN_LABLE_MASTER_PROFILE') ?></h3>                                    
					</div><!-- /.box-header -->
					<div class="box-body table-responsive">
					<table>
						<tr>
							<th>Name:</th> 
							<td><?php echo $user[0]->first_name.' '.$user[0]->last_name; ?></td>						
						</tr>
						<tr>
							<th>User Name:</th>
							<td><?php echo $user[0]->username; ?></td>
						</tr>
						<tr>
							<th>Email Id:</th> 
							<td><?php echo $user[0]->email; ?></td>
						</tr>
						<tr>
							<th>Mobile Number:</th> 
							<td><?php echo $user[0]->contact_number; ?></td>
						</tr>
						<tr>
							<th>Address:</th> 
							<td><?php echo $user[0]->address; ?></td>
						</tr>
					</table>
					</div><!-- /.box-body -->
				</div><!-- /.box -->
			</div>
    	</div>
    </div>
</section>