<section class="content-header">
    <h1>
        <?= translate('CATEGORY_MASTER_TITLE') ?>
    </h1>
    <?php
		$this->load->view("template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">

    	<div class="col-md-12">
    		
			   
    		<div id="flash_msg">
			</div>
			<?php //if(accessControl('users','add',$this->user_session['role'])){ ?>
    		<a class="btn btn-default pull-right" href="<?php echo base_path()?>category/add">
            <i class="fa fa-plus"></i>&nbsp;<?= translate('CATEGORY_BUTTON_ADD'); ?></a>
			<?php //} ?>
            <div id="list">
				<div class="box">
					<div class="box-header">
						<h3 class="box-title"><?= translate('CATEGORY_MASTER_TITLE') ?></h3>

						 <div class="col-md-7 " style="padding: 40px 0px 10px 10px;">
						 	<?php echo form_label('Select Category Name');?>
							<select class="form-control" name="category_name" id="category_name">
                                <option value="0">Select category</option>
                                <?php 
                                foreach (@$category as $key=>$value){
                                ?>
                                    <option value="<?php echo $value->id;?>"><?php echo $value->category_name;?></option>    

                                <?php
                                }?>
                              
                            </select>
						</div>                                
					</div><!-- /.box-header -->
					
					<div class="box-body table-responsive">
						<table id="categoryTable" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>Category Name</th>
									<th>Status</th> 
									<th>Action</th>
								</tr>
							</thead>
						</table>
					</div><!-- /.box-body -->
				</div><!-- /.box -->
			</div>
    	</div>
    </div>
</section>

<script type="text/javascript">
	$(document).ready(function(){
		oTable = $('#categoryTable').dataTable();
		$('#category_name').on("change",function(){
	    	
	    	$('#categoryTable').DataTable().destroy();
	    	var id=$(this).val();
	    	
	    	if(id!=0){
	    		
	    		 	oTable = $('#categoryTable').dataTable( {
				        "processing": true,
				        "serverSide": true,
				        "ajax": {
				            "url": base_path()+'category/ajax_list/'+id,
				            "type": "POST"
				        },
				        aoColumnDefs: [
				          {
				             bSortable: false,
				             aTargets: [ -1 ]
				          }
				        ]
				    } );
	    	}else{
	    		
	    		oTable = $('#categoryTable').dataTable();
	    	}
	    	
	   
	    });
	});
    
    

</script>