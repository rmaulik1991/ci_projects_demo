-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 01, 2018 at 12:21 PM
-- Server version: 5.6.14
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `store_sales`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_master`
--

CREATE TABLE IF NOT EXISTS `admin_master` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `Role` enum('Admin','Super Admin') NOT NULL,
  `Mobile1` varchar(15) NOT NULL,
  `Mobile2` varchar(15) DEFAULT NULL,
  `Email1` varchar(150) NOT NULL,
  `Email2` varchar(150) DEFAULT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(150) NOT NULL,
  `EmailNotification` enum('Yes','No') NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdatedDate` datetime NOT NULL,
  `status` enum('Active','Inactive','Deleted') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='This table is for admin users ' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `admin_master`
--

INSERT INTO `admin_master` (`Id`, `FirstName`, `LastName`, `Role`, `Mobile1`, `Mobile2`, `Email1`, `Email2`, `UserName`, `Password`, `EmailNotification`, `CreatedDate`, `UpdatedDate`, `status`) VALUES
(1, 'admin', '', 'Super Admin', '', NULL, 'test@parextech.com', NULL, 'admin', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'No', '2017-07-10 07:12:00', '0000-00-00 00:00:00', 'Active'),
(2, 'Admin', 'Admin', 'Super Admin', '9913815322', '9913815322', 'gopal@parex.com', 'gopal@parex.com', 'admin123', '4498afcfaaa0306ed48a244cb7dbde7f5da78603', 'No', '2017-11-27 01:47:27', '2017-11-27 07:17:27', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `sts_brand`
--

CREATE TABLE IF NOT EXISTS `sts_brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(100) NOT NULL,
  `brand_desc` text NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `sts_brand`
--

INSERT INTO `sts_brand` (`id`, `brand_name`, `brand_desc`, `status`, `create_date`, `update_date`) VALUES
(1, 'Nokia', 'Nokia mobile', 'Active', '2017-12-01 04:59:35', '0000-00-00 00:00:00'),
(2, 'Samsung', 'Samsung mobile,tv', 'Active', '2017-12-01 05:00:01', '0000-00-00 00:00:00'),
(3, 'Woodland', 'Woodland shoes brand', 'Active', '2017-12-01 05:00:26', '2018-01-31 11:45:40'),
(4, 'Apple', 'Apple mobile', 'Active', '2017-12-01 05:30:18', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `sts_category`
--

CREATE TABLE IF NOT EXISTS `sts_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pcategory_id` int(10) NOT NULL DEFAULT '0',
  `category_name` varchar(100) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `sts_category`
--

INSERT INTO `sts_category` (`id`, `pcategory_id`, `category_name`, `status`, `create_date`, `update_date`) VALUES
(1, 0, 'TV', 'Active', '2017-12-01 05:11:20', '0000-00-00 00:00:00'),
(2, 0, 'Mobile', 'Active', '2017-12-01 05:11:39', '0000-00-00 00:00:00'),
(3, 0, 'Shoes', 'Active', '2017-12-01 05:12:07', '0000-00-00 00:00:00'),
(4, 1, 'Panasonic', 'Active', '2017-12-01 05:12:40', '0000-00-00 00:00:00'),
(5, 1, 'Samsung', 'Active', '2017-12-01 05:13:07', '0000-00-00 00:00:00'),
(6, 1, 'Sony', 'Active', '2017-12-01 05:13:23', '2018-01-31 11:46:38'),
(7, 2, 'Apple', 'Active', '2017-12-01 05:13:43', '0000-00-00 00:00:00'),
(8, 2, 'Sony', 'Active', '2017-12-01 05:13:57', '0000-00-00 00:00:00'),
(9, 2, 'HTC', 'Active', '2017-12-01 05:14:15', '0000-00-00 00:00:00'),
(10, 2, 'Nokia', 'Active', '2017-12-01 05:14:26', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `sts_competitor_product`
--

CREATE TABLE IF NOT EXISTS `sts_competitor_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sts_employee_id` int(10) NOT NULL,
  `sts_product_id` int(10) NOT NULL,
  `sts_branch_id` int(11) NOT NULL,
  `is_own_product` enum('Yes','No') NOT NULL,
  `image` varchar(250) NOT NULL,
  `product_detail` text NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `sts_competitor_product`
--

INSERT INTO `sts_competitor_product` (`id`, `sts_employee_id`, `sts_product_id`, `sts_branch_id`, `is_own_product`, `image`, `product_detail`, `create_date`, `update_date`) VALUES
(1, 1, 2, 1, '', 'com_pro_1512467236.jpeg', 'test desc', '2017-12-05 09:47:19', '0000-00-00 00:00:00'),
(2, 1, 2, 1, '', 'com_pro_1512467242.jpeg', 'test desc', '2017-12-05 09:47:26', '0000-00-00 00:00:00'),
(3, 1, 2, 1, 'Yes', 'com_pro_1512467710.jpeg', 'test desc', '2017-12-05 09:55:13', '0000-00-00 00:00:00'),
(4, 1, 2, 1, 'Yes', 'com_pro_1512467894.jpeg', 'test desc', '2017-12-05 09:58:18', '0000-00-00 00:00:00'),
(5, 1, 0, 1, 'Yes', 'com_pro_1512468016.jpeg', 'test desc', '2017-12-05 10:00:19', '0000-00-00 00:00:00'),
(6, 1, 0, 1, 'No', 'com_pro_1512473186.jpeg', 'okokokkkk', '2017-12-05 11:26:30', '0000-00-00 00:00:00'),
(7, 1, 0, 1, 'Yes', 'com_pro_1512473264.jpeg', 'from compttr', '2017-12-05 11:27:48', '0000-00-00 00:00:00'),
(8, 1, 0, 1, 'No', 'com_pro_1512473436.jpeg', 'from compttr', '2017-12-05 11:30:40', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `sts_daily_sales_tracker`
--

CREATE TABLE IF NOT EXISTS `sts_daily_sales_tracker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sts_store_branch_id` int(10) NOT NULL,
  `sts_product_id` int(10) NOT NULL,
  `sts_employee_id` int(10) NOT NULL,
  `qty` varchar(100) NOT NULL,
  `added_date` date NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `sts_daily_sales_tracker`
--

INSERT INTO `sts_daily_sales_tracker` (`id`, `sts_store_branch_id`, `sts_product_id`, `sts_employee_id`, `qty`, `added_date`, `create_date`) VALUES
(1, 1, 2, 1, '72', '2017-11-30', '2017-12-01 05:50:57'),
(2, 1, 2, 1, '61', '2017-12-02', '2017-12-01 05:51:39'),
(3, 1, 2, 1, '40', '2017-11-01', '2017-12-01 06:18:53'),
(4, 1, 2, 1, '10', '2017-11-03', '2017-12-01 06:19:04'),
(5, 1, 2, 1, '10', '2017-11-02', '2017-12-01 06:19:10'),
(6, 1, 2, 1, '10', '2017-11-04', '2017-12-01 06:19:20'),
(7, 1, 2, 1, '10', '2017-11-05', '2017-12-01 06:19:32'),
(8, 1, 2, 1, '10', '2017-11-07', '2017-12-01 06:19:41'),
(9, 1, 2, 1, '10', '2017-11-08', '2017-12-01 06:19:49'),
(10, 1, 2, 1, '10', '2017-11-09', '2017-12-01 06:19:54'),
(11, 1, 2, 1, '10', '2017-11-10', '2017-12-01 06:19:58'),
(12, 1, 2, 1, '10', '2017-11-11', '2017-12-01 06:20:03'),
(13, 1, 2, 1, '39', '2017-12-01', '2017-12-01 07:24:58'),
(14, 1, 1, 1, '157', '2017-12-01', '2017-12-01 12:22:24'),
(16, 1, 3, 1, '14', '2017-11-01', '2017-12-01 13:21:26'),
(17, 1, 1, 1, '1', '2017-11-30', '2017-12-01 13:33:37'),
(18, 1, 4, 1, '6', '2017-12-01', '2017-12-01 14:06:23'),
(19, 1, 2, 1, '13', '2017-12-04', '2017-12-04 05:17:35'),
(20, 1, 1, 1, '6', '2017-12-04', '2017-12-04 06:35:02'),
(21, 1, 5, 1, '9', '2017-12-04', '2017-12-04 06:36:21'),
(22, 1, 3, 1, '6', '2017-12-04', '2017-12-04 06:42:53'),
(23, 1, 4, 1, '33', '2017-12-04', '2017-12-04 06:43:01'),
(24, 2, 1, 1, '9', '2017-11-01', '2017-12-01 13:17:37'),
(25, 2, 1, 1, '10', '2017-11-02', '2017-12-01 13:17:37'),
(26, 1, 1, 1, '9', '2017-11-08', '2017-12-01 13:17:37'),
(27, 2, 1, 1, '100', '2017-11-08', '2017-12-01 13:17:37'),
(28, 1, 1, 1, '3', '2017-11-01', '2017-12-01 13:21:26'),
(30, 2, 2, 1, '150', '2017-11-01', '2017-12-01 13:17:37'),
(31, 1, 2, 1, '177', '2017-12-06', '2017-12-06 05:40:20'),
(32, 1, 2, 1, '222', '2017-12-07', '2017-12-07 13:47:44'),
(33, 1, 2, 1, '6', '2017-12-08', '2017-12-08 13:42:06'),
(34, 1, 2, 1, '5', '2017-12-15', '2017-12-15 07:43:10'),
(35, 1, 2, 1, '5', '2017-12-19', '2017-12-19 05:38:10'),
(36, 2, 4, 2, '22', '2018-01-18', '2018-01-18 09:19:34'),
(37, 1, 4, 4, '33', '2018-01-18', '2018-01-18 09:46:23');

-- --------------------------------------------------------

--
-- Table structure for table `sts_display_product`
--

CREATE TABLE IF NOT EXISTS `sts_display_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sts_employee_id` int(10) NOT NULL,
  `sts_product_id` int(10) NOT NULL,
  `sts_branch_id` int(11) NOT NULL,
  `is_own_product` enum('Yes','No') NOT NULL,
  `image` varchar(250) NOT NULL,
  `product_detail` text NOT NULL,
  `status` enum('Approve','Pending') NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `sts_display_product`
--

INSERT INTO `sts_display_product` (`id`, `sts_employee_id`, `sts_product_id`, `sts_branch_id`, `is_own_product`, `image`, `product_detail`, `status`, `create_date`, `update_date`) VALUES
(1, 1, 0, 1, 'No', 'com_pro_1512568167.jpeg', 'display', 'Approve', '2017-12-05 11:31:22', '2017-12-07 13:49:47'),
(2, 1, 0, 1, 'No', 'com_pro_1512473505.jpeg', 'display', 'Approve', '2017-12-05 11:31:49', '2017-12-07 13:50:14'),
(3, 1, 0, 1, 'No', 'com_pro_1512473532.jpeg', 'display', 'Pending', '2017-12-05 11:32:16', '2017-12-07 13:48:49'),
(4, 1, 0, 1, 'No', 'com_pro_1512479713.jpeg', 'dsdsdsd', 'Pending', '2017-12-05 13:15:17', '2017-12-07 13:48:52'),
(5, 1, 2, 1, 'No', 'com_pro_1512542672.jpeg', 'yslukgzjdjsgkfgixi', 'Pending', '2017-12-06 06:44:37', '2017-12-07 13:48:57'),
(6, 1, 0, 1, 'No', 'com_pro_1512543948.jpeg', 'bbbbbb', 'Pending', '2017-12-06 07:05:53', '2017-12-07 13:49:07'),
(7, 1, 2, 1, 'Yes', 'com_pro_1512555418.jpeg', 'cbv', 'Approve', '2017-12-06 10:17:03', '2017-12-07 13:50:18'),
(8, 1, 0, 1, 'Yes', 'com_pro_1512565278.jpeg', 'test', 'Pending', '2017-12-06 13:01:17', '2017-12-07 13:49:17'),
(9, 1, 0, 1, 'Yes', 'com_pro_1512566248.jpeg', 'vb', 'Pending', '2017-12-06 13:17:27', '2017-12-07 13:49:19'),
(10, 1, 0, 1, 'Yes', 'com_pro_1512567990.jpeg', 'bvb', 'Pending', '2017-12-06 13:46:29', '2017-12-07 13:49:21'),
(11, 1, 0, 1, 'Yes', 'com_pro_1512568167.jpeg', 'hchx', 'Pending', '2017-12-06 13:49:33', '2017-12-07 13:49:24'),
(12, 1, 0, 1, 'Yes', 'com_pro_1512568398.jpeg', 'vgb', 'Pending', '2017-12-06 13:53:17', '2017-12-07 13:49:26'),
(13, 1, 2, 1, 'No', 'com_pro_1512542672.jpeg', 'yslukgzjdjsgkfgixi', 'Pending', '2017-12-20 06:44:37', '2017-12-07 13:49:28'),
(14, 1, 0, 1, 'Yes', 'com_pro_1512794761.jpeg', 'test', 'Approve', '2017-12-09 04:45:59', '2017-12-12 09:31:32'),
(15, 4, 0, 1, 'Yes', 'com_pro_1516268837.jpeg', 'ggg', 'Pending', '2018-01-18 09:47:22', '0000-00-00 00:00:00'),
(16, 4, 0, 1, 'No', 'com_pro_1516268888.jpeg', 'jjhh', 'Pending', '2018-01-18 09:48:14', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `sts_display_status`
--

CREATE TABLE IF NOT EXISTS `sts_display_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `symbol` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `sts_display_status`
--

INSERT INTO `sts_display_status` (`id`, `name`, `symbol`) VALUES
(1, 'Listed Stocked but not Displayed', 'O'),
(2, 'Listed but no Stocks', 'S'),
(3, 'Displayed', '_/'),
(4, 'Not Listed', 'X'),
(5, 'Product not yet launched', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `sts_display_tracker`
--

CREATE TABLE IF NOT EXISTS `sts_display_tracker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sts_store_branch_id` int(10) NOT NULL,
  `sts_product_id` int(10) NOT NULL,
  `sts_display_status_id` int(10) NOT NULL,
  `sts_employee_id` int(10) NOT NULL,
  `added_date` date NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=106 ;

--
-- Dumping data for table `sts_display_tracker`
--

INSERT INTO `sts_display_tracker` (`id`, `sts_store_branch_id`, `sts_product_id`, `sts_display_status_id`, `sts_employee_id`, `added_date`, `create_date`) VALUES
(1, 1, 2, 1, 1, '2017-11-30', '2017-12-01 05:51:02'),
(2, 1, 2, 1, 1, '2017-11-11', '2017-12-01 06:20:07'),
(3, 1, 2, 1, 1, '2017-11-11', '2017-12-01 06:20:08'),
(4, 1, 2, 1, 1, '2017-11-11', '2017-12-01 06:20:08'),
(5, 1, 2, 1, 1, '2017-11-11', '2017-12-01 06:20:08'),
(6, 1, 2, 1, 1, '2017-11-11', '2017-12-01 06:20:09'),
(7, 1, 2, 1, 1, '2017-11-11', '2017-12-01 06:20:09'),
(8, 1, 2, 1, 1, '2017-11-11', '2017-12-01 06:20:09'),
(9, 1, 2, 1, 1, '2017-11-11', '2017-12-01 06:20:09'),
(10, 1, 2, 3, 1, '2017-11-11', '2017-12-01 06:20:11'),
(11, 1, 2, 3, 1, '2017-11-11', '2017-12-01 06:20:12'),
(12, 1, 2, 3, 1, '2017-11-11', '2017-12-01 06:20:12'),
(13, 1, 2, 3, 1, '2017-11-11', '2017-12-01 06:20:12'),
(14, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:25:03'),
(15, 1, 2, 1, 1, '2017-12-01', '2017-12-01 07:36:19'),
(16, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:36:21'),
(17, 1, 2, 4, 1, '2017-12-01', '2017-12-01 07:36:23'),
(18, 1, 2, 4, 1, '2017-12-01', '2017-12-01 07:37:07'),
(19, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:37:10'),
(20, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:59:14'),
(21, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:59:15'),
(22, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:59:15'),
(23, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:59:15'),
(24, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:59:16'),
(25, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:59:16'),
(26, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:59:16'),
(27, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:59:16'),
(28, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:59:16'),
(29, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:59:17'),
(30, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:59:17'),
(31, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:59:17'),
(32, 1, 2, 3, 1, '2017-12-01', '2017-12-01 07:59:22'),
(33, 1, 3, 2, 1, '2017-12-01', '2017-12-01 10:01:00'),
(34, 1, 2, 3, 1, '2017-12-01', '2017-12-01 10:05:36'),
(35, 1, 2, 1, 1, '2017-12-01', '2017-12-01 10:26:54'),
(36, 1, 1, 1, 1, '2017-12-01', '2017-12-01 11:32:37'),
(37, 1, 1, 1, 1, '2017-12-01', '2017-12-01 11:33:50'),
(38, 1, 1, 1, 1, '2017-12-01', '2017-12-01 11:35:21'),
(39, 1, 1, 1, 1, '2017-12-01', '2017-12-01 11:41:42'),
(40, 1, 2, 1, 1, '2017-12-01', '2017-12-01 11:41:55'),
(41, 1, 3, 1, 1, '2017-12-01', '2017-12-01 11:43:33'),
(42, 1, 1, 1, 1, '2017-12-01', '2017-12-01 12:19:57'),
(43, 1, 2, 1, 1, '2017-12-01', '2017-12-01 12:24:48'),
(44, 1, 2, 1, 1, '2017-12-01', '2017-12-01 12:25:04'),
(45, 1, 3, 1, 1, '2017-12-01', '2017-12-01 12:25:55'),
(46, 1, 3, 1, 1, '2017-12-01', '2017-12-01 12:26:12'),
(47, 1, 1, 1, 1, '2017-12-01', '2017-12-01 12:31:04'),
(48, 1, 1, 1, 1, '2017-12-01', '2017-12-01 12:31:24'),
(49, 1, 1, 1, 1, '2017-12-01', '2017-12-01 12:44:23'),
(50, 1, 1, 1, 1, '2017-12-01', '2017-12-01 12:45:30'),
(51, 1, 1, 1, 1, '2017-12-01', '2017-12-01 13:08:21'),
(52, 1, 1, 1, 1, '2017-12-01', '2017-12-01 14:04:54'),
(53, 1, 4, 3, 1, '2017-12-01', '2017-12-01 14:07:32'),
(54, 1, 1, 1, 1, '2017-12-01', '2017-12-01 14:09:58'),
(55, 1, 5, 1, 1, '2017-12-01', '2017-12-01 14:10:24'),
(56, 1, 1, 1, 1, '2017-12-01', '2017-12-02 12:13:16'),
(57, 1, 1, 1, 1, '2017-12-02', '2017-12-02 12:13:20'),
(58, 1, 1, 1, 1, '2017-12-01', '2017-12-02 12:13:22'),
(59, 1, 2, 1, 1, '2017-12-04', '2017-12-04 05:17:29'),
(60, 1, 2, 1, 1, '2017-12-04', '2017-12-04 06:23:17'),
(61, 1, 2, 3, 1, '2017-12-04', '2017-12-04 06:27:20'),
(62, 1, 2, 1, 1, '2017-12-04', '2017-12-04 06:29:04'),
(63, 1, 1, 1, 1, '2017-12-04', '2017-12-04 06:33:44'),
(64, 1, 3, 1, 1, '2017-12-04', '2017-12-04 06:42:37'),
(65, 1, 4, 1, 1, '2017-12-04', '2017-12-04 06:42:41'),
(66, 1, 5, 1, 1, '2017-12-04', '2017-12-04 06:42:44'),
(67, 1, 1, 1, 1, '2017-12-04', '2017-12-04 07:20:38'),
(68, 1, 2, 1, 1, '2017-12-04', '2017-12-04 07:20:47'),
(69, 1, 3, 1, 1, '2017-12-04', '2017-12-04 07:20:56'),
(70, 1, 1, 3, 1, '2017-12-04', '2017-12-04 09:29:18'),
(71, 1, 3, 1, 1, '2017-11-01', '2017-12-04 09:40:25'),
(72, 1, 3, 1, 1, '2017-11-02', '2017-12-04 09:40:25'),
(73, 1, 3, 2, 1, '2017-11-02', '2017-12-04 09:40:25'),
(74, 1, 3, 2, 1, '2017-11-03', '2017-12-04 09:40:25'),
(75, 1, 3, 1, 1, '2017-11-04', '2017-12-04 09:40:25'),
(76, 1, 3, 3, 1, '2017-11-05', '2017-12-04 09:40:25'),
(77, 1, 3, 3, 1, '2017-11-06', '2017-12-04 09:40:25'),
(78, 1, 3, 4, 1, '2017-11-07', '2017-12-04 09:40:25'),
(79, 1, 3, 4, 1, '2017-11-08', '2017-12-04 09:40:25'),
(80, 1, 3, 5, 1, '2017-11-09', '2017-12-04 09:40:25'),
(81, 1, 3, 1, 1, '2017-11-10', '2017-12-04 09:40:25'),
(82, 2, 3, 1, 1, '2017-11-01', '2017-12-04 09:40:25'),
(83, 2, 3, 1, 1, '2017-11-02', '2017-12-04 09:40:25'),
(84, 2, 3, 2, 1, '2017-11-03', '2017-12-04 09:40:25'),
(85, 1, 2, 1, 1, '2017-12-05', '2017-12-05 13:53:16'),
(86, 2, 3, 4, 1, '2017-11-06', '2017-12-06 05:09:30'),
(87, 1, 2, 1, 1, '2017-12-06', '2017-12-06 05:39:37'),
(88, 1, 2, 1, 1, '2017-12-06', '2017-12-06 05:42:27'),
(89, 1, 1, 1, 1, '2017-12-06', '2017-12-06 08:00:04'),
(90, 1, 2, 1, 1, '2017-12-06', '2017-12-06 09:18:59'),
(91, 1, 4, 1, 1, '2017-12-06', '2017-12-06 10:14:16'),
(92, 1, 2, 1, 1, '2017-12-06', '2017-12-06 10:21:24'),
(93, 1, 2, 1, 1, '2017-12-06', '2017-12-06 13:00:01'),
(94, 1, 1, 2, 1, '2017-12-06', '2017-12-06 13:15:42'),
(95, 1, 2, 1, 1, '2017-12-07', '2017-12-07 10:17:51'),
(96, 1, 2, 4, 1, '2017-12-07', '2017-12-07 12:56:44'),
(97, 2, 2, 1, 1, '2017-11-01', '2017-12-04 09:40:25'),
(98, 1, 2, 3, 2, '2017-11-11', '2017-12-01 06:20:12'),
(99, 1, 4, 1, 1, '2017-12-19', '2017-12-19 05:25:56'),
(100, 2, 4, 3, 2, '2018-01-18', '2018-01-18 09:19:25'),
(101, 2, 2, 1, 2, '2018-01-18', '2018-01-18 09:23:51'),
(102, 1, 2, 3, 4, '2018-01-18', '2018-01-18 09:46:13'),
(103, 1, 4, 3, 4, '2018-01-18', '2018-01-18 09:46:28'),
(104, 2, 2, 3, 4, '2018-01-25', '2018-01-25 10:13:47'),
(105, 1, 1, 1, 1, '2018-01-25', '2018-01-25 10:26:48');

-- --------------------------------------------------------

--
-- Table structure for table `sts_employee`
--

CREATE TABLE IF NOT EXISTS `sts_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sts_role_id` int(10) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `sts_employee`
--

INSERT INTO `sts_employee` (`id`, `sts_role_id`, `username`, `password`, `first_name`, `last_name`, `email`, `contact_number`, `address`, `status`, `create_date`, `update_date`) VALUES
(1, 1, 'super_admin', '4498afcfaaa0306ed48a244cb7dbde7f5da78603', 'Gopal', 'Bhuva', 'gopal@parextech.com', '9989789568', 'gjkdfghj dfhgjkfhg dfjghjkh', 'Active', '2017-11-27 12:57:08', '2018-01-18 07:27:04'),
(2, 2, 'admin', '4498afcfaaa0306ed48a244cb7dbde7f5da78603', 'Maulik', 'Raval', 'demo@demo.com', '9989789568', 'gjkdfghj dfhgjkfhg dfjghjkh', 'Active', '2017-11-27 13:28:05', '2018-01-18 12:29:12'),
(3, 3, 'manager', '4498afcfaaa0306ed48a244cb7dbde7f5da78603', 'Mukesh', 'Rathod', 'demo@demo.com', '9989789568', 'gjkdfghj dfhgjkfhg dfjghjkh', 'Active', '2017-11-28 10:45:16', '2018-01-18 11:15:45'),
(4, 4, 'employee', '4498afcfaaa0306ed48a244cb7dbde7f5da78603', 'Bhargav', 'Chudasama', 'demo@demo.com', '9989789568', 'gjkdfghj dfhgjkfhg dfjghjkh', 'Active', '2017-11-30 10:15:03', '2018-01-31 11:47:34'),
(5, 2, 'admin2', 'aab4d5662e913ea207c9870983b191853b0b841b', 'Harshad', 'Raval', 'demo@demo.com', '9989789568', 'gjkdfghj dfhgjkfhg dfjghjkh', 'Inactive', '2017-11-30 10:15:32', '2018-01-18 07:29:54'),
(6, 2, 'admin3', 'aab4d5662e913ea207c9870983b191853b0b841b', 'Nikhil', 'Prajapati', 'demo@demo.com', '9989789568', 'gjkdfghj dfhgjkfhg dfjghjkh', 'Inactive', '2017-11-30 10:16:18', '2018-01-18 07:29:57'),
(7, 3, 'admin5', '4498afcfaaa0306ed48a244cb7dbde7f5da78603', 'Trupti', 'Bhuva', 'demo@demo.com', '9989789568', 'Jb tower, Ahmedabad', 'Inactive', '2017-12-13 09:42:02', '2018-01-18 07:31:15');

-- --------------------------------------------------------

--
-- Table structure for table `sts_employee_attendance`
--

CREATE TABLE IF NOT EXISTS `sts_employee_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sts_employee_id` int(10) NOT NULL,
  `attendance_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `location_lat` varchar(20) NOT NULL,
  `location_lon` varchar(20) NOT NULL,
  `attendance_status` enum('IN','OUT') NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=267 ;

--
-- Dumping data for table `sts_employee_attendance`
--

INSERT INTO `sts_employee_attendance` (`id`, `sts_employee_id`, `attendance_time`, `location_lat`, `location_lon`, `attendance_status`, `create_date`, `update_date`) VALUES
(214, 1, '2017-12-07 12:18:47', '23.0490497', '72.5238344', 'IN', '2017-12-07 12:18:47', '0000-00-00 00:00:00'),
(215, 1, '2017-12-07 12:19:00', '23.0490488', '72.523868', 'OUT', '2017-12-07 12:19:00', '0000-00-00 00:00:00'),
(216, 1, '2017-12-07 12:19:08', '23.0490488', '72.523868', 'IN', '2017-12-07 12:19:08', '0000-00-00 00:00:00'),
(217, 1, '2017-12-07 12:19:17', '23.0490121', '72.5239064', 'OUT', '2017-12-07 12:19:17', '0000-00-00 00:00:00'),
(218, 1, '2017-12-07 12:32:10', '10.422', '10.083998333333', 'OUT', '2017-12-07 12:32:10', '0000-00-00 00:00:00'),
(219, 1, '2017-12-07 12:32:13', '10.422', '10.083998333333', 'IN', '2017-12-07 12:32:13', '0000-00-00 00:00:00'),
(220, 1, '2017-12-07 12:33:20', '23.0491086', '72.5238091', 'IN', '2017-12-07 12:33:20', '0000-00-00 00:00:00'),
(221, 1, '2017-12-07 12:33:31', '23.0491086', '72.5238091', 'IN', '2017-12-07 12:33:31', '0000-00-00 00:00:00'),
(222, 1, '2017-12-07 12:33:53', '23.0491531', '72.5237944', 'OUT', '2017-12-07 12:33:53', '0000-00-00 00:00:00'),
(223, 1, '2017-12-07 12:33:54', '23.0491531', '72.5237944', 'IN', '2017-12-07 12:33:54', '0000-00-00 00:00:00'),
(224, 1, '2017-12-07 12:36:58', '10.422', '10.083998333333', 'OUT', '2017-12-07 12:36:58', '0000-00-00 00:00:00'),
(225, 1, '2017-12-07 12:56:03', '10.422', '10.083998333333', 'IN', '2017-12-07 12:56:03', '0000-00-00 00:00:00'),
(226, 1, '2017-12-07 12:56:06', '10.422', '10.083998333333', 'OUT', '2017-12-07 12:56:06', '0000-00-00 00:00:00'),
(227, 1, '2017-12-07 13:41:52', '10.422', '10.083998333333', 'IN', '2017-12-07 13:41:52', '0000-00-00 00:00:00'),
(228, 1, '2017-12-07 13:41:56', '10.422', '10.083998333333', 'OUT', '2017-12-07 13:41:56', '0000-00-00 00:00:00'),
(229, 1, '2017-12-07 13:42:02', '10.422', '10.083998333333', 'IN', '2017-12-07 13:42:02', '0000-00-00 00:00:00'),
(230, 1, '2017-12-08 05:00:44', '10.422', '10.083998333333', 'IN', '2017-12-08 05:00:44', '0000-00-00 00:00:00'),
(231, 1, '2017-12-08 05:00:48', '10.422', '10.083998333333', 'OUT', '2017-12-08 05:00:48', '0000-00-00 00:00:00'),
(232, 1, '2017-12-08 05:02:31', '10.422', '10.083998333333', 'IN', '2017-12-08 05:02:31', '0000-00-00 00:00:00'),
(233, 1, '2017-12-08 05:02:35', '10.422', '10.083998333333', 'OUT', '2017-12-08 05:02:35', '0000-00-00 00:00:00'),
(234, 1, '2017-12-08 05:02:39', '10.422', '10.083998333333', 'IN', '2017-12-08 05:02:39', '0000-00-00 00:00:00'),
(235, 1, '2017-12-08 05:03:36', '10.422', '10.083998333333', 'OUT', '2017-12-08 05:03:36', '0000-00-00 00:00:00'),
(236, 1, '2017-12-08 05:03:40', '10.422', '10.083998333333', 'IN', '2017-12-08 05:03:40', '0000-00-00 00:00:00'),
(237, 1, '2017-12-08 05:05:08', '10.422', '10.083998333333', 'OUT', '2017-12-08 05:05:08', '0000-00-00 00:00:00'),
(238, 1, '2017-12-08 05:05:13', '10.422', '10.083998333333', 'IN', '2017-12-08 05:05:13', '0000-00-00 00:00:00'),
(239, 1, '2017-12-08 05:12:05', '10.422', '10.083998333333', 'OUT', '2017-12-08 05:12:05', '0000-00-00 00:00:00'),
(240, 1, '2017-12-08 05:12:06', '10.422', '10.083998333333', 'IN', '2017-12-08 05:12:06', '0000-00-00 00:00:00'),
(241, 1, '2017-12-08 05:12:52', '10.422', '10.083998333333', 'OUT', '2017-12-08 05:12:52', '0000-00-00 00:00:00'),
(242, 1, '2017-12-09 03:51:35', '23.0712981', '72.5730538', 'OUT', '2017-12-09 03:51:35', '0000-00-00 00:00:00'),
(243, 1, '2017-12-12 05:13:48', '23.049127', '72.5237556', 'IN', '2017-12-12 05:13:48', '0000-00-00 00:00:00'),
(244, 1, '2017-12-12 05:13:51', '23.0490552', '72.5238218', 'OUT', '2017-12-12 05:13:51', '0000-00-00 00:00:00'),
(245, 1, '2017-12-12 05:13:53', '23.0490552', '72.5238218', 'IN', '2017-12-12 05:13:53', '0000-00-00 00:00:00'),
(246, 1, '2017-12-12 05:14:26', '23.0490552', '72.5238218', 'OUT', '2017-12-12 05:14:26', '0000-00-00 00:00:00'),
(247, 1, '2017-12-12 05:14:27', '23.0490759', '72.5238032', 'IN', '2017-12-12 05:14:27', '0000-00-00 00:00:00'),
(248, 1, '2017-12-15 06:52:41', '22.712056666667', '71.599123333333', 'IN', '2017-12-15 06:52:41', '0000-00-00 00:00:00'),
(249, 1, '2017-12-15 06:53:03', '22.712056666667', '71.599123333333', 'IN', '2017-12-15 06:53:03', '0000-00-00 00:00:00'),
(250, 1, '2017-12-19 05:27:32', '23.0489742', '72.523952', 'OUT', '2017-12-19 05:27:32', '0000-00-00 00:00:00'),
(251, 1, '2017-12-19 05:42:13', '23.0489943', '72.5239314', 'IN', '2017-12-19 05:42:13', '0000-00-00 00:00:00'),
(252, 1, '2018-01-19 19:36:18', '23.0212584', '72.521983', 'IN', '2018-01-19 19:36:18', '0000-00-00 00:00:00'),
(253, 1, '2018-01-19 19:36:25', '23.0212584', '72.521983', 'OUT', '2018-01-19 19:36:25', '0000-00-00 00:00:00'),
(254, 1, '2018-01-19 19:36:27', '23.0212584', '72.521983', 'IN', '2018-01-19 19:36:27', '0000-00-00 00:00:00'),
(255, 1, '2018-01-19 19:36:33', '23.0212584', '72.521983', 'OUT', '2018-01-19 19:36:33', '0000-00-00 00:00:00'),
(256, 1, '2018-01-22 10:37:31', '23.5646671', '72.332408', 'IN', '2018-01-22 10:37:31', '0000-00-00 00:00:00'),
(257, 1, '2018-01-22 10:37:34', '23.5646671', '72.332408', 'OUT', '2018-01-22 10:37:34', '0000-00-00 00:00:00'),
(258, 1, '2018-01-22 10:37:37', '23.5646671', '72.332408', 'IN', '2018-01-22 10:37:37', '0000-00-00 00:00:00'),
(259, 1, '2018-01-22 10:38:02', '23.5646671', '72.332408', 'OUT', '2018-01-22 10:38:02', '0000-00-00 00:00:00'),
(260, 1, '2018-01-22 10:38:07', '23.5646671', '72.332408', 'IN', '2018-01-22 10:38:07', '0000-00-00 00:00:00'),
(261, 1, '2018-01-22 10:38:30', '23.5646671', '72.332408', 'OUT', '2018-01-22 10:38:30', '0000-00-00 00:00:00'),
(262, 1, '2018-01-22 10:38:47', '23.5646671', '72.332408', 'IN', '2018-01-22 10:38:47', '0000-00-00 00:00:00'),
(263, 1, '2018-01-22 10:39:07', '23.5646671', '72.332408', 'OUT', '2018-01-22 10:39:07', '0000-00-00 00:00:00'),
(264, 1, '2018-01-22 10:42:56', '23.5646671', '72.332408', 'IN', '2018-01-22 10:42:56', '0000-00-00 00:00:00'),
(265, 1, '2018-01-22 10:46:11', '23.5646671', '72.332408', 'IN', '2018-01-22 10:46:11', '0000-00-00 00:00:00'),
(266, 1, '2018-01-30 11:52:06', '240235', '562565', 'IN', '2018-01-30 11:52:06', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `sts_order`
--

CREATE TABLE IF NOT EXISTS `sts_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `client_name` varchar(150) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(150) NOT NULL,
  `qty` int(11) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `sts_product`
--

CREATE TABLE IF NOT EXISTS `sts_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(100) NOT NULL,
  `sts_category_id` int(10) NOT NULL,
  `sts_brand_id` int(10) NOT NULL,
  `product_image` varchar(200) NOT NULL,
  `product_desc` longtext NOT NULL,
  `product_code` varchar(10) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `sts_product`
--

INSERT INTO `sts_product` (`id`, `product_name`, `sts_category_id`, `sts_brand_id`, `product_image`, `product_desc`, `product_code`, `status`, `create_date`, `update_date`) VALUES
(1, 'MB Colour 56 Gsm 45.5 x 58.5 - 7.2 Kg Pink', 7, 4, '', '<p>Iphone x mobile</p>\r\n', 'PRO2356', 'Active', '2017-12-01 05:31:10', '2018-01-23 07:17:59'),
(2, 'Century Pristine Map 38.1 Cms / 70 Gsm', 5, 2, '1512374482.png', '<p>Samsung 32&quot; LED tv</p>\r\n', 'PRO8956', 'Active', '2017-12-01 05:32:22', '2018-01-23 07:14:38'),
(3, 'MB Colour 58 Gsm 45.5 x 58.5 - 7.2 Kg Green', 9, 2, '1512565816.png', '<h3><img alt="" src="http://192.168.100.171:81/store_sales/public/uploads/product/1512545453.png" style="float:left; height:100px; margin-right:10px; width:100px" /><strong>Type the title here</strong></h3>\r\n\r\n<p>Type the text here</p>\r\n', 'PRO7895', 'Active', '2017-12-01 05:33:06', '2018-01-31 11:46:07');
INSERT INTO `sts_product` (`id`, `product_name`, `sts_category_id`, `sts_brand_id`, `product_image`, `product_desc`, `product_code`, `status`, `create_date`, `update_date`) VALUES
(4, 'IP Colour 70 Gsm 43 x 69 = 10.4 Kg Pink', 3, 3, '1512565771.png', '<h1 style="text-align:center"><span style="font-family:Arial,Helvetica,sans-serif"><strong>This Product</strong></span></h1>\r\n\r\n<p style="text-align:center"><span style="font-family:Arial,Helvetica,sans-serif"><strong><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAACWCAYAAAA8AXHiAAAgAElEQVR4Xoy9CbitZ1nf/axhrz2enHMyHwIkwUBAVAoiWKci1Cpaq5+KiNZaabX6iTNYq7ZaQRCKCrSKWm0/LaBMgUSQAIKCzDMkQBISSEJCpjOfPa619lr9/f73u07id329rm+Hw9p7rXe97zPcw//+3/fzPL1fuvq6+bTtt3lvqc1n0zacD3idtd6otSV+35/P235v0IbDXptMd9pK/0Cb7u+0pTZss0GvDebDNmq9Nu/P26RN22w6aIPBkN8mbT6ftVm/1/iIJ7Q2b9x37jf5q8d3+JyP2lKvcf2AV57FO/k+n3H3NuTZvjvcn/MMvzZoff6ezblvn8+9L8+Y044Zzxz0+rSf6wa8Tz/2B/22zHVtMuFbvTZdGrbhlO/PuG6J69ICPt7fz/PnvLM/8z0axR396v6Uq/isT5t7A+5CQ2Z0amlGTxifOW3xoYMlejjzjv3Wm/IWjRvO99uU9sxGtHfCezbOEejZd57Wp1PcY4nn8GX+8V3HgV8ZibYyHLTd3phn853Jfvpny/p97rvfb8MRfzu4DrIf8K0lx2DCuNGIGR3ocz8GLH21Z/SK57a2x3NHPGeZ112eNWYWVhmvKX2oHwfSVtg4x973M4vd+LTG5bmvbZ7OHHTmk7b0nv2GT86Hw37b48H2azjgzalD40QxGH5zBTHZW2or9EDBm4yYmL1hW+ejXbu/RENno3aGEVynefzJ+0xC5geBnY8ZSAeQweT7TmBfYWBiZm2vDZmQfQZiQIPmPFcB6jtZAwSDP0a89ia0aMnZovGzZdrFPfcVK55Dh/t9PqPVjpiKMJnutZWllbY7n9BmBttP+WwX5RkxqZMpwmFDmcE+k6sw9XlfieyjMEhTJn+4z71sC89YYpym+ygM9xqMGCfaMtjjr2UnCTVAOFUGB9l/e7RnpHD7mQK1stS2J+O2wsRNudc+4zwYIAC0jy7Szn6bIAzpFQKhKExox0zhU1wjFSXg/tH3WRnWXhuhnTOVz2FT6TAEM/q6y1V9DUMUNd2o6/h9mT/2nHSFiX5xt7bt8+cr/DZD4Jgv5knDoUCPlU/+dh6XVXgFsF8KMqMPs+EwQu4c9p591Wdo/zgaiT6UFjlBNA6RyPs9tcTJUyAYTHQzAoh54v1lrAvfdL6dvhlyzwOHCo6WgHfrnhny1kf4poOl3G80ZNBiytCwXI3wMOD2dcn785mDgg1p+32Ge8J7aChvxuoMVHMv08JqjdRwOr2nVUFwtGhaUUaO69D64XImccb1ijQzXhaHgR1EM5nsTtD6DNg+3/fZGUBukYm121o2LIu2xze859KQPjEeWpGR1t1+07m+E44A0WL6ynvOhZOhRUpftYp8xrXcpgRxaUl731aYSfu4i8DGKtIGhW6o8mhVnZMIJs9RbLSoDl5nh9N62uo7Wm+vic3RQ/BviBRMVXRuNeS6sXrFmERFUS6vsf8D5mCkR+B6ZWPu3HETX9Vz7x2R4RqfpnfBYn2akZm0MY1laGItvM4vlVXBXPKgpZhILJbqycOmDLrvx2QzUHEZ/KF8KwP70d5Y+QgMNo5vVkfjtnhdwhfta7EUSq5TGRQ4rVoPzdHR9ZiBKImWzKEZDWjHhAmoAfXDnhaB1wkWZmniq8+mEb7igiYOGJM7RkDWVhhUBTTuWEVQYXhBGJcYSYXUvmSksGgKxxxhsf0DGrrvoGFBllBGTDcajCBE6aK8/B/3VYAQGpvXY9wmY6zAaAkBQwC4x0zrwbVTvQNNUTBXuAG3jnL0uBEGESHVGiuUXJ9GORDMAy9L3EBBiTGNxSglUH0d2yhAFNqxjQ2xq/Fu+ygFt8ayIUJDFD3jTf/QnMH+iL+nsYqTThAHKIoWV5cYT46s9KPM5UCc5D7WaorREIIMgUO951x13Xy/t0eTRjRDWRUT8XsajvXGuvggPWKficB28Dk3jhDSWG7aU1KZRO1OCaVWzkFQq5g8Rlif3+fX6ZDRxm0OuXDEBE0AHnsIyRIjtDzbxe3R6T5WEMHqM6G2XlelO9gX1zixdmBliDsr68qUZbCDwfhc/MN40ZZOq7kq7ix9UHD3IqgznuXg9LFueY6C6LNwPxgR7qXWOm0KNdZZy4Y8eashz9C9O3nIUCyFAjLhvQECM0N4lxxslCBC4Rhh0WwDzcbdqOmdK0y7FGJwIO2PooGp/JmhoMKRHmOk54ivCWgt5XO6Hfd8XwHk5nOsGOg2AjwUr051b7hr5lRXthQBoa9IgZbSuZowR0tLmopyoX5vpifC1c+XC8vacfvuzz4WTfl1PHWTute4WYVYnPgLr/8Ez0ALmIkhM9/H2dthJWTJv/XlndnzJvuRbr2uk2OHy7znn0KmObZ5NpZGa0Z7YCkthMI3U7u1dT2sJM0d8d4a99jl9zWfrd4p2GImUa8uWayFGdzXheJq7YjaHbVUsDKhDmRZE1sw0gJwi2hzcITKWiC8l+ucbCZDoY+2K8A6ZO8ZOMobiGyEwGAB5B07yH3RYJVOIVBhtexOmpo8coD5jq4s+LSbuBmCMMB6DrjXWIXpXKvjpGvbm0yZWCe1G0Pep9d8nzkIcPFve8w8CZRpO80IBh1g4QwoIhxRhK6vCQqAA7RhHyFbCTSgh4xrORItLcpDUIAslEEUw3UQQxe5zzUDhce5Vhmc3xgN553vO0ViRBU/oJr26K2e/YbrMxKa87gBNKWPW5ijIQhqJmGGBg6mWKslhM1BicRitVS9fB5/WMgw812YKm7QKLM/br2AVayQ9gUh6aMVfd3JfK1NuNcqf8/FcvEnS4DscVtPaNfaKu3b9u2BlhRQjcXp99ajseXTdVVGpWhL7hG5jcvtDybBWmp6sJFKYlsR6x7g34EfY+76+J64VoVWD6GAivi3lKyK1MQdIlFx2dnIqOvyIFa8LLBwYA4YjoWJpYsJKkvQuby5k0efogCBKKXx0wya1oBniNdAHvtaUMH8AoviQXr9Fe63E0soFjYaFTwP6TgeN96kQ+qlWCMsJsJA3NV2sabLy1h8BErB0rr1wHU+JwInLEqkzXgyXqCLCKzBhZBYwRrEG+mMdNOMM+ODU4onG6hcv3jVp0Qx8bnOYkJVfSaTnWhDa8EEr9A4ID6TZJQnqE/MWPiGb/rwigLLkUeKHVb/7j5T2JYwseMpEQgD00eydW+K4ZyJXKeje8sRyRrcgG5EJoGCmsPg8F2t6WyI1Uv8ztWZGZ8r1cE/NHQad6zAK1SCZLSZyVEz51oa1H2OYuyDo+ybuEuL6HWJuuyfj8WH9KeF17TcNfSMk1hvj/nqLLwTP9F68yqwLuuj61ELwaYohfdTcXRFWolMvhGfk8J3dN96DEGFEeOItuUejnQ8QaY1gNT5UnAFzkPmSrcnDuxpGTtFr5b6TF1VN1YiaaBPrCk3IWZGEMYYB9rdzZ3QIziyizIDLQK+fV+4wDzQ/iUxZ1wnFn9Jy8+4ir+EKr+AYBkO806MjU4uGFRJplVxQ04OD16hX8KRxBlqaHCJ9pIBj8ssRxIRDSJmUIJpvD1S7fsBhmgH33eQnSyfrM9ew1JsM7o2xefT1oT8MyxLj/f7gl7Bq1GSwLoDrJpgQ2zvo4vQssTCxFzjMmxbb4UJR+BQ56VEPEwwwrqH0CbCZIAnDGYf4LnfJ0jn90yMShbcYjDDJPhdro874LviX2kKJ3mmhQ1A0ItzT5RQjDXAkqjhWjoVEedWyqTyyvXpfpDdAVGGghyXrRAasWFiplAtPeahT3tzD4SHRsfSGbTYryHjK/eXySt4Fgun8vqWjfLZRqYjrKWRvBBlghdaRjCIZ4t2iSEqdycu01Ds8+wh18TthV4QfpS8aBicz0AM+22QpgD+9FUfno/mB9AwuR3dhhyRvlvpK58pOI8VMQITLmJ19tUAtXVsI2jsYBnTWiB/HFSnxGux/K4N1IUZ5mOphgTjIdOKd/H/BvJNTMA+95vhlkYMwJgBUFgZG2/QdYjBd1xj7ei8EY5uDCyidRPzJqgLj6HpTuwayyVfNsTc7yAAA/gkUE3xQN6dNolnlrTMht60a93oV4zDZ8uDlVjGKdZrClG8xN9TtbezpooLeKGjFhBCLJbWxGaMhvBCoH5JWB826I8YC4XZCE0LCS5JcOGkGYrwXrCi1la/MAaDybcRcYeD6/g8xjSRIPPRQzgNvZaxus6Dimh7g4O5/wRl0LItgqowhlhtgwIDAAMacafBR4UBBhGOv+PZCb8RTdSmFNf/+kiicEJLP1tabkOe7fz0fvHqz8yHDMg+vswHGYoq9uGPBIliUsFq5997WiJvFt8cteB3ox9RTmSkgG1e/Z7N6jRQn2yztTBM2Ky3FZOrWR7oSwV+NGqCwAKNnOdMRE932QUJMvtD1LuHJdg1LEfrNMNj3t+gsSOYdQVuTvS5i6tCkuKChnTaCTFqEjNlyGmsE+zkD8RRTM4a7xmW2OYx918J+YuwGat3HXTSBwiVBK8R88poxPNRKoUsbqsyFsFpjM0EoVAAtGgFffyuwyjfp2fjVayiMGbcynWbDZnRT8crWQG9l9aAe5dFNNIUttAb+rVn9oDJ18rqus1aaMEjBMG9flauXkseD5KgwywJkTrv7/K3wik/tr8HBtZz6Hzsl1aj+I3Mh0ZbIj3ujzenRtVaeEfhZ9943VzO0Zv6HSGMJOXUjgYCVOOMmMZo+6o4pxOeRmPUdHmeolwTMwXTiIn2uY+mODjHyEWq306LKyLWMUUZuFEmTpChlTHi0Tw7GXI+tkd8J8ezDyPMRIKv/EoiHcjP+T7IhSABFJ5oclWScRfhX1FzFWbFhY8JQpZh8LcMuOiPlIBoUFHqm35hQBUw7WNxd2p1hfNRHgbLSRww6UZjWlSvCVXRW2WCiFq1vIzfEhM0BogNseZ92xvQX4y5QN5nJH2F9V8im0Dj0uckUcSytti0GqLeJgBzxjN9Vaj4TFax0mJdVCbXpFcxokfBjDR1kXmuyixb7qQanSiABjCmpxJ5KzSQy2DH/tgosddWxYIYqZFks080yOPvfsan9MznDVR6R9AUWyJtwfvrPyVqbdNlHShfCimnS4P8Ew8puYnl+NHWIr4hH412AgoZXFjnmYBcXwscJDsXTQhtYTrGyFA3VZk9NK9yfz3dIoPpc3qAWwH1WKAbP68DKKwVXIPWzwd7COAGWsWrHEychQPsb9UmXYt4LgGZaSr5MDFdBFOioyyS7jFYQsvD6KkSvj8CEoRGQBgUitXVVSwfmbQOlEcBo/22VwzpxKgYWg69ceUwK/p0sLtUE0o1dcJRXGRbcJKxWWKmJrnGL0tpFF8VfEuXFGZFzSjd/mk1JFp9T1c1A3gLL7SCM8nXMcBcix6wi3Jr7bWezKABjR5kSDSuN+0r8PFKjL/pLekZFQ1Cd2WN+YeK17ItobC66ML2aCTzrTD5p1grRLqWyog6+Jv7/MIbP8p74IdYehtA4+cIBtMatE/n5sFJWAEBrpPY3SiOLYNoL/D/PpfpCW+leVTCY3rVvIom0xomU/xlkm2GkKyoXUjREAswQbiWmBw1cSIYNlrSSi7v0NFlBgqhd+CDDDpyztwVl+5qhdLBIg218piC9GoeEpS+mYCWFQ/YNyhBEPfpL++PVpdxJ9AEAmrRGWy5FMxyF4ztxr5q0YUMsv2FO001CayLjig8YsQ0VdiwPNIghuC6Cq1D2sGzdWvYIIQPazXn7g5TtLvye7EspcKA+ASXbUwyPfhLrxG4ojDTXyef+VLYpA3SO4Rw17yveU2k2WhQS9Xb2wtGdHgUD4lQKXMDBCHKAOOxi7Vb1rMk2pY7s9kooFDWRqUfRovxlmXVNTTRZ+767Kuu58Uk8ah8aaK5EAbR4qEhOIM9w1QvjaYh9wTr4pP4Vky8g2wDDI/HgnmHQpNhZJVIzobo+mxEsfW2WS1KSC+lkLwj7gbALqG3JHDfFWBWojXlAjI2stP2RBeFkPnRgGTzDs9Z4rO4WAR0BmZLVChGivUQ0+y31eW1Nt5zIK0gkPZwcs0cImC6BYQD1JA2wXxkHHQBstlq/DIuKVYumLNAtoTjGBe5Qh+lLQaM2f58myExoc6dk8oxQnRgS7DiEs03qjso0hL39HpdvOM5JDshGDBnuq1QimVLDEOQRinNfyK4Tqr31IWmWsLIF6UY8p59HS4TLGCF9vFCowROzqmkc82HoqNfslJlGWu26z27KFRBAZJXDlTvwffl/+ItUKykj/L9ilidD38gSD+DtZPjMFNYAjPWhJsfSjhbQDJYS1OedIGugEmB3PS1b+ifpKGm38kXbyhHhduc2DL1nWdW0vHlPXx5oKqRpIIsux5rUVgheTwHNdHhHi6AKdcYGjnxdz2BOxhG26N8p7qWSQ/fU/hg1pWeBOJ1KZp9U1Wxxrol819iJTGjgmRzKxI18gyRkNBaZanBE7Bq+nXXe1ijpViMSij7aagV51mrgYKoMHKDsTLcY4zwSkDah7RdJcME2HaV2xSSeKkyUxVoSNpM9CR6FvU5iWw5JQVND2FOtiCKlsOujaR6hBliIxRDKOIzjQKTtpHgdNRVLOmHHTIivO6KgWm3vJRgwXxmFC3ykVuXMop4Mte67KDVsliGzOKQDCOS3UPad7AgCakhwlbo7L5sPMJnY00/z/pbTIQ4zDRCpUYStip0/B1/7OjxvxXs+K5Rk+bWhgTbm26tcg6b1adKwkITG2YUao5MEGwQV6E0goSLHsRajhBngCcWy4lM6sZBtuPem6oA65TmSc8zAvYc5aGjwQY6CnNbKkR6Hcsk212cl5NiGqPMe4mpoboBRLHpipn9EBNVP41ElQfddkhOolQTi7sy4lqZkIvcg0ka6D/EOMsIiTVWtqGTVsdlGmtvP2mXyk1bxhKhPKqsfY1vInTvDVksnRBeNFyLylxc2TLtHo/NBjB2hNoaAPFj0CnjF8ogClQWZ4M+7eqabQMDm8g2eMq6NgG+D9DdK/niK9u3sFP17Kl9ffYbEawAuE77cQWzdN7Q1omdt3Wk18K4KkPxvmb3FSQHWmGxceKHilLscGeb5BAVmyL2opT8rsPmtxGZdFKj4cnmjgo5gQBMU4nRankg0j22D0FbWTnQtne3M0CW3jjAlbJ3cnQRCDDfWWcwt+xDSkqYZAlE3Q5tXV2mqI3nKJQh7DOHDC/PWULQIg+4M6NRw/0hQiCNYBJ9GSm3XDATbTjj5JuMli/SOmI9rK6YywkqFDLW1K2Z0hKnhv2W1nAMrLOKS3eAhB1cx33OmDsVI2JFpgDz5Ge1vjFrTj5YVwDO/Mi1Ccb3wY89+rUU3iqmKNY0BgvuTiGyrmvJqNBOy3FJQxjVe30nxCVeJSQqh2kio2ZxptDByF2LvQDrCzeqsD/wJ+8/Gx7Luqrk06IRDrY1nrtnC+mE7KGGaaD0nRNUEZ9dlUKwnsnyC512AFWFtuam1DPHL8FClWZU6aaTwqCk6kF2GqFKRFpYKCKoMYurUDhsggSeOEVBkizkMzFK8EElt6cjiNYIRtUGpZO0dYS1m+A+zdXtcp85kyZVYSpJrm6gcNlGw20y+rrIWY9yRV5XeIYRowpiNDsh8poNV4t3MnZlwMUg8m5LKoMkah8L2wUxukTrqiaQssloMBhGujOpBqNdujm0LVNIVDkyx9TqJElRBTSMfgUFBjoTBgP7g2A5KDXZKm4qPxSj5PTEtnxGVGOgYuRtn9Rff8wYSJ0sBKtyvYJ8rVAkMmR3igIRzqo+kZ+s7EFBnUI3tj+CHAErfrP3K9d8em6IX5WeNlJN5ndIU6mHlMAGqMvrlPYMkHTd2B69XhaTxZEYFwovuSI5OjUiz8mTxTrJL8r2FmoMlujNmKChSeXCR6EpAjZM01TLTfFM/T/dZCIuwbEYoyoX+ian6dQK2GOSwjoxnmkQtXkMXpAG0QJ6fVBdvm+gImsdPitNrQhXyy5RG+7M9wJwtWqVupnESmFB+b7BpoIlwTk2WkRK42C14lIX2nUDiRT38eQItey+9AnXyrFZ6kP3VI5FLlMrLN4aohBj5wIhW5YQ1XpaO+V8MT/yYQppxD71aboraROwI8Ljc7yvbkzvkhST2M3KWKdBc6FwlGdLxJuozkDKcpsCtanC1dWLuZMhiPQ4tUKIyqCkXitejPd+SR4rsSSRg+4Dd6DFTulvQmoHGUtgg5wQgTyjvoz07/CADUtudDdqXQ1/hcqxF06M0l1aakOcqEyG7TIFYhrFyCm5QxWQyQmWkZ2vtIh5RDsbCxPLJ6bsnqG1SQEe4TGR6x7gWza77KYPKrAZt6g7jOaWuuVzXW/a7UiJS/ymAyuJ6cfikGpwomT+SR/sWe+vqWPshpCz88EusKmqRCtCcyJSKZUIK9bLQactpoyqFEnB8clR11gnv1mlNJV3GzIfZxiwcxLZGtlJhhbXpdcwFx/slyhSF1fJa6BbDIHKnTIhBRm3GbnrHJ4q4CgK+WyT74sxYw8comDnGj8FU0FOJKjr5JtCgBrL+3msmlnu9B+u+cx8j/KL4XwjWXkHwUkNEdZNpKDTG+wT3iacXYTnKReWTC02Pqyr7Lp1kHJhmlIjSbVcbsUkLu+ZHnEQlIB9tc7qTYGzADn0RJIPBYZ53i4gt28QoZaZFYBIDLnJAA53uR6TXpbIYrY+GGVRhVCq6D1sh5UHCs3CyqT8g/bPKSEZcf+Jms+HIR+7MTBgETMNEaI93U6Cj4oEA7p1KfYGy64FnGEhjbHs656CE0UwNVJK4WSNu/KZmQ3he/gExstEbrk2hz7uRSEw/aP8m3PM2Fb5jJInfyVsCGuu5UkQJFRRYOnrDhH7OqAB5d1GicWZI12cNIWKI8GL29ZKLpLV4qdy1xoU54d+ZdFMiaNeImSo7lA+k//ihjt3HOfq/yyb0UppkgWbiTqiRTEpkcYSqiIkO89WKQIHMNJa2mdhmNO7ghbNxrhKhiwPdCDBGDNIOrVyzCitql1OEFZmQKZ+pyv59XkK1hpqZNrFVhrY7e9NEZhlrKRRkbgJu4FAHBgjeGoZg5PCNEz3EBMeM5/QVzegldFDVDQVndS00z0enWDCAj2/E/eysPMqWle6oqUaGz2bDeF+GqZUfRiup36NXzs3l7GLpjv45uFC5UaTDUJiEcV2gnBdrox7gqOqxBSYn11xJGZh8i0SSH5OsTW9xhfNrypI0jQpoVVAxGKMtbxg6Ajev/jAqF2ystruuvVMm26dJkI/0Y4sH2mf/fzRdtfpe9roywftisseG3yt27BkR6qjOMjKASaBreVX6MThwcJly0sGMvn5XVnp/dLV189zI66YMEAJi7vJlc73p8CmyV9vjuZqhdScWBilNcxJVnWo9SPxj/k8p9CcGQJgQ6as9DHhafJ41RIWJgrRq1U44qv4dgcOd4Z7sZbL/6ZomBUCKZcx0tJimuXn80MuYDDpi3CsESbtSNQ6Lbp0uQqtrZxOOl8TSgFNJlpebgdrtw5+cVWRq2f2kDQFUlA/kd/Zm7A6CetD9ecIKibsWTysSlilNVE2BzmUhPVjlW/UH4mTauBLKJK+6qCBfe87BgiW3FpNjPlAw3w9KmMnQZzgRWtJe7JkrYprtVrOx9BEfECaNst8IwrX225fceiSduJLX2wf/+Bft8GDDrY7bllpb77qle3k7jvaI77hse2bf+BftSsveArVIRuUIN9PcNq/WoFTtEyoF95MkMRn5pETGabFnRJFrh8gYP/hTTcB3uksg2s4ums4bCLVu6sh+taEr+l1XJgDqjFLxYOYK5FfDbG5NNVQesIy3ABBv0uLDIfFJhkELR6ppMESdm1sdarEDkvMLNFNJ8wHSBEw4Tx8Rx6Hh27QnW2tELdwadMIIZV/D2cTLo35VHCZ6F2uN7iwiE5y0MhMN7dqWJ5kqQLo5IAvw6K3toZg7DAGRonJA8ZvyncX/qtxrBKVUCl8aQwoTUDgBMR9CWKdHGvNK0oyCnay4gu0rGI9gbkVp1ru5O4ZSatBwtRzR5RjT9fqcjezCSE2pS9UN0lUswDyWEalPAdAfz7XPHxt0G56z+fb5nk3tu2bH9b++BW/2e697x3t8d/zhPYDP/qn7dDGJXgAMDLz7sqcodQCwr2K4GptVF2rey0CtJPLjgXvJ8vQRX5mQTQAiTjPotASrAQ7zyYqdAGCIxIJ1KfwkLgwhSfoj5s4HvndL4uyLJGwAWYXNYmB6Xxs7sus+io3k4fqQn61jAExQklVqjVJhN+J0XhfCyj2WKXxSbRmZmCNZPwFomqPQQNtNRodGbHqntQc5lurah4gbozrdnn2SiogC1xOuW9SKwp42mu5jM9kcKQOtCxWRdK5IVHnJkl1lzglZUH/x1grLe+EiQ5TjRBbGqSgeol4xMqEftIdDpDts35LS2bVSGm5yqdQGXxMXQirdJr/DK7SfWKPBeXSCsIPJzNYzAkgf0mQVYuD060skh3uzdpDSJZfgmu86/Yb2h+8/63tuk/f206+7zVt/ch++74X/pv2pCt/vZ3ReHCPPczdIUjrZQR9ZwtcukNSehUFXK0oNZLPze2jZeQmuGOBy0TU5x0RK49WiPD+n0TkVjcYlpfPp+EmIdUGJ4zeuqxItzZwAsROETwHE3JN84d1k2RQiEICev+Es+YZtSPF0Ri1FTGCpcGirVA5oKUTcch5KcR+KNhNFt+4gwndS+SBKOgajIiS7VeQLK2RyJUUrWz/WlyfeTUmHD5KCiBjJKSywoEB8jGu8FYfY7WCK8VKuu9yRVpqK0YliNVmTb991h4K0Ff4fUuKQXxjvVV0vCZbIQ+2o0/htHh4MEcKAlEmy4KxQMF5CMxASy3tAMCTHNYCiAkzjwZPQgjaZ0AyTMnMMDVTe7x37tqkfSVF8Xfc/KX2uZuvb6/50Kfa5z/yptaO3dEOPmzYfun3X9kuPPxPEODjbQ0LdXhlvc1On2gf+OiN7c0ugDEAACAASURBVEPv+1B753vf0A49+AvtGb/ws+0xj3xm29pBaJP5UI4rCNpO8CMwrbRepfeq9j1UUKfM5ZWEAMUQUOjnukIVzEF2xnLX+O6qNlTGwCUWkgl2AzAqAWtadElTjpTLhbj4YBLBqwq9cE4hQstc6noC/szGWzXhqJVzzQpgf+TCnEQxRiTXBsiv8QU7JQsuLRKV6QBlKiX93aVl/FhA5xVelzJZ3chCxbRYfCi+EutpfSwb0Ar7tJXwWkSIuVPlRS3mEy9Z1pMsW4CtucUSNm+Req0g+I4D4vM1JNXiOyNi+SCjN38vHk2rKdSwmK+ohCUWPISQ5L7LLvJwjCPAWGZc0w6pFq3yFTiDSykP+dx197Rf/pM/aEc//7nWu+9j3GO7nf+Eh7Tnvfz1REhfibU/3Y7gOc7ccaa94OV/0m741NWtd/y2tnLOVnvG83++/dMn/lzbOnOgnRkcx2iuIdyVG7PCxG5KQwxdF6AhsY++BlupdAuN1TxorR09aYjybL1feeNnE4Xvy7lEg3QwphsEkU6wAjFqB+jmNp9Z2elgrndiIEO/RIfDY2m2mcixlsVogvuuRaAkFJFuzHvKbiXKXKWS/QV0FTRWU5/6cfFabAMtLDObVdjx1k5Isb4KQhYSQH4mt2e2Xgtp/hLXMk7Zbo/0DkEAbs10U6ooYgmLkPRf8EASqUy4KQytja4mqQLTT2ony/KtEiUylRuyxCbZM/GQIbsiaKRoPpR4N2QHE7+812+b8mq41hUWt1pHtgSu1BVad763D59vNO3E2IZ4AEWatjoMWiujxaVxu5yFtgdO9Nt9d38OYVhqL331n7bbP35t6+0eVfTbOd/9iPbbv/b6tn/mkbjF01Rh7Le3v/e69t9e+cdt/LkPMmmT9pDvONie9ysvp7zoCbT3TDtzhmqHVZfZ4R6tr+94K4MiTYcKqDGhqCXeorBiKNGEGgZu4b4kXo0YVWavsfbuV6/5LGNQ5KSIJ/AccpR0JAO9UwSbUsqECu5Tyqd1QGpk6cU4lsMaybDMND7aem83/5C4s8YqawL53AUXkp5aH3LxTk2ETnw0ovTFRQo+2zrsGE+eN0Lqd6gfEji7FN1MgD2UyS+/31k2+Rtl1Xt5nfyaSWzSOwmBtVlaDJRHZdHdCV0WCVRd9YTOjlg9tD0eQ3eAq6h9GvA6cTxCwySHldxZcviu5DYocEk/+1uMeheTxG1tk8LAKQGJxYsXnkNqTGtGCmmvnSJQQbh2zgvpuxMSrEq6D+DS3HxksrrZ+jvLVLkut4MbKN4N97Xd2z7WBkeOt7/70EPaX77+pa2d+JtYRi35ud97SfvPv3ld631prz1qeKI9vHdde9W7bm6//PvvpKnH2vzwmfbkb31Ue9Yz/0e75/RB8qSU84jJzR7Ydl11F5Mm+u+Y+64IhzmoKpGd/ipWHOSqG1/dogLCAEps1GVKmCfL1bXaIZb/89U3EvQRCWGVKKyNURu7HwP/EYSGr4n/1P/zi+vg9gDeK1nMUJVM5q7kPUQbPTLnBUlMnEoRGDIrYAl7AmKhuJJ3CkOfKLvydbUyWKsjIOezrnpSOdBNKDQJNCJ0avSCyPN6rBdaOpU45L+RpK3RWydYMtiW6rp5hgKy6+KCgH/uZVQE8BX4L5t4l0/S7GfKiSjZkkWCNiy6SXfrscwyI8AuuD1w4HA7fsuZ9pL/+rJ28jP/g+9st7Zxbmv3fSncUltab0uXPrYNHv7V7Z884UngmUe3B114BIWU3DQ4wS1PiBC3Ntvk2PF2440fadd98l1t6eQdbffCfts5/fh2y3t/r/V2jvF8cNKc9YSPv7hd+9JXt689cqId2EWwPv7W9v4PnGq/8q7W3nXfpK1vnGnPevYPtCd85XPa8eEhAPrpSvEQiVoU6PC6jD+r2YUStFMBCwxxbM3dUhWhYzmJElx433b7ugfDGTKnI4jKe5mnO47ttWMUEriIOB0VJRjcOU6/8YYb50vWh+MutFqSjDu4Iysyg5c0zLHRbnSzxoOJiiinsd576o4tuhDdp3ilIA7vURUgIapJFAwKpjuspesZuj8ASVrNq6FVEZdEi/r3mFdDJAlbhYtHW/EpKMwCAmXcAcBdd5WgsdGGw94u3I4uxTAcoGs0pxbKe2FNVwDLmyZa1bZwUXKT8m2WH5uDpL1gQAMOd6rRTdViWxc3IJi6VLCcDmtjdb1Njy+3F/3aj7czd/9tO+/ch7RjJ4626Tah1i7/5Ky6/qSMJQCkwyZYpORj1hA6Xke9jba3dKY9tHd5Wz58tN26dX4b3/Wptr+9KTvMFwftMV+93/6f3/zGduXXPKktn0HJPv2KdseHL2wf+8K0vfX0Rnvf8QvaTaufb7/171/cDh94Qjvt3LgbjqU7cWHOfxUyGqiJ3bLHRqKwYvGDoUMp+KLyaFTwArRxZ/zF9os/9s/a9Aun28Mf+w3th5/+Y2155cL2FY97TLuF++i23TrByLP3m391E/1NEbZ3CFfiwgQjno6aKqflYgDLW2W2O+LMdIPg12HOejmZZy0YbtJ8VYC3FZUhMAvY9sFZc7kqnKEdMfoKi68F6DBa1tkZlWmG5WziLopF1/0UhRCwF0sl7hL7CHzzzFgVrZXCYImPlk2LyV3AQVPcjvBeMx+PYuZAKC1Wi6UzXVLljK4A6osFE50wKeCdyXAN2qPfXv3f3tg++b7/2Da43w6uzzYtr17Qto/f3eYw3M2VytVI1a0LRqIZ9JVC7/WNLJszpp0pOxtccxKXMz3D5cfaox43ba96TmtXfN13tI3hpW1+Fy363PXt7hv22on7VtotO/vtIyd67a2fu7uNv2q7/fCP/1lbW/omlOAUNIobnMGvSWmoHF2OV0GKuxNaOI+SwcGxFQ1XbZbj6Ocajiq8FHNZ2+V3p4PT7TnP/Oft5O1fbL0DD22HsNjf8x1Pa9/2nd/ftjc22r1T6Obn/dUttQtNCsRdWWP5LYV+mB/xwsR1/nR+PttCaoHsTIabqvX215KElJwzLSE4X+tY5W0lF3MpuTcyAgzD3gFArtMyxYJZ2qLlSU5NLdKlFjA0f2US1hzZInJK2KCLdT8vqxppshgspTTcc09X5j0x4QNc577bzLiSWdzoAJljBCOMzeOkklPtLA6swKkZAKM078fw8gAW+WDpUKgUH+62wxsXt7df83ftra/+pTbbPprS6dlerRGQSZ8zqFmpsH+yiw4c18Def/DTXzu3zdYO4DVxm2MoXzi8Cw5O2qufN21f85SHtbWNp7R29Ghrdx9v09vvbme+tNXuO32I/asOtpMo4U333dt+7+9OtKXLttrPPu8NbXP1G1EkSoFohVzfLmM+RklGWYWt0hTZnFVSClIohErAK2ymo4JjO9iaKo9gUzlDLmUcLVLs8wcS0s6BN/vC3R9pv/FT39N6W7jnLXDo8kp79OOe1H7gh3629X7rmpu5u1NpIJ0AWF+WocjWNjGTteqD3E/IPtMvta4O/5rVVn5IQSBuYpsGZO8kEYpuwA4ICrMAgWfQQUqwwRRGdF1i1pXUKbXV7ia1m38ZgjC+xcb5dypLXZRpqBEcpHWxCzVAtYla0Q1zSMB9yp9HCollwciRhoHAOnhPZtzKCIVOZr8KBzvWXKJBIeapu4zBuctb7dT00vaK33wWeOqdbOngihhutnOG+4JbxjsJEFipQB+Bvu4s02n+AyWq8CrPIUUl4caItde/dN6+/buehGW8FEFCIG+/tU2+eKydGJ9D+mUVCA6jzsP2ZifbVZ85p/0R4Hx4zmb79y/+rdYe9tOsw1BhGIfsf+H9ZdVq/wVX4PheBSklNSFxAhc6BTYNp/B0wuQVtYdGV/mRXXdEJ5bgVIopvBze4+Bar73uDS9v1/zBC9pkZ72tXvSgNj54oPWei2ANiCuN4rQ6YZHT97pBNttisC3VyBJ6C/rcdgiXMB0jIebWbKrRktyO5b6pJ65I0vLXyFZMQ0V1Wami25Jlr5E4SyIuIZwueaoqiupsWhKiUZZCspUFqpl4Op56I0s6CudlayGsbaoQtKipIsXZpBqyz+YiVElwX4Vo0hXGqTu73stsfoo8i9LodcvTjxOdfeode+29f/ZklGajnZZbws1Nz5xq821cXqryLOxzdrSSG6138EibQ0bCsWDycG37/MvE0i929vPyF/7yRnvOL/xQa+95R9u7+7526tQFbWdnr23un0NlBNZmeLJtDA5itI62F79zu73lxhNthwUmz/65x7Sv+qE3tf2tWTuOBRuBwbS4xaUZ/CgwXYVIDEQpeVyb1nnxtxCBfpp8V7AidHZcpXYK5TP5T7rB6N+xHXQrjWrXmSowWF5daYdxj0//0X/S5neeav1tKJfnXvP5iNLALQKToysrkJsrmeKebDThTcofh0RGEKX8KzdWqZu4BSc1rsTVI5IxVb6bMtwFcLXRWketkSGI9+34qWyuoWVMXsrroDf4xXzASMY8zzKdoiDVRhcpMOPXcXYrMxdZaZQAZwvjeFb2WrNqwMRucnYUBsLOj/nbVTLZrjLXuMwfC7261zYor7hldrD9zOgn2hWXvK7d+KZR++bfOtDuWcGN7eOmzmyGSC7rtPihZ8NzaHtXKnPhQ1r70s182NXHexnBzy//xKi94Cd+o93zuudCQlwM5KitAMxKbLhCvJ3X3nL9Pe1F7zravnRCRhtS9PJT7cV/9Mft+OoPoXw78FHmdx073Vjh23RBpQiBWU54IUgPfF20dhH7ZuZTr6XA6CqtxOBv57XzjwlyouD3V+fW3FVZ1ZFzRrD5r2kve/aP4Qrf9Nm5eakZcfeSxX6ylJUDKaGJyaz9F6L5WplIq+QeF8jXmGB1vAC6KQ60AlVALqkt6WmkljwZvxNduZpewaktdMR3VdkZEKmYJxo0YisBSI7R/BmWUO5pwQS7IrkEXetmRaSsthWlKoGLOR0st6QsQrMWGPjAxQpi0lEuuTIXKU40U0DgMV7n6l0Wga6das8590kQU4BUBd0qzu95XDs0vrfdB8vd261VyZZ2ZwqDXwqr1s/97qfeLysMSdb+2Zdf1l72vUcoYzkKT7YOfQP3xa4rR8FSf0Yy5LUf2WtbWjq/ghn98Wccbk/9yY+3O6ELRlATlrKkKLDDTAZI8QvMSW2eUgKVmYkVut/VxXg4xV1LpVAWbrIqTKq0OcU+JQqlpAVJM9YWKGY9QVb6OKHyWs7PUrvwPMD7i950G+BdM6n9NEKhZiA8oMngciMFF6wP5zoER0Z9CeFJ1s7IULfD70ZUMyKj2txVXOamG3xf98lN1akVCvMsR3FvBVdI28FUQKRvuj1+kbW3nqjbecVCmOlklxyacM0l9VpE/rnem3VuFSkW2Led5jPde9T2L4FNYoN1hck0uXyKKVHLGLUYVwtxsniE8cHu7xKYPHL13va95zy65AFv58/0Bvbq+qmHtBU8327bCu9mlJmwXMBlaXBcu36lpsAfJ66qAjrB6kHb9E63iw722hMuP58FHuvtnpNH2wegDUx2O0lRguxkvdue/7vf2I583VvaNqt67XuKDLsod3H/CLPNEE8l1K1MiNeXgJV8BVfFDwRJ5bdQEYkvqtat1jQA+r1Yw+LMaZkjpLYrLFHUR8rcUqE8A6NxjiXRcpHPJyqUMFQAqoAOjGOYnyii8I1ZexOoRtzZJ8prcDuuzHF3muku+/G5NLvwXrBMlok52eFCBNgdgIx5LrLUZ2XRpbJka7P6hA5ggmsrby1QNVzBF3Zla2ytlwA+dUGVT0u0mpREV9npUPIdsYrDuqzwVU1ADIvM8x6W2H04Tfoa0bkTnZmBi9a22tPPfQSgmAHSvCIzLu96wa/P269//DJc6FbbBQu1MXtGO3ElPkXq+tyY324wOlhxVsoWlitf6sxBJkzxl+tyQZqBBooAaf2Gtzyrnd74pXbSKgkjVuGHV9jlMkvUttX+ZALsrAU1HUdTXB+6LrmfeSuAk5xBLJht1TuFJg5pbITo51kwYWuUvgD6rl/dPXzbLIVRuZ8UbClrGfl0el94za3MSy1gDFBGUOZanWxvY9TSgd/k3uR/ZKjNmZEJx1pMdqmJKma/3GfsQynnYnFA+cnCtsECCozXWgdlCQlCKmjunGGk32XesuEKg9UXJoJdcZwRVRtN2Cp8qZy0OI/AgOU0WYLOYO1jQeS29rJPqeNau87pRpetX9KtugMeDV9hBC30s02XYLWf8eDzCxJpqUC2clomDja+/6HkS7fIULB/xNY92a+iLFOn/x0ovl+I/O0BLvDstYsrOgvWWY4AYhTGdNpF5x9vb/iLP2/Xr/9fLHmjhgy0r9W3vcUv1p6xuiE9QTbO6yxSOKrOYJaVWfizrmY/yuBeX+4XZoRcS9rMNmhKungqLjVMel3C/3UBHVe5d4bCFYgTPFfzoieIq30B4D1LkWTIuajyYbW5WBaDplwi6pG9n1LznKEscjOpky6jm3BVgBzTKofCxMPYWp8psSagdMGoEUYameXfstwzorXabyHlSdZTgcZdomlVqpUItjv1VNxnDPHpzivS8DO3CHJADbR8hWleNjGddldeT0a9truuKswsvhXXlTENM7/lpEEAP+fB/7T1znys1H+HvkJLef9T72/tyAsvadNzIEZOHi+39w9+SrgiSGp4XF8pS/10n+X3hUDdL3Rxlwnxe+0x37zWnv/8m9uX9twPg+VqmVkFSPjgRr5mL0x/iSV1jVVy3XmzWOrKsGj7qm5du5T/aFeV34mNJbaLbsn+q4zPKhhu20Kg7BQkTeMw17oGy38itPYluGpR+Fc9NOuxqDbuvfDqW5WWWCGv95wJJbw216gLvVF+FxhKmqZcdcHPGkkoqnamQ3d+XxspaOFhS4DNbJHN+1Z+puolft8qSvkkqwTKMjmULjer5KFWBjo2ZTFV1yVhWyto3OCf+yT1JLC0CNB0kyi8221FzSSF4/2D5xJkBA3n+VnL5zu0cY96pX9x6Jp2Re+ZCVoauDlbpBp4IlzLP7iKO6RoBeJ3vgWznsMLHihcC8FaCNBCoB4ofQuBWrz3AMFKOUprP/OKn27fdPl/aXeY1zSn51wmgnIXvbIgqX/oBCleoZunBUiXXM6hEDu7UCvCCyoprARJ6XRoYP4ZUZo0pm+4nNrMjWeZnGcALLisVdc9lK4gUbYg8PVsluMfqlZK2jur3XvRm78wd7lVVWhyZ6sWJBkNM7lJ9k63F85siNOqgMwCgc7dZWM09dAaK78fwhNdYfcWt2F0oWgiMaG5m5/JiYmJuIdaaLmLeUarF5yqlawOKdmCESBdwlODvew8jD5+07KTCJHaZvqbigR3ZNk2BHc1UIC8lqwS3yP2Npi4a6ATGMul0ilmAvhBuw9a4TfPheFSXk6VQUqJGK/vv6a1b3jl+Qw6KRprsai47OxDNLdymw8UpIV7/IcDX1ZrYb0Wvzq29vrC9qt/8S/blZf/Z5weZUk7ZDZYb+lz5Owsca4OVUFgl2youq64KEF1ucmiEUvQJwJp3rCeVx/g2CR46bIO1oiNU+WrHTCCrl2ou3XuiYaHYUcrAlxsIGyLzdvaJB2Wr7J51polinwBBGmFk1U/XS5Z7dbfK0tYAesjmVD1PXVPAe2dRAcI+h0G2EgviyJ4aEdkStRp3TSrAu591xKKxAwt+ao0giuKZe89gqOsWRUU6gLVmDrbxYSuCzWW0KBJ6rx2U8RXAj9wV8KqHiweS422cA0B1DJZ+uHoiWNykoYWTtcfRWFQtk62f33k4bXbsik+Mi0h92nPg59h3cZB0lxTBBeaQcF0IgSsdvasUMUZ/f/4cUbKWoWFY4b+3Uv+Zfvar/ldFpwoPEWzZOtzxtkFEglJgmO0IvXsuAWfbfWIi15T9Wp75CWJhl2CZlmLY5y+GxVW3ZRil11hhRmREMe9vIg/ljbFiSVyrrxhSo5DRrsVpbVxlWt1jOuQAhCxJLv0ZQTLqQ414C29sqKA2gAsssmkkWClKqGWK5RPL+qxzF+YbgbezqZqQUFTcLhi2bVzAe7GH9W5AGuZ+pjVxCApVHbii6TVrbqTr0Lixvrcy62AZMMZxHUa7zk+KZ2O0AHmu30/dXDRcNulyw6+8/ldlKvWMyIW9SnErkV80uQ97TFL39NYmN0GFBRkDxJqjsZsx73ybw8RGHCheM4VRbjc8FeOTxcBlmz9nyzV/1vWVBRBkH1bak945je2X/+pt7Q7qYqwCNZxHdIXMyFuqWdlbHWnLG0VKHYb2aUeqlBbZiY7JboQuOihRXnRPkrmKuzCR+JNU2+4S92mM2zuVJjj3l1J4Rn1Vbn63Pq2zJNt6KqFfS73dxnJwvmv8Z1xaBLa9lvXfI65lGawaVqEqs3J6ptgkKL816AfttEktw80cexaPqsmA+6STLZXCmHtD2B+bux9O7OcoYyLLZKz8lSuKzTBay1Vt9uNEjtk4mCirbl3c1xTRN6/tjvco6xHEiLePrrsgDpIRrPZx8D58BmxjbrbWtWTLROVfaJQFyxo9+SfzqUs9hsu+EQ78MHvaIcfVMKWH/t0qt8O/Edqv28nYbwsxeD6SaJh7P5gd4N7bmc8hAalcDgLBfb/+NP5DZ0GLuGKbzvSXvq8G9t95PvCo8UodVYw1qrjmiwtinSpu4ybG4Ho+oJrjJBdxFIWzABJesQ9VJddpc0oWWacFUVaKNvmfXxYPTApnUU9v8HVHt8dgSMNzNzayB8xVvKEHfNe607FZJ2n6+6brZqeH4vVWQg1Jai7SLiySvpmFiowEIbkmVC+sWvqRhmQFJVE8WuxWDzLeqZYnq7d1Y8w4sFESt6+OwnXABqRnl0FbYBgmXRHmMYpPGCw1TmXfQXf5Xaaejk3aYPKOda+VuUWfG8Sl9e5A5UHpTEQIegLg/xoiuIefFj896E2+fwr2+B2FiScmbeHHeY7MA82/s4vyGW1dv0dS+1elOO+09P2yXt77ZY7WvvYnYDfE66tdBumOh2sfMT/14+WqqK89UdM21+88iSrZ+DkXIdlaZK6SXuzBiGwJOnk4Ce1tJj12vogXGG3p/u2pHVSGgqX7sE2qJBV6r3Ys32RLwwsUAgfENlVEt6x6SxjZq3GbaFpRW5UpG1Q5VbddQaTRsaQQCiCOjz/6rJY8cN8aHgf8+nFipELS/Gnnms35tVTINzPQA4j8VXcmZJro1z6XtZrJYLpvayEMOqsQjy/ZYGeo6/5dcdm16ilQzY5uxeLEUpgTC5Yd76YJ7fsYWdHrL1A3g3FRPkKNnfmnrXEwzGVHnGXQd2BoFPtLj+SGn/3qWDB4owSm6dejpKsnEdS/XQbb55o2zsnYMBvbMv33N1O7H66LW3f0CZbqBbR4PbgnnZwznU88h4KRC+1UPTe1g5RUXT0LqqGD7f25387au8/xnBTyWm9falnp84hJNmac77Zrv7YLVQvHMa9Sz67GlpuqUq1i3oyKhajVl19QIkZAz9jTB1fCeisd+R9LXU2b1Fv9RgKZrCRhz4VT7VYLOuryi+mTXot5gTlpK3CSzfeM4WWvRpcvxi7p8zXnmbOq88Tu0qoD5ir/S5p7Qqq3ovfeNNcP2tjQiyYNC5xD+hVYzzgqLgS0ydEZTRagqxoRUCJYb3r+ztuaCJ45H5JoVga0pUJq4kW7U1d3cvnSZZq4vXVSRxXpaiAvc7H0+0obAUgg6Nct6hhzDbZdcRHCm28V/COGK86XiU0AszK7Fs1MYIU3UHTRg4MI/NlF83a5RvUMa0fyCZoOXmC+yzz+UnY9XUTnozDiTOw02NKZNgLoU9aarC0RrnUMYjaWdtitbSVo7fedbrdc+uH2sXTN7brP3pz+5Gv77ebdgft5/8bA8HhoSEUxJ7c7wef+y/b0/7ZH7Zd8o3mF3RdKVMy+IkrrRXTobCy/WVMfipYTXpPcuimkXtFxv5oUf1mUDLPSTDUfVa8u9e6ctwcYPFfdeNaQV3fLsxchZEOaqXrTJtJ+knz1HpLhZdrxYQWAPK7W2+WG2cO/ss1t7DLjlFF2Sh/7EyWM2hK9d/gEJ9h+kaA7kapOY0B080KwdShG9ko09aLD+m8IFBvlpJ2I0rzSaiaCy8qRC6aS2uWyE+hdOJDFBZ7a8rA1JF7+1f1QxUGCi63FXSwkYs6ei5Rj2k32LCd9qMStA5ygoyYc7kYFgbw6xoCtr0za9/xFbQbDRh2Que5OlIVKld2N4bEtb59Dl2xDG0ygfE2wh0TvQmqd7E2JzcROPOGYMM7bj/RPnHzJ9tDP/TD7TuPYMkOAB+uaO3y/7Ta7rmtFmVc+sQL20tffkM7TdYiNfwLWLdwf1prMaI0gm7Pagy3kFTwkB6xk9tS6h2mYXD1GF3GI4IlFtVlVqKiXKJjgmV0raizKyjPd5xne1sjlelKFJlfI3cqaTj7ot9zr5RQVWicbZ0EAvcLMW17Ea7QPI/nzGg19Jc9T9ikxl1s4kOz1pmaI0N6S2hnLga10xKVEpZIjydPraekpfZVyOJGk7uZ1ALrQAlKkFXBBZvvnly1QZlbGtmLDGa4JnW26rKTII1clJsUCoxzwgDvWVMVqydf5tmK7vlQeUMXV2S/qY4JN8MQ+Ml1YqsVBvmbHgVfxBZEQ5dt6TItGlysYeS+27hcN16zInVvewciVayjlvODEI4B3Suy1AzC0TO40a1Ju+22L7YfHT+lzTd71FjN2633tXYjkeYzXsVAUQHylg/e2Y5u4zvDGZbByaFHTlqsQllt+xxIkMCkA7wBE92uMn5PBRKU6yKTXSjaYVFXVZG9DLpj7taeWBUXviiw4eDuF8gUZhpZIz+uyMqZkjzDpWGWn1u65GRYSSHvyPqjTqG79aK6IH6yuObFV98CHqxGq9/u0jvLMU5qlyrLpIXm7RjvmNHaUa/SJiV8dThA0RMDBC9bItFhzab3Vqi0nshIugAAIABJREFUinY6u8L4eey8ZJHly2VRzmqNv9kMI0A1K1qna3BzfjVHgS3X6TxPEehlBs9I1Lr92GqxXcfLZHWN7i/XmxIBH100blccPIetftyol12hoyBaVxl810MgfNQmOyG7VBbUPSSMWaFNrZb7fsZ9IyDHj7GTC1Wkn7jpvvYTxx7PamRSjQhTb51l77yuXThvX/3C9faia19NWe9TGWOs36IqgN6kMEkD0FmNeKFOgIt+0Y111tjafPvOf7E/jn+hUWcrXT+7eCJjGjukD+AFhRT3ZrQXn/m5wmii24+1jkUk16EDnnhW8GRxjncKazo6KLvQaLHybCN92vu7qXlfrCxTe6z4RDYZ2W13eQmAtBk2iNA/G+57xG7VO9m41AV5lmBX855wM65RLKOUFwM85Hue67cqjSGQTH+y5ViRd0YjYqGsHHZJecmZNWBJTFs14VblCO7Es5kVNi4JWOxyaK5YXxx8IBYsc1+piTpmTuBfdQ5PvJSN49xndANTjkXSrVtAl9wiSmAJ9RwEvC15i3IJrN2/9PRRbCn1U6zjp4cTznmetWPbe+3SUze1h33oyexpS3/RHhlw04o70t707x1UHT/ip/fb1uZulsln15xk77ufBDwV6MR1abFocCBD4tpyUY5r6BrH0H4pmIlhDML4pVvUErPvo72vQxmuquMA/Ig5XpyUmuckPCicXUeaeBREgXJFJ8e40Bj333ezPAFDrbGstiiwllk5d2WxHPwQmBXGO8vhfOSqfA+wYz1ThcAu+KzjSLw+O6PEnhslmCStFTP+uPq49iyoyKNCnfo99VtGGEXAB18V6KxNzGrJv8vhpQtqy5EaaMy+7tdFolouNSxHi4Dp5KZCLZTlS0TU1cHnqB6e5/S4j6p7L/zji0kNUSa8uoa1sj4eNyiZu7bqOT8ECXzJHY4zB1joTVzrjiRpl9HZ3KYOnVTSNuTj7X/64vb0h/9u+reHAJ3eEqgy6J5kwhZI92C1brmO8fxXv9N2r/iZtsTC1b2kNhwzR6soCKfJfKmTWB90VsUojr8UVq225T51um1hqtAuOkZTOCpUvp4ES6fENX6ZF38NGA1CjiJm6yWa4wZzhVOLn9dsZC/H5GeVEYOpEElpTHHMhbuyGMZv2ZWXXP0FCFR5IEk+LU3OQSiPFG4CKTVVw42FF54aoSugzC3L7GtbI5l5+anqaJKGyT85FLzhTi4h16I/ETZXSysAvp/uJzknQRuJjCnO2TnVkGiD0Z7L2/fxWUZ4Cp0a66ZtsY8ogphOeVMY/dwhCN+jkIXWHnGi6y614oP2zZdIV9Qmrq5tcCm86wtHpp7cehIrZhvM3UGlsuB13s7suomc+UdWMm1tt9PHdto7/+rt7dmP/JEkrse6P+5lZfJRBIw1qNkqqH9Oa3exVOsO8NYlP3Mv7v1wO7a0jQVQ2LHkpqWCSwtQ3r+wgXvpajrrUhbcFEoljZWg2DwGd9nKEYUrOiyfp9A6bh1dE2m7X1Cja4lGCbqw+hqEoUfYES3tuzIpVlWhs0RHw1KZrlXHtWqggl/duEWguDgGOPtovPSam2Jf9zv2XE+ZbR55zZnGTNoqLmGsZtlh0bCFe3RAV6WB23ffJs1kdo5wEzD+tnyGzxIVRksKQ8W3ayE7t7fY3K3URMEqPKXQCRaFcGeMkGJJRf/VgWUHFI3JNkb+7veilF1KKMreMcpMikqRxUiA/1UGcpN7PPYi+DY6t7bOwLmcDPOp0mSXHQR4DXdmFYP3z2n3KN4OvnhsOctgiwUQrV33qTPte//RlyFFNO+z2RSybSJMMv1gd3iyXvvSPVhJ+C4osrbJBUuP/qY2/cfvwMrayCqFcTmweyckWgtmctLta8GAbPstrkEQZdj3MZuW+8yRWsdWI2JclK05TSyHNyyljOglQa1vr/3HsjVCLFvlV33PRGnUPYJYLtpc7Nxlc7pTf2eeck41smEqVrqnPC7KqAGhAjbk+kuu/vx85C7E+lQAisShBF5YrZgf+aWasKBpzLpZ/5RDmfjUfOvSdG5QCUnzdNjGM2hqcWlndfS/3Mfr4pa6HWZ0t1lU6v0YENcKRqK6Ir19kXRKp8ODxB0MXJnsvVIlkbGBxHUAfZ4nRZTlD6xVMLini3AV9SVWtexglR5Dbfaqx9ozEUvs2bDCUqY9BkY8tYOLW11m8SiW64DHo6GlO5RH27Yzu8vtzPFj7ZVvub49919dxb4Jf9B6kKMzrNGe+03x8F36fBCy9Asw8yzBa3dhvdYA8vvQ/e5JtfPU17fJwe+uig2u1VWrHJ6XqEoJkjPq1Z0I91nWPD1XoYr13uICv2feLsv1DKCioKSinHMUf8U5EdUx1juCdLk8GUCtmvDCI008KCLQoqLewsFl0aQqUnRpiXqspEZGb2pZkgYLYUc2VIzsCvmyv7o1XlJzPHTVi4leTP6QAvN9qjE9kyW8Bjdbdj1/BK8WnU7dmgct8hSLFQ9pjA12INCi4Cw7U2U4NrWoh3JuRoUzGqK7Kv0sIfAGAnwXiqpR4r0JLslKBx2jyueSo9qryY8Lm2UgcNNqjaU6aUtnzUrzYvJidQrhLbWHHzrTDp5zgIneaaMDB6JIK24qoWJB9olF1tlsbT7j0AKWwM/7O+whtdLuw5/d9O4/a9/3jP+OhHyBxZqMD9aodxLhOz1vd97T2sMuA2dBmN1+J9aLNh3Q1br1AG7mFMMMhdXueiI17FiesVhUPFRGOwoWkJ16NJVNO+jeVSVssfwy4inEEwJ05xCJzSI+KJvl3eAKttAKLRCI4D5T0DTZSJe71IpoQVrtNaa4yEEu6ruS7rF6VqzoJvZuq9C56syLCq6Q2269m0/n/XVPN3n5X9/hnbFWNBJbakc8isN6rCqT0MVVZBf3SONSoMxgyW+YAoq5tWFaMoVPcXKEbH7INceiMFaK9TuJn9FwXVoZ64qIkvoyrWNBWoQhspXGa61DRJbtjcsw8Wy044DWIoLsHRyaIQkhMYSDz385ZcFl924cwqVXnscuNlphIsyVw5C/RHkHDsBd4cP6I1Y2c+7M+eeQE/N7W2eodV9un/zcbls7+vPtsV93MSmbF7GukJYjVNZHsli8LDt7OszhGHrn9dqJO8Fl21gDCtM3sFxGtZuu9MKC3frw17STG98VAL0bgXeEuUMWBnf0QKc05T3KqicaXrh+sZTj53K85BPLksWah9SsY1dq10SplsJxvq4kSCs4czagyqqqAjBlJVVkXaS8li30A1/Z+gjhNup3FXfUNYtJjLz5+3+8HcHqsuYue6/CCppFSG/Zr4y6m5e555V8likHrZUddTBWs4Cx9Ejjqk8K/9QJhGXHWhvxV5XEKjQW8GGmEeBlNEomu2incsJ7SNeKxYIBlmImo6RKQVQ1V7xX8F+2s1bj1SwVW+Cn4PpMrK1cUQlmDe4CvPr3peecaTtEdhvgrNXRevo64+iQxIAuxEVJ1piO0+Cxg7T1ts+M2+//98vby1/6GoTpn5YF+SKjtVZjk8UX5zyZNgCyTt4Cl3UMgpUmQqQ69FP7ZX+JFE9Tw3Rm+vXt+ge/k6NUUMXELpbKpIKdtsYnFVka5TRIUrMysxGyRd7P+v0liNdTbulJ31f0ODlFjEJLS2gkNBNti9l4Rra3Lj4x+h+IUD/JfHTPqI0RnDNdcx3R0nnoKLqYrlYMldFJ+TPP2TGI+5/vvBNI5E7CdXSZkYnSPkv63NQC0okFWZWVpxHhlJxa66AVHyZIodlDyyRDPbw75R0RJlaLhEeSkzIa1N2GLOfHU+XrECZ/uui2LFxW3lRUImSQUyoitsNvtDNpqGi5Q8T1HuYZ5r+UIXY0gEHCtCxdJsMAgX+7/Lt4dhSBZOXu0sG2Sm1+jvGlgWurG21lQ5xLtEYe0ALF3buW26/97lPa6/7XHyD5v9/mp15OUlpy9DKsPSWn+5uMG+Zo+cvx4VSK3Uce9cCD2plbb+N6stSEle6bus1smjQYD68goDjUPn/obQjMRjbf1ZJGaNLWTjmdBgUqCuWGsh4AVQolsO+Md4kalqXOeGTecn4zbo9xkZrxrGfnOdtQZouEMiAlVHVvf1J5exZc1Nyo2Gffo4n37+DnUy3TqQDDjIeiEVz2l++4mzks2j+HUuEWHEjxk6s0LFnOkRpMoue3uFeo0+kWkBaBiWX2wDTLToyVEJpw2qZLW6Rmav+HSmobBRZDYv8LkFamoCMFEbY+Iz+jhMFtvaUsPMemUFiZ5wiLnImD440E8ty/au8Ls1nU65+5b06xiFyVe2eoUiN/+vp2mHDtjhP3toPra+3wuefjNsbtwMYhhGul7W5ToGPCfLvXnverz22/87JRO3zx17fZmTez4OJlbIZxAfdBsNZ2eL0U4XooS3k+gdR8BdHah3ngd7Wto29nqRhbMZKEHrTb6etl1gvyD8w2OK/dufystrn8PQiomI62pW6miiUX6w6c52wsHAwV2Fw8lwgnlIrjY0QKVMlpGCqhE6C1Bl2BZbMtelJ2LibpqB+rEZIZ0fp19f9Olc+ISy2Xa6VDigZ8Co/1+wurqRLEwwXi2MSqiuhd9e6jsW6mBaaedGV+rdvTPRfFtTlhVVetyXFSE93FTFejtRKWacj8ymklTuyuSyrALa69g/thjZh2T+vsDjbaRYtZBBzMlOropH3k1jpTzHPqmJQayOyR6oB2JrsMea1jrBDKvzs235ROUkGdaOZMwTo8aunYp9sd9+60C4+sYoDp0QGEax18xLPWAPU5uPJMr73jmje2f/GDt7WLj/wAQoP1mb6CFUafoC2P4DGApdAtXwZFcSEu8SI++3vc41Pb/OQnoBQ+ibtlf/jdE+WerLeRlcda9frrRGgXtlvWfp9IyhwnmQ7+y15c5gzjQWiMkihG1WOERqjKTjUl+Kqb8EpfBRR1k+2xwDVfYuFkNsqeRHCsvymmX6PieHeWMgS2nqI8RlYDaZkEuUljyQGUIUg0H0tvJka8XEFI741/fyyCVYX48jgLwFxSm2Sz2hM7U2mFswViWhzDWH2sbsiITVCpEaJBqXTQetkhXWrMbhzoWfJOKchxvWlEbfyWTSowr7q7iIz5J373uF/NsuY+Ya7/dUt1igaTyO3cQ3xhAeJ67bRMrshN5NgTdHrPZ9rRrb123oZ0y14796KLg5OWDq62Qwc32qnTRHC33d1+6md/vX3iU79D+25EsN7Cjb/IWF1Jf+/mrg/m/qD2xqrpMQnC7Y8Q1Lyf5PSj2gZYanNzg7Iaqh+slccaetzIDAZ1v3cI645/HKy2L/X/IwtPHkE0bp1bt96ADonxnXTTT2G1xWBO7Fmg7Dh2G6pkpNwE11ydSlyHNtShV1rvEs4SrvoJrdDpW+4ZqqPGq7xCCdPi0CaFzH8xW52gVyWEM1HC6MfhFK9+3zFRUnx3kXG6MBthzREuj2VRbu6f5d6Z56rRik8PkWb0pdDBoyTnqGmuzfxNr2Sxg3/HYjCoJvip6xUYitJ0YUpUcvZYkqQt+EuLZXlIQlkEykpFqYtlsRSYwa2ybURaojm3ZbpDLai4TGuqtkfQa9Nat1LKaWZSFzDnR+/8VPvsTTe1Sw4faudeeLidf94RFON0O3w+r5jIzZN77QPvfX+77Ip/1/75Uz/Ora4jcma7xtlD6ASMaCod7C20ev9BLAv7W573RVI8JPDZhWbzzDYbyxyizuveOrWWwrelIcwSLn6fjUP22bOh7V7ZjrPJyO76v2V0hB9a+oqnHDrXdyb/wKMSTZd8ZEwTIcdidcpnkl9BSLos5jtjVLJQ1ilkawSkhKwLteM+g1gKWodM7rmPayLBkgtvZICnxVscZZfCyjD22cYjy/JdBNt780fPcHRflbZUjsgHBJzwynbb9kFLFOl2aqsYTbdZ20hrwfxeWayKVKQoukiP0akO+PXSIqsjFt+xxbVNt+sZS5NyBqqrpBHoRXVMKATuj8einTU42Y0uA1btliKp9hdN4v2MSq2TS/W+vJvgFgwwgpH8yN+/uR04j78R9PPOO7edPH26fdllD239DaJEeLkb3n1H+1/vfGZ77avewb1I7IxvKoKQhFZvfi8QBguXQkcslYHImet5xiXt2L23I0CcuKEFGp8gFWS9GH+DsxIAOd/D8xOpjScI2NKBdmr0/RxGdWm2247QpPnVJztozVP66lwoTlmjUDplMbTH69bBC8U5Jo+rIHZW3wuT903WxP3KCryvELHuuTmdcMF5THailDVkPH8abGk9JX19Z415l2rIHQzOUmUqzOl03Pfe/MEzZYii8XWnrIqNlFfiM7VUkdwSQBdcCODML8XCBjTnl1ifgpO6HMNP28JDXd2SrrixfhXrRdc6YTZ0ixsTcDpoLlTV/cmZZBC9uiInl6I5vObzBjmDuUi8VFpGyhS2jsgtRw+uqy0mXWyje7bJ73j7a5j4ebvwovOpFCU0h1B80EVH4JzW26l7ttsb3vbK9uPfv9Wu/Or/wH2xUGxv5F6sPTEQlq2xj7rLoOZElhMiv71THu5NSY0HVLFL33QfV+lJrqnhhUVCyIZ83xMze8MDWGsPID8XSgSSdPCo1j/8fdkMsMhRGmhpNl2yCzlAKopX2GbqAaJdsObwVIK6MJF8oh/6e20fpXfrrF0313DOoXi05N1KvODm8GWZC+kkvldboNXJs6l9814Kem7bGYo6Wtj6roUg9t70wVMEakUDKFWu4asKTBtp7XkHEDvpK2GpSRZzVWTn7WRnxT5B3znm1gjScuWuEj5VkCYhZKN8oGmZxfFzWZ7tIlmfH2tk1KeQ6XorEtH0ewqWizWsw48rMMq0Rsqq9qlLZ4xqzRowOIyIWqUmxwpbQlvOM2mbt119TTtzmvutb7bLDh1qI1j2Sy68tJ3/oEva6//yde3jn/twe82f/QZXm1WGTk9D2GzNFTGzz6Gh5GxkxXfXKDG6t22y0dqYdM4cn2DJ0ZwFiiFnKcVZnq3BVN/G8y/CYrH735DiwtnFyBhEz5T7WxW78cNYElb+0EK5qZSfxCoV3pGSSDmxyo2wuvzRrL2l2nVdYdSqtjVyrFc5tCoHKMHIIhQHwTfzxbPOwoxdDNZyLJtC3e0bpmx4B9vUzXnAeofDDK68ZwRVE/LXH9ZiKUwFvbLRf853rcmoQv34sTyoxK8L8wXsi1aZzMwVZTHqBHlIaM0933V5lvutOtEGmdrN7J4CCM9ke4SKrHIGROGMKas2SFPoEqxzr8RU7ZhsKY9JXMNwa8j8flcrblvqcFC1vpjmSviaXYCXgwj969dfQzqHAsGDt+PGDrVHP/zB7ZJzL2ifPzZqF/RPtUMXXN0e9fhfoA0A7969CAA79c1dJv15mrdZm5bMwUfjzyJMV7bNnS9iueC8xicTZMhPDRH03e27k1BfAqyPZzczsRdgLTzoAKgxOIw7lGuattPDr8FaPjFWKgSwYbYckG4t3FUCvlTV7jmhun+xo0fw6q+sRdMoiHkylyVMGbJYNUYjxYwlSeLekiulsebGcVexNXqZUd/qcF2CQgXAqpJApZpLb2eu0yVkrp/ITonXfnQTArlAbRiJfKk6kfgh7dRXV1xVEULhmIWYRU48Ed09GMRXWZnrimm5LxYvKFhiAwZAIVHocqJ6Fl3kyMtamxYLibwnV1ZuVhs3BZi4tjBZczGObL6WFLpinzrzJdIZ4jbTCdmbyTYLzoS9mmKuN5wWXzhoYhLywe2977ihXXfjX7cvf/g/anef+BLLvVbbY772ie0PX/Sq9vob3tS++Dd/yC6QF9BpTn+ghHo+Ow83eBcJav5mkUS/j7uTd8KCbu6dajubWCKs5v7+MQQfzMXaSE/hmLP1uPvEe0SxK4dW1uT8DmXGrPV3L6/V+ZF2aomdlDdITGc8awJTTidH5GOYQS2tE2ndviebZbGLHCHzIc2TWi7uIEPhfXJUVsjp0vuYDLnGyFJZJRU7m7F0wD1ARisfDOsFjBuviwPjFxYm0EbzljGV0qn9Z4Pz3vbRLWRJfKKPlp6vTSEs7hPQJbKKRRG+aEEKpC82nPWB2cI7Ul2Z7/qKeMRQxg/cG8LFEVgl3NNcQnZLsNNVSWQfde9dhKhS7f0sDTEDkK17lOIud5iqCHNjCXGlGDrNNMjm97K4tt3/70hY32GC1E6jR5XjUx/kwKL3/xnVB/T70Ep7OFtJn7Px+PaS1/40q23uadd/GNAO/unN3V1GxTGi+wxR3sEckn6CWiwPR/AM7d29Ewz8MhWmFB3yneH+CebjMEIGeF87nw3nthh8DjsHno9I+cxmh2kJ+UgBt5iBVT8e47a//m18fjBnPbrKJgIQIehI4lA25UUWJKbWTbtdW8y54r0oCKsd1hl7T7Q1aMhYdOZAXi9UTP2vqImzOK6LEKUSMr81btn3QqElZZSycA2ArcnkIOx87oGicYVv++hpFN8KBnJB5vBskF/iopw9WAJbBJkTGcui4FQTa/MJJ17TX2Ddd1KUp9vJ/u6mMN1swn0K6D4VFJ6WHkqjEyrZ/ZySFdtbltK9INRoy2HcEcaEsee8qONm4VMzkcAhLakOJnlrgqL2Ma02Vj8qE+DnrAYCvd5+87j9+Z+/oB25+GCOVfuuJ355++t3X9dee+272h/9WmtPeeor0DbLFly+hVBNEDAiuzE7/o1376C26gAW4kzb3NVSHWPFzrk5pm4Pc7GOldp27aI0DKTp6vwkY3wUob6wxtVDCCBLs599HyA/hXogZh+vskJ29PXct4oUY1fOtl8hW0ThC2tR7qxDILFuZh2Sl2Xsir7Rc3SC6WwFIuhlHyBVUU4zEo5zJ1he4/cVrprGgka+p27HpdTfxW2a363Cxt61H8EVxhRaj+6HiBC+vUc44HwtD3IAb6xOLInUAK9jXE/OIlY4PDfHUAQ3p8VbmE8bk92W882qQFzsxhwC2qXigVPdzjEKB8OgW5ySVpKNl333KNp1tOQ0ir2yALAJLrTfYVW69pXv72KJCFpREUabReSl8DFBBaT67f32Gy/9rvZVj/72dvq2L7Vv++ff0v7+769FUE61//rbz8QNXkkDTsDnANgpuDqxdSvgdjdbHk12qNybHSBpTX8hRk9vbbWTuMrV/eOA6sNsnQZ3xXTuTaUljrSDBB0nR6ttdZfNtVepjKAUos+9tnFWRc2s0fNzwInr7Lj89WxrDvuf2qfqp97ASc06EvsYqNA5s0ATU0CRjgil+HaXaTMhHSvTraBxPLReMua1RLiEMhaeiRM5iHKqFr9q2t2puoO2iSSz4x/yIr6LXpsi7EyhUGrHuXkLGEsCLpvl2YnON1t75cFL7umwWAqfDdp8XDgO6wx03JWHq1KWSjfUgZm1YDRzz6vM76Kso3a9Fe+UGzNlIE4RA7mlkephdKOF8VjbxXm10QoNuj5cgQm70GkMHcphSRHjAqCL4rg0sGtjSnEZDXOgpyjO+08v+Tcw+he0yy+et6+64sntN37/l9sqyvSe135Xu+DyZzGgd3DPQ9zxtnbm1PFUuPaHF7Y7d29oWycPtvXRZW1tsN1OblOXRl2y2yhlf1B2Ru6Dt6aDm1Hvg6xjhHZIGueLWIUHMVnuP2n6ixXWunas4B6WK2UnG+Qa4blG2cjsfgsV+iCC1dERtEwFSRl3QZ0a+wRbxZfV+xGf4KxYFX/PsJU1dOrE0b4V+BBBrnH2Xlm7apRY1QO5WzH+3bgq4KbqIgMk+P1/o0JzPxNZVs1v1p9VAlRmccYMG4JWUFYby+pfDVayr5WvEVcG1PHpyuVr4YW9ckVH7hxaQG7eh6cMVwvotpGRgioBDoBMD8uM5yMJOSMdTwfjb0/3SvdMVySmlebwK5WIjnVOgFB0yGKNXY1ufdUjWfbJxPzYz39fu/zyK9tob7NdedmT2sv+9IXt8kuX27uu/m1uyGZJ/aPc11XSd+K62HwN4D4BK26GcsAtjh+JYM1YU8jye2gDsWR/DK+1dEEb72CPhvdigckfIkSjAadxwV8NZ1gllGqIIliS3KMGv7GWc3eK4G3s4TYvauO1x8Wq2N5F/Vmar3VyNMPP1eflEerPmtr68dUAKucMKixCAd7MwZYCgrOBWJe+US29LklnrZJy4I26dFx8c+HoRbotkKWzlAvh0hv13vThTY6Vowg/E1hif38hXZlGcZWsrXDJMmF3NEYfE5lJIxi1xU7IcWhONZGdAO1j+erU1LJchce0jtZGk4jOmTsVacbKdROv7Hgec/Z8iIAwMbjESbfzTAB4V7RQo1gRn7cTD0ZTY9YWILfIQwfCRLhLuTbv7rVf+6PntNnJzfaEr31ou+OzW+2qd1/bHnHkTPsg6/9c3uXKTMnQ7Z07SCZXXRkhKuThebRt2E5xduAUYevtA7gpOtzZtdSXRRJzgDuRpMfNDaYI5BwpBn+J14Ykri0LGsxJBUkyS72QCJ3OD8Zy9VdIG218e0yObRb7PHDzfzk9lcwKjVr6UqA8lQ/2N7SNVkgM6uDwt5jZsWEuisEoEcz9Y2m49AHuUkgR6BPipLOU3sk8JN/Z6axThFyr6mcpJVcuuPO1WCxNaw6rDpVfjHUVqtrgurGmz30UspW2k7NCOoC94fcQFhd6lsF12ZaC1OEe3vUIOUPQkBULrdGyOGEMbg7VtjrA73emtQjXLtTt9M8BkFl2LV6sY+LjMr+uYFmU0wiWI0DR5NLdOozIQe+sm24Y/uPTHzjdXvA//+92nDWBP/It39quetO17ZY772iPPHR7+8C72HEGa0rJAy25F9acArbZjYzBo8lhHmdfBxLJ04uQla12gtg/mX62ArR0ed5zgy1TVNO2tkbEuOXRu3dyTAo5xgErMIgcXdm0gkJ6fIvEbnhEa604cnQZAd0cue33Q7tatLI2jlJOT2Mc9BI5AFgwz3tSKPEsPDnrMWPZpHFKiJJ8jrCAT44VAAAgAElEQVRFkkrDup9S6rou7taK0BiJjiT17L0oqBi15inVJjo1ZyPXyZd1tlIL+ZYPERVaVZi0SEUaKXeh4UkqmwiO0HdUg9MVP+yg4OZ8kGQl/1n2pDAa9ZhPzCZswVtVMKgfq0jOG9qkOkksWzb66jHAWW6vQJcZzmEC+XEgwml0Wla5Lq2Wg+t9MqgBlt3AikVyvYNxP+D1bkMwz1vfeGd72et+uj3p8Ze1x13y7e0lf/HS9oVbP99e87uPb9/xnc8pNt/BQkB2OYxz8yRlLYcfSkR0rB3jsMoehOku5TA743O5FpDuMvyJu9aYvL0DKEkN1ux8orR7CHbIRvQ4AHN+Arx1HimfPQQBi8USsDlVD262EiZx5NYBF1FlCtXS/wo6p/KVciyUN2oaS1Zk6aKy5H4nqMBpoWK2S7n8F6a9rk+mTwWPshuNF8931pkGCnGtc2r5jJAnFq7weCqaeIYLkWOPFK7kNd2SgZc3I1iZEb7pgs2ssOHP1Lz7Xxj5el5t/FGYxerPTBACUzuliHSK0HNNcfWpzK3n/GUrSucoDS02PWNlhzNyta+U+K0sjM+r0asWdcDS3xMRxcblk8rUV9sLhFZ7/OZZEOo1uW99vko7Xv+az7Tf+YufbE97ylPbQ498Wfvzv7y6febG97SPvfFp7ase+63c2JRN5UQnuLHTm+QvR+cymTvgLVwfucPTm8cpckgJJPtcYa1HsO2sTRxP7slCk33OWp4P7mS8OEKOf3uU2ox6l+bU1hmWy+Uo897dEJ8Hwa/LQAx9lWNxEecXUhnBIg4Z8hzlp1FT+TuLc7ZgID2tFFzclsFV+n6/u8tQLwxKl8opz+JElaXKWGU8FTYNgRwd46p88KePDZ5WJLoFH3Jk4rgis7Vahc97b/3QGWrzXLHWhZ9+ORuB1oNibXhQXBxfQLfihtyeWY1Ikb1RX9IvgumySrEnns/j3jpdpaK8VlkrUzAuvy/RiAa6eiSgXGGqVE4gAtfUltolLBF0/mc7HJCkiMqR5t6KfmUGahwXAlYBTrmHKASP+u9/8sH22rf/p/bzT396e8u1H2vv+8x72vapzfbJd/5oe9TDvoayoSvafO84KRryd4MdaqtOk6NkPyuImk0OSz544MJ27wnwl5vvetoE2GpArnBPmoEtj5bBhFldjeDAIeRswj3WiG1DPywxNvtSDfMzYD7Kulc9raJaN0eY5ASGK1SoukdGBADv4ZpC/ZyBVFyX/1duzvmrRRJdXtDvMD9lZbpAKPdmxBHOjoiPQIZiiGWu8Uq5OO+5sjwBFXNfRqe8Qym1qaEKtKraolxkXKn3eev7TnKt2wo6NRVl1YGSNcfeoPYALwJscerTKPsDCFSrADD7OyQckygqa+GfIw9Niu+UUVPsS7A0sVKc+ZrWyZHKYEia6udLuIvScNdjLZwg3rVtKZ7lNhUiR5g7lxpN7QQqrzVVJb5aukiYgrXf/vhP3ts+cssftB958ne2a9/z4faGN70FLDVvL/zFy9tzfuYHuf+jsnnHmX2Ovh0fz+KSfZfiE7Wd2vFsQtbo8XmWoXON4X2PQygpxyKahgfk5IoBWyS5Mng0dUtJUBHq32M3wz7YK8vkZRrT9jrl3vp2nUmPUu8VFmnccQ+1+dSLbYuT4vsMajya2DHoKky7PocclozuMI867P4ujmD8i16nA/NKgPucuqlw5tiAq/MQktIKlikjRaGgd8mE9w/5ys12fJZfZqqye/rCInrPv/kAFovBttbGQU/9T+d66kbm9mtbIFc8r+oGiWwmKfnMpkfJPWUTEKMYGOc59dwL8XXZd81uCZurbU1jZHGFLjNWxt7X7jZVR1TgPI4uLHBpbHYYjJB3mEFNTdSoRuk6y8qVWfeahX0qTawj1WpRpjm3l/7Xq9rx8evaV248or3iDe9uowdd1K7/yAfbu177/e0bv+FfYxbZQYbFrR7seerMfQj3eejGBQwim8+x+dppK6x5tfhhyq64bt+j4E82GQuS3L3ZJpQC4B8tOg0WOwCrHqhgcYecoNs5ediBKRKDEccYC58V2aySWmbl0Av/6KXtJ5/2Y6SczuUEX5euKWAFF8JfRYmiq12kV2c9p0CP/qa+XbdVhFfyuJkSFLgid29QUWXuo1DFYpXLK5XUa9Sl/gSsKzO5vK4wIozBkG63K3+FK1yiwbLuit+iKnFxkxThe0SIvFCqFtA+j7N1y8MsqbdWaLE0XhfmPg4OWkl5uVOXBtWGIRbwmdXyCGC/PHWVrhEpA5ncnx3GEiQVxLcq6oGaYDJdQ1g1Y8U6W/RnusdOmxpSeBfbUpY79HnFLkesI2cFFtZhzJ/2736u/cSTntje/uF3t8/ddWd79KO+Gqv1qnbj3/5oe+gl35KE8Xj3OJaIxA17Y00pyGszCvMoDNxBkk9tb1AXdYrmSN7x7BEquDNoW9sncINsjwTT7laRkgIndjaJENeBFCtZXb2cfajcjE6MVXtUZGGUFs2kOv1ZYcOSXRZyPO3Z39n+8rff2AZsueRax4lRNOUE2UVRPxP3Vgcwp8RclXI6DcIMrDoHpJjUErial8VaxYzKwtosLnbeFr6tlh7EQsa6Mva6wUk8DJe5xI5r3QxPe2OVb+9tHziNezRF4xbOnY8Mui8XVVZGC1I+S7Fwl+SK4gxLFRAEwAoCoz4Gyf0+fWIGKas/arFkdgGM4pRkm2SV2fTIXZnwepSJagQvbq4TLJXImjEumVCN6Xq/RCky6PrUDkdkoELGeqOy0QtmPj2phyu+SdTe8IlrOErwWPvwHTe0v3nbR9rd99zaVhmZ69/9k+2yI1/XZrunwZsXQKnc3XZOgXXYlWZK8vg0dfJn9jiT0HQJfckxLgoLa+m3qWjYwxf2cXtuMjLWBTIxY9q/zOYaQ/7te6Qxf09ZCOnpWW5bOYaX0nAPPecxRYuMOQWHl5x7Tnvc9z25feVXPLb9/DN+sZ1/+AgVnyhi6ldqfhYl2PEcGYtSJL1PshoKjsBfpe24rW51XwTDBHsVXpbX8gZRxFS6KF+dVYrQC1MqZ5v9LCJxfs89JLSmWjcE+224wolL63WcvJnFCsE3BarDbIffqChRwVI3sr2PT3Fg9eAd810TWNajGmqv6ui3quERTloB6gJOOsR4yk3pShcRaOWOtUr+gp4YAGSPAI9/67ICsWQuTa9Edo7vdSfnPF/Fqii0wKZVku6W7BbhXrfX1sYr7dpX/E67d2+tffrEJ9t73/nhdvLo7e3Lr1xv7/mrn2kb619D3tmyGBSufwi3xwrowYPadHm53X3XFzgF9XyetcaJqB4lomVw52NaO1yl4I8sIXuVDjiUfHPzFJuLHIwiGlnOqHJYoopCfOWueBl2Ignr8RNZZ1NPCwvpA3npwwjihz72d+2Fr726XbZ8uH3307+7feWlXwfmMpEqVi3KoJbY0fsFxGUOJ/hcd8HOUct8nKXzWc0uJu6sTebXlFsJyf1eRncnP1bCmWhvsZeGDl23HfDVRal6o9TYmVRndt9GBamDl8hUFl1/miiQSfBGC7pB+0Hjsto1bkbPGYIlg1bhbYWrSlMMRidcZTUcMDGZFs7kk2plrZINEgdobJSEKsfNvXCJdtdV2EsGAVnkIV+h+pUE1XuRpDLxZ5GDFlWcUz7fExOSNDeiIpz/+Ps+2A6zB+Sr/+5P2t9/+uZ2z2ePtosvvLA94Yp5u+pVzyN1c3siu+nkYvZB3eDoZ8H0g9uYFdFjXN0WAH7CAduniBTnk5W2vrHSThJRLq+dg1XledNNermOsOEC2ZHZ08p24a7WqJKYsZHubLc2zh3n7ET6six/XuMu9RndZDwOri+1Q/Bh3/Lj/7o97NJvaPdufba9+Ode3pbWoS66hHRgUaLmEgDv55bjU3BedjMWWwkZIq0IGdIcUrk7+sTMRpLJgQ1dsNUZBeOtrID2u1jolIfzwBxQkNnuvFCIdf8G0uDme9d+4D7up7iUb94RF0l6pbKMu4o0UyLjNtDyV85jl3ox0KdDoRpiksstd4imEy57XxHjgr5IXlBjK3jtqlVr621vXl+39j1ALebYa8u+10u3O4st1o12INQl+V2lTASvSj0sq3SDMc4udP0i97v5uuva6viu9ua/fVu76MiV7ff+9A9Rpu22f3q7/dAPPbL98a/+MICc9YOTL2tblBnPV86n5Fg6YYNBG7UTe1gyarJcJT0lKpyO1ynDsU6J7YjIJozJO/axNFPGbzLZIV8oEVr5zOk2QcD6+dAYEKSMc9zlHsK1UvlPo+ClAH9cJG8dch8I2vbJT7y5vfA1f8d+p1Ag7Yb23Ge9kJ1yLgYbe0Sf2LaiQSs5nb9UczJPXcq5tjFwUKK8eiSFzXONOrzKxJrqcreY7MHqGHNfsy07WFrn2IBL92qNXJUnG2zowqusXM9Wrpc5uwaLtYINt8hsV9yjaxHLZPlWCVOMWTgSVzKbj3OPBTbypzOSoTYjVYaxWkqXvYtJ4W/dZdWu97MSRyzXka8RJHFZzFt97X/X9R5wepZVHvaZ3ie9k0aTjooQELGAgG3tIgrqqqxgQ11FBXVdRCxY1hV7Awsq9oogiBURASlBakIS0pNJZibT+3dd535ecL/f9w3GSWbe93mf577Pfcr//M85eXL4P66XhP3shVUELHOW+bMyGrjIoJ9aEQQzv+UPC77lgSjOrD+zopoOfmi+gS13xa233kkTtF1x7V3XYwJ7Y6KPE924jwHgR8ebzjqLRd+Cxl4MSeHw2Nt3H2dsEcEC4CgwwMhQM5qG5iEj0I5HKTF1lozDQSdpfmsPL82KBxzVZcNgOdmULmYJmP22WqnosHuR5q9hYhifCSEy8c89tsCKsKqnrSVjcRD4mVjQNT8m9v0pnn/hJ6keojSNNNKu0cH49H/+dxy4+ij8utLGyH74uhoqCjw93i2fVHHSfagyGKmVCpia2UUzLuyzAZjRq/vvdriSOdaHPW+SBSukgJZLnebSJiSlpaisS1qp8rMkhP7kpp6ZLrlYSKUOZmtSitUx5Maq9svuS3bX8835d27X0yaPymgozVnqzNzImo9Ubu+xsLioHDWg/o8RW6HhFDNaVfEW0UiN5qwdHyKbV6RWzCeqFsb3GRLos1UOezHEheaTPlf5vWhxDsFUtz2yPm668/eMwR2JW9feYXYvbv/TAzE5SHTaTkO2+2E1tB9NXSCIeiO8Gsh7Y7QvGoEWU9+8NAV+EO01bkM2CE+DzL+Zom+3HfZaqATqJVHd3ihiPpDlXfsGBiCHtpYMBQ1ypx1Bon/lCSFQmMSeNWNem20oZ4MHzTdrnYxq1sl2Uq34a92g+e++/MNx50M0fBvdzfo3x+YdG+OFz/i3+K83Xojpbcz2l4X3VHK8Rmi6ETlFLVkU1eImcaZGdyoHWiK33rLjVP4ljEysUYC6JIFqJrcogmy8kq5Jwc/qoJ6Xvl7cxq//sie7NBqxDSJUjOMrLam1hGnBUIdWz6RfJX2ltGnOGcs2WjPU5Y/cdpudCQckp718dp4Ke2amSfMDEcIE3fhH6QhYToBMiSSq5fuKAPv/2YiNTfDk15KiNb6Q79Z5N6rySOmgp5flwhJxZf4tTYRtA3gOmAf7Hrk9dvf3x/a9u+O3f70v/n73tSxqS4z3bYjFB8yPC19zcrz6OcdHFwU/kw0LIK3xO5iiY8PACu0r2RKmQQOCDg3Pok330ugfggSIYDlcU9rQkLMSZS4QsCgUO/t6Yz68+QSeKf2yCGMS4Wqi5cwEwtKKgz8J6c8uL/ZBnWminVL2rQdMxX9sw5zW0yu+BX9t75Y/xcn//VEG0Mk4lc/FdAyGGDTxfF/88ufj6GXHMxmNoaI2j9PUjRDJ0t5G7ZluhtaA/wxgim6psReqA14poRwGgDRqmXJNdY9d2XR18iK5jwmap0UreJqleUmF0jBd85ftuYuT2B2bPxQKRNqjlNFS3aFEFrjRSKwgGthcI0FNoAKhkkizluPCE5zzlHrrY4lzmbQuwmNPT28qf5bChP/DZaUbF1E03OYzq5uvNWuT7+MIutRxyVbg83TGUxNyOqupV+JtpV+9VysBgF1yZpHjqx/aFQyZiHvvvzt+/Leb45Y//joGdlAfyLW6Zy2OT1zyxDj71BcAcCr5Q7Fz6yMxZ9GJcNkxUW4QtzgMBWa0bz+emwhweiCmKMCbIg0zDSA6gk/W6uBETw/o/gB9I2GeR7emjWb/45MDuQYtVuzQX75hnM1HiFtzEm0J6bIcXl/LwaC0bm5t11FmPNbo3fGsN36QSBS/h8BCTQIwU+Yn7tkdK094fHzx/ZfHIrrcCF+IEc4I9uUhLdrchbKx3aNfBdwrB7p6SXHVy8/t6mRTlnyZAlVC7Sp4Klc2PVa8bP9Sou+6a/64Z0YMRrHMuv+srVY67XfpCzUphZbi9TwJY4lXlRBW+L/R8iOpRmowNIP9BTKPJbiqUmZTE6fK5LOke++n3HyiUNrk7IyiU1jDR2ocLYXH91nc6f15b1yrch4LXaUSHjsdJxdefAvNIVtCc8lr7P172NypuPuBnvjHvXfHz++4OVaiQdbeeVvcvx1As2FbjFHQ/Jr/OCU+9ebTIuYOxuz2Y2PHno3R2L4MuGEZsIFxAGOFcdInEIjRwVaAUuoDOWwjtOhTw09gUhuJNqV6T9tlmahwElC0m75IHB+eAW2ExqsnEJgitzgDJ8vwv5GMRSO5RKu/pxzsDpbXTAK7jvl58q66mjqji6KOV3zp4lh3567Yu2NrPlu2M0K7TDFNtX5olCKVvbH8KUfHR971uThi8YFQn/m9jV5qEaPRvnojndmawAlzlAObMpZCJGbFZyMCNUKC26ZIljxwcWEM+2rvFRj3TGV79h/9aXv2D9PHbGFTc8Ru2rEigyVTXnyU0jjEBhr6CGX4oWZKDWORaOnjVEszFDNWtE3xj9JlA1HPQUP83CguMScfKDVP5eDmQ1dHRKH014a4tRqmqjysQHpiKqVdXPEEMmAuOI3+gfRqPnfVHFoNIdEbd+yNz1xxRWzctSP6Bh6OXZsZGg7lOMaobEYwLr30/DjnRW3ROutp2eC2DrR8kOYgk3WwPqkBHBntxjQOYwqpiCYYGRkdJj0EHEE35SnNmd14CM2mDMtw7KcorZ90ugUmb2JSsh/PjTB60NRGaqlGmKr6ntK9rT2UmdrI78xCmnpqwjy2tqKxWM8/XPfjuOB7P4lxxo5NzengHtEnyd6j0yL3MGYTVMeaje6K+QcdGWe9+e1xxjGnMWyNz0KiBGfH7cDsGup+VIqq1nO+EAD9oQrBNlXFBcq8pIKVxqnGZLFRW1nrzMPy+xQyFdOP/rhjZoKoUFNh7V0NLlAcckRIFd0lb52FG+PGioZRZauUfChhh5JGSExKH0fbqwPqNusPJpKgaS0mMCORFIFycsoNFy2ov5QaV83o+4wIjZpss1RRmOXB1zsUKH/va0sS9VGFbyCRyQKMCNfbf1VjDG6biS9e/Yu4bv3fYhDMCXc3Hrnj7qjbuykFtJ02kX/59UWxbNFR0dS9NUYml3NwFsUQkMLwAENROpakqRsZJBpEy48jVDmtYgbNgvT2jUg/1innj30bhH6dxzzMZEQ2dsrZhrZuIqrroBWNn6nz3kIvLkv9W4wWeW5DkVZMZ+lFiuDRu0tQuh087b61f4mXXPQ+GulSu9gNjOGGkW8s5ovPJTLF0WPoOgdJOIGgY5ohVE9/9qvjja8+J5YuXJXXH2HqmeViNRvo0awxSWsCl2ZPHDAtTMEuExXw/yr6jjKTEKL/JdzjPziQP7hx88x4piW8R7UJDiRq2BqhBLwVjVQoxXmuZbMtkkwB0dHixOSovPTu/J5SoReWWi4BiQwEqtnGYprSThUgBTEd+/J5dqWrpWFEzzPayMhP4SzN4RKwc02EMMDZ7ESoxs00k39JofdBS6n6/A46yJAMvvFPG+O7a38et929DsEYjXld3dFz259p67iFi43Gaa86OT719tdBYemOuW1DLMEcrj8fM9ieBRL6WLBkMH/yppjcQWqnEdNVVz8X6IHO93zuONO8WltA1rmXnsFtsWD2UoY4AYy62IRpWcbmg0qDQZs2aju8//RXBW8kBLEWOC4monW7mlqJKl0vKqd6gUhOf+W/0U+eQzbbFJOAspNEirswhtlrBCObbENQKKqlET39TIQg0LAokM4VK+LUl58VZ598BumhhWVUMIW0Y7oQ2ROjKI5axqI2+SKNZGqjss/Z+DY9moqx6w7atpN7TCLgVTdszuC0FrBnqJoRmqZPh7tcoLpKajHDaB1A221nday/Tu5RNaXC91Xi7bfsmKAkq/ZTsg2GvdEylzBTqUIPmq/kwhczWHKFasHSHql2ZFTKMsPM4GdaQSWtLDuAyH/ZYJeTlnlEnOIDZw3G7fcMxDev/Wn8Zv0mbgPiHc74BCS9mV4ap227Fw3TG8e95LT49DtfHYvmdqF0hjFVtHocpedw3VzuAcoxkdwQNONhu2XoqIiwiF7zO/25sVEqVBhF52vlYo1Mw98CY2qBa1UH1NCCE27HxGQf6MrmfMLKP2RFHE3cSJFu5kL53QQC0kifroy0WSuDgmmCrFNe9W+xZ9NWqDfdhPjeB8qAaRoyqQVkm2VIdHfEEOkjatlyv+zNhQYh0LCtJYoDn27pEY+Pl73gnDj5KU+NhYCtA2onlIRrmENLU3D0rQtSX/asaKf8UnHVmrdl1RWV1xy0Drhrdd+xua0XSpe3OMdTMCPrMxdYc+dKj3TRD5kOzsQZ5YLZCC1NqsMQa064wlbMkLdmYUUDmIsDjayM0RyWjJXpC5xUSYB8Fwi1Qtqh2anUvV7OtNEXKL5TQntJ1lK16bDJesguBZUarwxhaq5C5jPKXdmyN775m7/Fz25/MB7ccTvvIxdnI1hSMyGV5c4/0fZxV8w7ZL/42bc/HKsX4kdNWO/HZDD46wPkA6cniQIZNDBNpc4+nOQJfmYDEpPmjo+coAGIQwjEdkryFq1DFJqNZ3PCRcmVepjqEdb2jlawMCt1uAzBzzSawwljSofsDn3b5s6SL21yqI/HkjVsY8TF2z96Qfzumt/g2MNKbUNr4WdNgtA3Yt472vH3EO4pWjTXN2OOrV4lfUR/t5jqdQcHoT6R17TjDZ8/MULEwl4fduJT492vvyT23/+g1MyJDhjdVQwGD3pijjWXxl7ymfBXc5Q25vPYy/7+Xaw7k9SuumELMBNoOMUCCXKmmSnmxCsVRqFN/YXyEYRMRBqycmGllN3TlpdQwg8uzl7BO6qyLEVMx9sUjlUqChEC6gjebt0CrtdiRbRiV7tO6iyF1sX1L5pbTrUjQsTCCoci0xCFQeGX0a1CrfNXFmIBVa+33XJ3XPaTX9E1byI2bkBjKczMOJkZ6YnmuUti/J/0tQJdb6H52pVfujSOWEoapWk+QCeAZtuC2Ld3J440vatau8lOcKjwTyaJAg3nnbHTgL81iiYah5uloAxPjkZH62zkn/fzTM0KH6aowbXi1jqIGmXt2hQkS9V5mjF6zXfOQkA5KE22IBgewOcjhYTmSP8H/2tC7cfn/ermv8b73/yaaJjLZyBQORyL55U54YFOc2g0j0DWdQHIkjJqQ1j7+/sSxilAtvRx90MXw8+jOe9gX8w57ui48D8ujROOOFYzFINALvXjYAGKQ5IIii9tTYQZlwbwiPEBXkP5W0t7W1Zh79nJ53wbwXIzsiDFrZFIlg64O5v2JYVmwqjDNodSInLHXSSLSRE8VtO9lD5S/KOqiMIAwNdlVFnFFXzP3J4bxInq0vGt9YkUIU+TWTn9ymZiXgpq4VYbzRQnU6zYn/tZlWouT5DquXhltNzumI5PffPX8fW/34j54oFH0Qr7QNTnLKCVo2XwlGltvINmtXSTmRiIs9/ynLjgFeegkaEWA0XWtwIyQVwcojn7KHBAO+vQBzZlL9EmymL0ioYMIogUB03XWGCCMz3FsW9lY42YpwAsbV7byrWsStJ85TOobSszIwwhHNHWQG1hG4KBFtLHFP1p0JF3LfO/ltiyZW88+wWPR/FCfwDGqEfjOaRAfH2CFgASLufMnoNppte8GpFmI33bMfu6ObQez9ZTJadUPBwmbsgTy5geKykvPxYtjLe88b/iBUc+P9rmmq6y72kJ6EalcYzsiw0P3BedNKlbPJtaSfzKHXt3xeY9/XH3uoei7lvXP6JYpfrO0J032lh+hM1qNYOt9rEfCg6iGXP9IaNZQ/tWMvJTLFjKgg1xs7GHWqeUuResRBPgNXQK5RqJUFemNjEzT7njK9V2vl/BLUTBnIyVKHFB1hVw2QAZKvN5CnO2o7QTjVFj0n14lsxWJEwb9Ts2xzlf+2Fsse86JizQPkYqdXMg7fFZi+qXx87d62NmF1qLEP0XP/5izF16YLSO8DmYj4bO5XCvWAc7j5nyoFZwHDKfjTzsjIP9gh0KHZnFbsPetLPZFvWOS3FwNB/Um04qN4YwG/M9gGBgtlQ02tFElmiKtpQg+x3djLVjbbqBF4Y4IBbdm09sgarTAoqvv6bWmIRpseasp8b4zp5oIzJ0/5pR/ccdtiyeefzxUQ9teuWKVZi5XhqeMDCI62/f9TBJ62bmKu6Jn629N9Zv3x37du4mKa75xpySs8wCZcmHCH4dcMq0o/PYh+Ne9JJ47ys+QFfpluhCM9+1bn2sXAj6jzDefs89MWvewrjv4Qc5VE2xafumrAOo++Y1m3LYeE7lTEIaqTIkegSH0O4Npm1s1TPBSWvkQ7NNEzkxfac0P5kqSsSI3JTRSeWYpf2y50NFp3jUX5PazOsNVzmRDSQCjUYstzfkzDbeSekoYWw6x3w3MMiHzvSQYKomyBK90re0hhbrA+SgATRiG3d4/113xrn/8xEuYJNMHNd+FpDuyD5z9+rV0VktZdUAACAASURBVE9KJHTg9zCbhOHj3/nCG+KgFc8C9+F1CFdzKwwCTrwadgKnfQQmaAvVzD74kFyrdrorswGjwgY2k0MAxPr2jaA5eHx9sW6Q1V4EbRamsN1EflaO6pu4gKn+s7hEJzvTOLoFmJg21iBzhWQB7G7TyEF2TmPg/135gy/Eug33xN0bNsf8rsZ48dOPiyP2P5RCDSAI21QyDaNRjcr6tIKNZcRIq6VpzHITeJpKfpT1FzMboWJ7Z39P/On2tbGdcWXbN2+KPT1b4sSDj4nXnfn2WLH6GD5jJnbvANgFJrnrnw/HnsE98RABxDAUpHbWZ7R/X+wFQ+uyQX6Lkyl+vRlWq/6PJqdU1zodwg8tcQCRjKaI/yxDsmI6+zBZvpVOXkVT5mQ1szCZmFTFpoYp5rUUMahwCoUm2aQCifpbFT3Lf2dTexuF6JkQ/o7XijqEQoy78zdFiPSDDQNsWp+0EQ+GQs7LWvj3EH5KJ81lL/7ilXHjTT9AaOhH1TYYH3ztm+Lj3/4OgQTP1zYr+nrRVhtx4qcwk9BhLv/CO+PxhxzHwVrGdbfzLFKM6TXKGoxS2NqM9hjqo17QPvhqUJUPLkILjr7jRTQpY5gWyZL6m+YF68kPzrTOwuy7Fmhs7tU1TXQ7vQ1dAHt5uS48Gz5cI853BwfMfGI70WQ91x9HK+qncfnY8NB90bvzViJPkudEvt209Y5Z9h4jYEDzjKJlRwWwmzCvzZgq1qwDFH8CTWmbJRrPRhf/huHDTYHxcYimpvGxCAhWrngiwQX9JRD8rb29sCumYYLUxy133hN3bVkLwEprALT2MOb/UCCL+3c+EntEqIhIJwhgZkZYy69ftzlVj2YlhygKcqFyk53psnH6sfZ8QyASdEzHJ9M/s4zmatCClishCjWGPHSLSAsGlh5QYiMKXcmBZZidIYZmzOjCBHbOXvDV6du5MLnwtp3Ua8pokA2TD1S89TTN2bNLTZVIPmZBDjZadc7e3njxf74t1m+7v+TuSAjjZEUs2T9IDEJ2moslI/K7AyxL3wcmwif+97w47qAn82l0k6nbjaDMQsiIuCi3HxraF51gXwPj5AqZSjGf9w8SxjeTC5TiMk1VTlunyPlkbMMczEbTjFPl3N1derfL1+pq66JHA85u9vk0shJfFnkXvzPniEmFKz9O2N8Oem881QE7wnPaD19sVicwAk+955Ft0bPhzySZPUxOUzRYJvJGyHqHJA8iPOxhM9dZt2UdbQMWxgLaYPq7WUw58xS2klbqH14f3bMXxoqDn8C9LYmBrQOxCXdh20B/3HHvvdFhxoCosgkzvm77llgCjDGJoO7evZ3nmhVbd+yOh3E35i+ZTzYC4JjxxTxg1H3tuk0mWNgvsaIyWbRk22rNZ1mcROCVAUNiS+jBrPigVqWzcu7TgbZzr5vr68V4+J2CVIWXeQ0LXf2ddIuMiBRkW22j7SzK1H+qfWWBR1FRaaYttNBnzwBTzKv6IzLsdHd3Kbn3/H421/rlL2+I93/yg+XNRox7cUr1bxavjq7VmA0da5gOuAYxdcvvUtjee/HZ8bTDn5XFArMYyqQADAmVtM2GxCegCUOUYz4JaNoGZLAPH8rOPG0t3ZzgfdnSyWisfy9/p5p5Es3RPrud1ST0h13RajOSbFCFBQCXajDJanxFINSCc+/wqywRs2SM+9MPa8nZN5IG2RsOs0NIx+GP3bP2V/hvuPxEqC3cq9SnYRPSycLVHWC5aAjX3UJ/VcxiJq3JnICd5ozrI554WDzpmFPjtr9s5PXD+Eu9cfPtN8YgGNeGvX1x1FIYsyzbOKjByJ6hWLh6UawjlWRWYIzgoo7RMHv698TAADAHB+rBXTtjOXja4rkMUvjmtdtmnE/cmvxynWTDkDKDbsKWj+Io+jU5pLqg6ebtNHfZ5KKWRmGTm0xaq2zSbBkhei1hDqH+opkaNEFKipCNJlgvPXmx8rpKF5v0+Syi1ex6PfEUvidbsYIzsuFFlc9RazVzTxNqQ006oXnT7vF431e+Fr+/7lsI1DbpA0A4+FKOP11ERLjqYNR5R3Quboy+W2+POqIcn+Xcdz0/nvOU1+E49yBEdO5TX4PaB+X0NL1nc6EV22kQrM9ayGkoM8OTfTjthP7j3B8PMESvLD8HVKG0Lce0tQBvjAI5tNFAV+3nYZrMYMayNwQTgUvckMdqltrL8xrpCfY6f9m1muJ5HTIgvaZv72Tcffcvox2/izCXwAl6DzDDzkHYEzj/+3WjxWycS1K8az45TrTsyN6tMZf00LNf/kpym+RAewbjs1f+KDbvJn0Fp38LlUgLqAcYg2yoizFvVlfsIsqb2zEr9iCl84g+F6KlxwhctpAE97M2ECEvJCXV1wuViMBgyf6LaUgH2v/V67fNNFDJWxuHMSnJTPTX7nlIvRFiph+zCEK/ofhPrQk3ONa1dNN1w5uInDKjkguREsbClpBcvrnaS1S5xHmi+oJwZu8LNubPs4elLAaFK5uwlZq2QvLXfJSgwdeXedX4XVYb+/4WtKgICL72TTfeGe+4+HxApZ54wrOeEnf8+KfpR9FNLRqPPpHrAjqCTKep7UcQ+tBm/OjzX7wkDl56HBqLXBzoeisCM8IUC/szOdLWgoLWFmsF7SrI5mDWshxKQBbUWRxqxn+wLs34Q8McvjZRa4SuBaHKkcXiTNJkVL25VuXgpLPt78QLeZBay7os1kBz2WknuVIcdhkLt/3jNtJK6+GO0XYS0zeIJt0HpjSEul21sBOT6oxFBBYY5YAD0U7HrkGDNUNzXh+3rGV4wv3rYgfC0c+hGmZRO2yZyf3v7BsgvqFYhOzDyrmr4s5H7qVodkHsZi2PWnRALFy2Km6+46b4x5Yt8cRDD4kHHmZoAjRt01EvO2VN3HbX/Tjvv9mK21R8HbWMGXqb7tuNwCpa0VkdxqzhF6zLbHHZ5Cy90DdJM+X3CkBL26VKZ4FJbeRYWATPSa4ueMIbRpyCrpiwonxEmxEQZdQ74e+prXJOTWFSSA/JWYb6demG1aqBS5dgYQphJ2ks115/W7z/v16dcADhEPoc4ZkAv6JHQhx4KI57Vz5THZHODEi47QMbJ7fGJZ/4r3jigU8HnZ6gFwNQCoyGHVCX586l8QfadgI/Qn/TgVRTwiYIyxjvb0YjJhFRh55nmoR71WTzNX7XgpnQEkyy8U77sAq7kUqcOjlfRMQpOBkRGmGVRH0JgohswZ0ytqpSbFJRxm31wlps2rA3vnXNh+IZh5+IJqyLPnzjKXKV46zL+L7NCHJDnPas0+OoQ06MTVuH4sENG+Nn1/4p9vbujO28bor2Afbr8v71C/HHmeG4LNbhY3WY93Pvjb7JVfbsgFZEhOrI1pZZjGtha7eRt8ye8lozAN3HH7kyjjngkLjiO1dH3ZW/2cxayNPWzJWmsVlKrwbI3lCaMHdeYcr5T0lEy+SzkVnlQxWKTNEe2f1N6kQ68pY2ifkY9Zlq0cEq15QGolnUga3lHItDrrKzyZtDgNRqJX/lPU2lxtQfFGMzAaxAcRU1opLIqyZ7h+KdF38s7rrtKjCZuSDP4CrUCM4Q9dCnMeoWrMZcgv+0ADCKODP9ixAsnnLcmnjdv78g5sO/auF3jWjbEdmhQAkTHALvqQtnfxyhMW3hwouGT6H5mtvp+mcynkocm+k3Ywcn7CKD8Nn6sqOReYgAwklQlPdg4tjDYEtu/JIGzKUZjHbC+ayn4QC3dbpejkNWU4ljuYslWa+Az1Cq//Lznx1nv/CFJM2h0NRBrcGNmRzpR4jr4tWvPC/u+Oem+N3vb4wRTPFGnPjli1fGrevWJq7EiExciMbYjnltc9wd6zgEnDLBgVizYmlsBCczZbSB0XhL58+NfgR69txZsXs7UaD415690bpgHi7FAAFAWzzrScfEIxt3x7qtm/CxfrMNdF9bU2CATI/UstvZDRmTpNYxwSz+pEbRpGUqQuGRNoJzy+INVwTAFIuqAjcZphy5Fs2WYpnmsbjnUv2zkjG5VvoY/D3ZDKmO+D8nyJd8Y2lOIbygPLsIxSepERP9faufwxlpghP+RNpqs9qAojiZoMwz9F6wMW0d/sLMwgNJDHcAazHEGZyqtXU0Ru7fHHHAfnHlZe8FTV6IAnOAEv7GBCkTPn+Isq15XQuiA79lgP/G4Lv7WQMwF5ALlo/XcajGoK00YObGRc499SSNrWiuwwTXwc3KIZcCxmxoO5Grh9C2kc02ecNJbpJ8JqWINIypH9kPOYfKhzUyllRocavcLw7Zhz/+Ieg6G+KkJ64BAuqAnNgci5Yexsu74o6774571t2B1psTG/t2U+MIdDBnWTxEtLwAf2kSTWPUd8umTXHQMmjYUGyWEMGOEfHeB4Rw9MEHxcMbt2ABJmMugDJKLsmcm6HsNAG7dBmBEmnPIPDtsztiLtr7kYe3xKIjDycJfc0jWCFBOxenlEinSve7WXXBUZBjE6zCBFkoJiqfmqWYUGv4FRF7uRe0oDAW0slSM6UgqutUjLWK6BItZmTINbJ0PuWpENCMYDLg9Oc1ujTazhkuJr+9pnhacvITLOOe2MhRKC2DAHzPf/ETQHqBDPg3Lfvwpwb4jh7vXsVMQdgKHWiYNn7fQ/oBgDTH3s1rj8svfUssnHcMrFGEkghqDN64qSRBYzsXWjjRSlg1iR/ViBaQzj3GQCb7lFrEOzSyE4Gjqgb8KQs++Zm91nPmsgldrIBIuibLflpGaILLLVJtpIbjV6h4NX0dbaSIEL7sre+hRCPWs5lcORqADSbJw91975b4wGdfG0970jPjwCVz4zknvRIu/z2xdc+62LRzJ6BqN62WhmLTwN4En1up5h7ivUb0QzA6mhDGPg6Ys7GHiCgVEDsEjeLIz+Au7NixPo5cfXDsxu9qRKuNyLAAle/duI2AB35ZJxqVMTErOxtiNxpuEE3YtJv6gO/dsI2I350pJK2EAwxTpbhwKsqQn/K7dLoVEoUoQxidVhS3kT7/zsxTpZlSvKrSohxNpnxUmqj0gCjvn7KvQ5IEDcF9QdFqCmX20ZInr0Jlce0ml1Fo7V7ErBK2KM6/o27qevfGxz74lfjdnV9DS+lEcwRIbQTAYf7pXBwxb78SHe7bSciMqeznO4j0mlccEu8/671oHSI/DkYnmzoKp30CpHsOaslWAJNwnIZx2NswlQapTQ7n4cQaCDY4mFzf0HydH41PNqOpFKtL7pmPV7Ari0/s4dqIk9KJ9mhC/VlgMQNImsdSShGva4dRoTVRuErrp5LaSfov5rMfWODM950Tz17zpHjxyWfGdTf+Ix7Y/hA+ZFs8sn0gRvEdRyj4OGDRsti+YwfwyFDMoRJ7H/yxZiCKoQFATRz/WWhwI+AOfNANu7bEgUsXAkdR4sYs7E6iQzHE5cuWxSaixI0PrCflQ9ACvmU7hGXHrIlGWpJvWv9A7LdsSWy+j2FW379xO1sqYFkazoqk275Q8bGjn0/Hc2fkIyqf1TUJaGomS9qlTA40wCmVtPl3NZRDlHDYFRStXwpMMhP054onlSZOYS0Kq3KAS+1bksg1HhkRln4z2bnPReY3TfpvClk2cRPKmGJUSW8cfsRTOG3oUbkiOpYgwSTYUkNG9xJMJCg1WxtbyR/6M5xTtdP/XAltZM5TsrnHEPC2bQGaACnHSI8snINvxWuGoTfX4cx5EEyDNeLXtDIXZ1cvZlZf1dpANtNDNUyjtgxQeNYmNM3wxD7wpjZcDlJFJKo9lLZ3bMfk6XO24mz7vQmBlk+WuB9aTVbqZKazSpdFZ3QPYuKdRd0y0Z7ExXo00tV/+z2plsHEs9q72mI9g6aW4vuMsOmt5DB37tiFuUPIFi6hPSbsiVmzEEwS6g1DzBBaGg9s3BFPWrkAmhBoP6NfjDAPB1jt2zcY27iGn7lx/Ub80lIsBp2j9O6gv8QMAUEAIKevsuCgqPvpH/dSS2qhqnCSpq04yel418yTvCeNYDYGSXEocELJFBfwxTfgfGr+jfASYlUj1USoAlKL8BQ/Kf8/qRt+XjGZOaU9eUtWMFfOmGLm51a+Vi605oCIRfgizakazc4uQAcnv4D+7Jgmk8B1JIhncLY1g+m9zTqYDZlF+qYvqc1TFB/Uz18c57/5bXHSmmO5Ls49AtRBdAbqlOvn9JTODigzkzQJwenzswa5RarfEXQmh+FkD5LuGcWJz4IPm0xKE7Aph4PiEPgpQn6ro017SVo2JdaEgLaQk5Un34AfpjZrJQLPjni6EPa8cGoZMINgpxEjajFxscGxHpix+IQ/+Vl2tNm+a1fcdP9doOrdIOPQXfaR2uFxBTO97ia4/u0ycDGfrazrMCmdZgDe3r39sWTeHJ4NrhemfvHiBfHIjp5Yji+2/5w5sW1wd/QhVJOYzocfosHvvqFoXbaSFgEk3ncz+gXF0cT8mMl+zQrCbo5uF3DDz27qZZ1mePxSIpVj2nLyewEtFRpLwQvy9JgflAKhBkuCiprFvJjhqU1oi6M9Q8LU0FytloYyqTOFklN0kpFN8c+yASsvtCeALygDiGpaTTNYsLEi9F5fbamwF/jC30yMbY7PXHJ1XPu3b2R0m8IuYxJfIuaR5d8NBXnJak4ci4BfBM0yc5NtyxfEFz7+1Rx3Z9sfi0+hNUR3V/E3ptmMRkq96mSFcuJbW9BeMkdIX0wTmTVgUkz/TFA8IbHUNbDnvN34xoQYLOQ0Pmedzd01Egn6uraWolG75E0pM/hY7fYxRVCaeE2rWQQ0m4faAQCu9lj2Ox+Jxd3z4hUXXUrqZSspQkvqASlz3s8MNZPD+GetsQN8qpODt3LWotiybVcK+xipmgkOXxtmrQ7NNG9BKwwZCnERtNlzFicD48+Uxj378OMJEnbH/gfgwK/fGndQdLKTZ9+zAbAZ90Iach3+mC7BvnUwG5ieNkoim6QjVgEo5dqb+vHZ0QA6MlmBW6BKK3ESOa/oKkXgVIF+VXbL7cy9t7qtTIEvKk8NU4Qrs8XZQaUWA1ZcpPxZ5aybRM5wXg2lJ1YYo1PSOKruKMkh8tqa4UQ1y6n2fvV92ohuDlyyg0w8pVvt3KeYGUlSq2/qbCV00lMj/vA7FoPeByR1iZf5GJxMel7NPmJ1vOct9MSa/7g8LOPUDTZOzmUuND0ZuK7N4yQ7ipBPoLLaKcUaxyRNo1EG6CzTScJ4Aj+rf2KQDTbpDA0FpmYjpniK8H2MaLAFmMPgRwbnFE3aLNtqayRSTKxlIubhVOvPtgJJiEN18btJK6AQoo6ENhR2tBfPvI/24S979/tiV8+2aOvqilULlkQveU5fY++tvfx9Cbjbrn0DsWj2PGhbM7FzV09MgcJPAmK3gHktXbQo5i7ujCcfeWh89opr4vGPI8VFT/t5XfNiNtoZ7B2UfVHM4nBvZ/Twn9beExtA6Gd64XodiJ+KwPc+CKygz7vHQ8ruoNlmyGrE5rVRd/3fYOXnVzFOqVs4mZPyibLcqvhU3rDf/VJbZXGOjEgEJKcl8GYFK/2oFJgClhbHX61WkcrSCUUouLwDjuyClyossYPaiA/Nqj6dt6WpLD0DFKysPazlCM2p2dK7ZTR6tg3GfnPnxFNP4fTRuzMFSxoA9JX9TzkZLKYvGh75bUxSgdOCDzW+fScHHwgCp/zM898SJx1+OmgzLIAmtKypGvwYBpRkEYNCYaJ7zGQsIGETGz0G9mPf0fEJTimR5wybvg/N2IhgSXGpg/ddzz1YfpaNYKX3uGj21GJ9PRvy/VubReAtaYUhAZTRTcpllGoem++OSjlGK86ds7QM/WTz9sGrf9pr/j0Wrjwsdt7PwChKtq3IcTbQUF9/LFxMvwkEtROfapQ9NPPRSlAxCQi6h0GdXd0NcdDK5bEJGGHlfivib5sejsldA3Ho6kNiJwBxFz7oOGzWo/ZbEAt47nW0GljRTgpsXmf84a67IQwORq8AOkI/ypiYOhDpGf2DPtZy6dKoh8oz07Wf/bH68X3LOLh0g3R21Ryq8iybqQGjmqsM2woK7Gt1qFNLFcdcTKqWfskmYEiGwKdCq1bMGsXUNqVJl/iX5DLHmpRKtRo2VSJBL5r+fgnAU2CzraRmNLnyCCL4T0cLtOCRv8SHP3xj/PEPX4FvNR/fC7wKzlAsnRMHHHdcrL/+r/GeC7vj4x8Fr+pageMO/2pqgOrhA+MlzzkzDlx1dHTiezk30d6cLTjG9QwF0CxaSFMPrlUHTdemHpoyzSNyxnsoB+O7hg/MG0HW1xOXAwRFECagKfvMsgOG8cE6SbMkTsVwc+ruYs4s2AJkBlpJp5jS6ZTeAxaGLOhFQtMxOMI3I/oc7GuME886A5/ZcJT1ShIA0TvQyKTmbX5bLCf629pLGmvVAXw+yeTdI4DiBC64Kb3AAA3w6NuJCnu374r9VyyLQfA1g+Wevr5YftD8WIH2+/vGjbEIbT5OX9WFsGwXkMYZw0/962+vpc6SQ4vGqyMAqPvnQxlI1WlKhwGZdzHORS188BoFq9f0L5tVIr2srE2zRaK10mW5uwKhiVv5PyGBgp7XmtAqXH5IbXBQClm+R+TctVQzobWqHqcpbtnXvXoN11a4zYVlNbXtcvS7kg5aqn+KmBWtlsUXmktAzMbxOfG4levjwANPLSX4PJzpkRPPfCnhdD0AIqHwL34a7/rkE+KTH9wQM/NIKm/bxLXG4/SzXxQnr/m36MIElAa6RHlZbqWmNu0DB0s4BOR8Rv63/HXuSV97FA6T9CHHxXTBYxpGK0wygNyKnRwuhcbpAJwcI1CwN5Y5wHqcda/tGo5iqmcjFPM6YJ3K4AQnamun1Izr6cPoYnYBN9jUpJ/hnMefezawDs884IgUJI/8nGbUVNqs5XNQGExs5UTavG3FkhVEcVPx1wf+GfvPnx+bd+4qKSmcwwmglmnYtPWSAJmFPUJkON0H92zhfnHUYQfHP2CIfvpNr4u/334PwOkSkHR6hXEIbrn7AUa9NER/H/DMHoBRSsliHRGp+gFuF79MrbViDjnY6+lBqhDY5jGnbmWnOekb8IuqTS0EPRuDFSKfW5yId/WVBMHkpRtam5rQAedkOzlMnzXH7xrtVXhYpo+UUFS1jAhrCbmeJk8BlDmj65FDINVKqSFLMadmw4ofjFOazzpGem7q6YmFlFy9+FWHcE1O/JzGWHHkEXH0QWviEULmXT0kW6/9cdwDmHj0Madg5jnBE7ujbuUJ8Z7zXxRzyI+1z2BCOgEBGaTURhrD+9NHygb9en+ofGnJLQjYyDCMBNOe+pUI+MgQ1BncpkbM8nBSe1kYksRjmKhWzG4OKjdo4gE0wyOjfVBuACRhdM7ljW0IbpfVNqgOmZ7tgI42O6kTjGQ9+nZMxilvei3LhZ8rNALLM+vHzHGO6lNg0ectiGOPeRzFtINovTmg4xu5j/ZYdw8HaS60HdapCe05Am7VtpzpY5AGhymwpdtcNOHQT+7eDXjaFF1zF8eubduimfnVpz/nRXHkAYeRPoJCc9iRsWlLT/zwrzcQXARtNu/iXA5G0+rlMbGF+9n7SDQcfWQ844B5cfJTn0rX5Fv2sj1iTcXcpA+jqclwORMuGdVpHjPIT79L0h+OIOYuo6DkpusWVSY1ufGlLDupMUaB/N6qc7EfOws7XDHHziaq7JdYVjG3ySStIsUsWLURmMFEZWrd7GwcwrtGud7suo1x7hkXx/17/pECOGfF7DjjjHMJmyGsgSrv3sCJ3PdDJqc+HC99w3PheWMi+3ZF63FPjLe/4jWxsHtxcp06O/GxIN0ZordSNi/9uaUNrSQpyfQKroEI33j2wefv+FVjsiatCSBP1QbAOc6cHCk2E8Ab2X5AXNDUTvLdEEWuMz4AzkQHwH5KrxZ0zwfqMdVD2I5gtRHNNbBQ5gg7aKr1wOZd8eLz36NU5uHOmkDghmzpIo5EusMxgM0LuuP4Y58UfXv6uO5w7N3O+OAOgFu06lwO+V4AUek/03uY+wPMID3U+zHPmdPVbEbW3YLCmQXUsITJG/vodNMQmx5eC0jM/QMzTAOWmnudzuJZZGA2Qw/gYHUtWx3LFnfFS045jgT37pg7j2j7hr/tNbxKP8CQPqM8jY/ZdVFe/svW0dUoEn+dGBdaTT9DM5e89HSJCuUlh1km0KUklchPtLxBZqqNNXBEs6EXFxonUTsh0GhrH8W44syXjswVYc2h5FYQZ9a/AKYml5KRim9y5H5DMW8+VSuAgjYqu+Cii2LTphGKIHZTRNEbD/75gfjIZY+n7+gr4qs/vC5uu50BTHu2xBEvOB3E+iQiMja3lVMNLNDRRmUOAtJgftRC1GbJevCpWMw6ig4UpkHxKgSqm/dNErUJWk7yTG2E4SOSHdHwbGkxpWKACINOfDMmWprMdJbVW0spz50prX4OsEdXdo6G3swaiJs9sndvPPf1byn+pY4eqZTk57i09u2U7mNOyFTbrPlx0IGrESS6PNMOfHvPVkDdhbHj4YdSCNuWYvL6yWNidqfJTtTB+5+/aF7st3hZ3PH3v9MPDFjGKWTzl8T+s2g7Pm9WHLpkHnSYqdiP62hmr/nDX2IA/3HT2jvTD6xfsiqOWrU6Vh1M6f99a+Pg5QdltmHl8lUKVl8tGExBqGmeMqJXn0PKLIuQ3rlmqoT4OVJOlwxVZOYkW0LbDcA0TEIGNUddE2JJlv5j8bcy2Zwaqny00ERqLtaoiQYZ+ic2T7NuWp8iyX3qCM1SlUtUo9ZBPdnXx2ikLdvjNW85IQX7+Wc9nwz+4+M+GqwN4AEP0Ev0gZ/eHH/94zVx9+1z4s71P4svfuETbMrGeNorXxhrjnw643qZJ9jE8EroLfWYpBnGmejnNbcpVMANzeBCAI8jLHLOXsaMTMqhymokeVJSaOze5xBzLTtZCwKDRhLT8qScLGEEramTNTrC+x0/10Ef92FCfQ85/gAAIABJREFU+dlQjx023oxm7qdZSRvkw4PoPX/UWa/B2gzAM+M05sh61gIhz/iHFkjZkMzkbjMlYxyELpLuLmkfoKeCOJ/Qv2ftPyV6EXW2xHAnv9xNXnTVikTqp6kzbFzIbKBeXAM0cxNmuYseE+MI7TikvUUrl5A9APeyEzSlZGO70PR8VtDqsrOjN973vnfGB770uazomdcORx5/tKVjLkRc9vL6WxCs4hMnsJewFZHWFNzw2qiT2uQsj4o5qxn7NgkbsOE5vRzzKKc7MSuFLaksFc9KEylDotSSpnCV7n1p7FKolMMCfgqMFugh+V5a0SqSzMChEsQ01p5um/XT2P/8118Q9+76R0ZF57/xXbF713BsYXj4MFr23nUPkCC9Kz536dp44H40wUBPnPGfJ2RS+ow3M9pkxdFow1Zycozh5QC1dhEZYgLaqDaZZJJ9I7MKWwVuccibmuG/Q7MRFhiB7dAhQ0Ifh3uzk8wMBHQFcoxqIA+B/LMxMLQJcm6Wxw/jxM/ugpTnwUmMplCpiQvz+feAOy3uGo0Fcw+I09/xoejZ9UgequSTWX6mi2HbRoQ42btGmGYV8PuSM4/ma5s/K4aJ+ADJ+B0mzzwozvoMlTOZlNesg61hi8mTovURME4PgqmTqMByL6zFiu5Oii+M8qdiG2yI/ZiOcSBVQMcefnQct+aIeOYacEH2eA+1gGvXbYqf3/jL+P6Pvhe7Nt3PUxEx/vaWfVUzEUdTm8U1hHXrqNpQO5gPzNNZNLItIiXYOAiRc5Y+UZluLiPC91baSN9c81pNt1d47KWVvdGVvrS5lnnpmBdQVN8uEXgJfAiWY9dy4EFOui8ZfoWt9Jifpq9nZyzvwnE/GKedUvkXnvnsWLmYnqFDPRD7mblF/u7eW7fE73/1Xk7+gXHjrf2x5uAd8YwXvxqTsjVeds5ZccCKo9AcMAtgO7SxMZx7Qnw1UTfPuie6qcuboRdWXQvCMiVUACMUKINS1zRtY7AUylBKCgnYcHsujGKCW/FnLLtPHE7aJL6Va+hkMAchdJIktvzeGUKd4mJQcTpwFRbjt5x98Sfj/n/enY6pB4qYwO5nRcgAYbMts/6W4aWC1TGPE2u5jUUZLBiCXTebBrp2dCNAoJSb++e1XTxLH6AmvP0ZDlhD57KY6gYsXTkr/u2Up8Uxy4+OIw8/LOZxD0tJ50zYY8yRjbpDtlNSYQChjCnE+JvCUfKB9bUNTvr2TcedIPPf+fnXQd7/uhN2sb39IKUlU4CHN/fsA2UJOT+QU1U1iWiq8oDTOfxSZ79gTtlfwZL7pBsb3RVto7BlIscKH4dYSoYTZed3JaOYIUNp7mVuMUltqs6qi7KKSr6W5tIUDr9XySmebYCAfSROT3vxk4kEh+PCCz4G1oNvhVO7fedA7IaLvv66q+KOO3ZHb+9g/O66gVjzpPvj1Be/m+LmvXHueW+KhfQLncRZbwFG6OqGSgMc0EZKYgZVbK+JNltpa95BmicRKtkFRkUejFb8iWGiP1NXTUAJQ7Q1qhffcn4hid0uig2GiABnpp1cz8/t8Q6PvhW/zTXTj7NdeL3lY7AE5jUviM8Bi/zgh9/OaFfLgDPHh8lwQEhlZBihu0FoWc1LJjfwr6ZpcJK50ezryOd3SPth8QZ3Rf2Kg2N6E35RC8l3wUxmFtctXhEnPflx8Y5z3hGH0SC3hYrmDjAUqebNAtrJjbObj9anUizFcSkaJh09lYVWp/yoFqDYh6Lud3/fRZaAWEefSkQ7ozBBudI9OflQXNjSrxwU7gezIAnfiZQLdKpCfZ9RZD5YwZzyAxWCpPFqKtVQpeg1p00hxRbDll4PXkMHzPUpmJa/z9pFTGf2xVLIqpROoy191vXEx/7n2/H7W78Uz3jpcbHm0OdRGLo7xnvoNdo0RAHm/fGx8w+J4455H77mvrjvH4Oxc+i6+MB/fSc6lm2Ls1/6n/R6p96YU9gMBbkZFNyTaQGthac+Xzv9Q6U3d1gEgQ85RbZArCpbN3IYcbXRaHa5sfy8nooVoikcaglwnQjqFMJdN83kL6K3KcyX3WYmKY/qwp+brFppO0KmFdN67+ahuOji9xbByayzkV/VMluOjkIBR6oO02g/BuqvKhyLz5eCTcuimEtOFPQ+tZQ9TdsZjbcFMLgJ9gWY2gwC2IZZe+e7Xhuves7rECgOE2ZyUkq64uKolYy9stKhVEQlLFDQTifAJdJTWSm5atlTVnxNuIl/yAip+8PdPTNm3B2T+livqkpAEBpToC5YqVx299UkfIha2GQxfxfhKv8rvpFFiynbYjop0YKZUnXVVMWBzxpEb0hZMu+mDCI40os1mVY8TWQC27ZJCiWMTTS7n+FnOS5l37Yd8dTnnQYRcSJe99a38jPIduSrtlJO30ZS9MdX/iAevu2a2DM2j7ZFjfGnP/fGr//8P3HXvTvj2DUjcdDyE3js2SxiN6aJwlQOjM9q8OYI3fS7MCGNmJt6WjqaZTCHikznPB1H9FruNVL5UbOp+ds3OIxWsncWLAAi1gHYE63wyrMukzUch6vVgt823bgHPxVMjMa2pmva8Rlf+/b3xFQPPHS58JnOEpA26uMDAXlTW1FkWwd+NcOAgqw8cmnIZ87QQARieiq3mAXfbNBUE6uK9kbSs+OMQ6fmHbkivv+p/40ly9fEKApFgoH3Je/eyLtNDaUACS+Kb2aSX41VsjDZ2TH3oEq/eaTSrSlJt8lUILzi5gf3zUjhkGyX0w1sDpJgZInSbONsNWu2uHZH85kVIP/upeSuF/ufTc8Ulmq8q0I0YTuf5Kgn4lnMoiaPUFJtZYFE6VtKWkZEDYHRT21WQ9p4rHxkEt+S1ZBDM+2+hxDgS6065LB4wtNPiCcd/+ys1BnCAZ5LQ7IHd3G9vh/E1y67JfqooetAKr/yldvj4AO3x09/v5082YZo6V5KQ7TZCDFw62yqWjCJo/2jFKXS04WiTDVHK1hSCxvXRIQ3BjrehsZwFNwwrIVRTF8XJ96FH8tKJ8ec0Led5gxNEPbG0WzSm2WbaiKFKoYxk23MiVY7j4Ff1cMwWNC9IP77c5+JtTaBQ8iTQ5bzUFQUWgxNnp1kXHyenwBCE1mPAFpNnrgW3Kp08mkpmZCE1chuZud+MdPzcDST6jnw4Ob44eVXky1YSvCBj2waScoOGYdmKoysY2gXetKPTj/WrjVasXIbuRMVqbKGS5UGLWmfEhGYZvNaSXTW3bFp1I5CWceZVc0185UpFPsxcGHVofKVKtEXiI8V7VOOVvnkgr4XCfZDirZKlZTkGuH0ZIVCX1Ww7a/iDEC9iBaEklqRdNBlFpoJ0AextXZeO/thFq0qBXiUWv/bb9gQr3vTk+Ost55FQ43DYST0Zw+F6Yk+mtgOxy+ufCc0ExxWHlaf4YbrttB4/w9x921NceBRRE5MlGiyaIIgwMPfpDBp+q0ShpA3gXNqSqWOCHECgLELALEeeoqb4YycTH3l4cpHTNOWz2+rbAtPzSAaYROGp4+ZVGornQFJ4ZXX0azWBiLrN26PT3/ooiz0EJQtFFOe20Ya+F8lXMe82WRNn0vEHaytzshdE6kwAYoaWEBZSG0riwKeMMI2EM2zWuLDF74hnvvcN6NBaQNuEpk1bvdZZSXgSzYLW7DHjg0sc30MpMrAhlQkWQHv/haNlsFcyloFIaV7U1gyFuTW3b9tlIMgjuS5U/E4/VTJdNJXTWiKdvJqecFHJdgflRZFhYhX5fFSWRZ/Kgdn6tx7AlxqE7SaRLSafQ+mrEVE2IoP5sd4un0Q8bJaGT73RYI2A4kKL1t/y0S89cJLYv2OK+LcC/BLKCRt4r17enfQ/YRZzXvWxmUfuBIqC45y+nYT8fNv74o1xw/GL65fF61zHkDx8R6ERue6xfA7q6ihlQhYgv00m1KR5dk5j/yd+Ur9SwOdYuongBqsZJombJvCR7J3lg7wMHxxfRH7MEwTwfncI1NDed3sbEgusBl6zCDaylU5/53voCoDxN68HziQzNcZ5ueUxhDsAZQakp7cU5UhsRk/n12HxpwBqZeYGMIYSjfpGRsImwwHbIrTTz8uLnr3xRSfrkg8VeinCT8jK/HQUK5xA6+31Mx0mj1TswkQh9yeaOmKVD5W4ok+eyqfIg/FRHGPujApL2Px+3/Aenho9xh7T0ogm3HZgsiT5d+JCJNd4GkpvlKWcGVmMSUwtWGKS1nn9LlqGitvLSkKRRgNTBOz8svCBG5kPH0Wfi4sIyrvry3p8iH5a7NdV6re8zIf3Xh1WiuVvuvX3xsveMbzY5hA59yz3w2STXK0Z6cHOfp2D8c55x4eh69+aQq7Ph/QYZz3ns/H+onr4zmHAKIuh8892ka+DnWPCewkhaO2AvrMapcsbuAk638Mobk0Ea1otzHMaicI/xR5N5yhTDg7t8+HsG/oKGNQWmwDBHg5TY5wgLxegjdEdeYZ21CNo9YaghdNU8j3lV//IG7/xQ8TxCS/krBJfql9pDZQop+N4qw0csFZmzpqJK09zN9LBwbghcJqxSmajj9U2zQ09cSrzjkjLnj9RzDhzqLWjbCpCM6NLcG9LFQbtZMWK/1br5lVQzJN7cVVimkrInFRUHmweW9RYClgYpZ+t1hXCbvkE9+Iui09ClbRVoUWVcL+Ut6V4pKlVikc+lr8V/jqxbkr1jF5EYXd4O95bwoVFxDjymZqSnWlFcuETnlc+mXGn5pFGagFF8mIQ+3AvdhKMqNJXUOOmSa4i8256fZ18dxTjo1DTnxSPPvpLwcVH4Sui7lCKHr23htf+J/L0BwdhRXBdRrZmM9/YyMZ/18zHm51HHNIY2wj+98Hst2ICcypZOYkcdh9bTNgJzhoDgGfroO+PD0PswWtF/aoWssK6BxjgrZoR8Nk/hMhHp+R911MpJSZEWAGux62wHHq5T7mZyMVTfk4OOVoXPie13PC8I0wvYKWpb5NvEcIH02k6QOhTyfcRvMOmQRCmCETQOtnNBUna5+8KIpC9Ljhh530vBPi6x/7BrdBQQR+nlle6eeZ2PbQptMqsO3elPVOP0tLyy8d3ec+ix4Whm4hXhYFVVgtGVtUIG+BI1A8EApGmsfivef9O4K1hwym5irr3TSobqSSWexszhj2oBTvLc3AY0WsJapL01BVJRfMqiSyFdQcHZuC5D2l+BZQNBWXalT5c1qF61nUq35VcpjSJHudooKzmAC/pG/zrPjeL2+Mj1/6qnjBeWeAEj+BRHFvaptJzNApz1gdz33aa/l32WzXw8lVX/3qvfGTv32AEqkz4hT6jd4jHYQVHmbxm3TQ2dxpabeV0LcTtjvORNK7xQlTLFUD0WE0cfJlFSMEDr1sloYiLZvNGpOxmkl9fU7uBx9ymlk8Ot9WY+tTuWgTsFS/cf2NpJu+V9ZHQUoCLf8HZ72caRfQBfLYKgzsgaxYIRdylTMi6YNEgi0ApCS9Z5MK+saXrooTjj856OGRmijtS81PSueoIP7FmXZfyxon2K0ApY9ZCmRTAvOz/XuZBZmpf+GnjKs8BGVfvVUVTxNK4OVveVvUbe+lU1NqLLv9elGTvUZw5WEKMa/wofRystzb11dmrfQaLTfnjdSGJeaQRn5nTq0Y5aLlvH4WC/Cn+oh8v6khvydomibYZ1HQFKjyXh3VNqK7H33vgfjAh6+kEdjV8cp3vyyWtj+e/pqbEBD8tqFN8fXPXQYfXZ4U5qwKkxXSP944EOd94/lx3omvjzOedWLcSlO2IfqG7rGSuQntRi+sZoSrnjxcov9iVTja09BsGnGs6+sJ9bOyG9cgSVWYWUxpJ9U1HqwJUiMTTKVXGPOoom1mnAiGT4VkwhvbhZzQNgmTN0Cxw8WXvAtTBixA8JBYigMLMLcz8qxczzy1CoaHnTUQqXfGo9rLNpGwO/VsKIiM1UfOjqu+8OPkhXXPXkyHIDjzvGXcomO+W8ybZqvITWr+cSvIkzDJLRhsue6pUMqfNHWayISa1HhlC5M3p6bLPUvvpewPmq6/ry6u+PqPom5b71g678WHKlhVrStfmqQUiBIhmnDN5iCpEx/7KjhGXvpRAXLIj68rz1P7uQh7pa0qQ5tgamKnDg9ijRx4qZ7mPWoxT5HcvfTleGE7VOI3ve0zcfX3vgmffE+8hminvYnJp1BjB2nZ89Y3PzUOWH5K5vtSmJV7rtfApn3rm/+Mv2y+PJbCIH3TK14Zd659kEpmhlnScC0XjeYalr5LnZkyZGfTOrtA5omwLAVrhB8vqtwBA3OUkn3za3UOFYGiLB+e9C2tjJj2JcSSJ5l/Yx4aKPsaIfyfQBi60SxSbK69+ea4/qqvJnc8NVQuEdGcUR64mExeswB5qFPJ6Yzzb3N7rYtI/NKHIl/TFMuPOyS+9ckvZsO5ce5p9QGrOaiSCrV4uXglmEhL5Da5ms7ayeC1wgqVX6I6z0vlsrgoxvO19ugKU21s4KN4lrQgd6fSWDfdTl3np98ZdTv3MWFPjWZnPCMEt9XNEBVPu1q8qmScpxotXzXhKqyHSmul+JYbL3JWhOj/aDgFRMdf/0p033AS59crK8aZd8wytErNVonnmsx2ESZ/9HPfj4+870LM1lCc9/4PsHEAkWToR2e2xNcu+SwBkaq7Ol5+HqethdD95z+diev/dnnMXzYQ55/zvHjgLiqEqRbup4XPJJsqtj5JlNfeCNqe+E2JAhtoaO9tmkecAvFuBYKYkE+Pg6+fYk5uHLC0DepP/9BWBBPQVT4bbNRBtItgcv8I+UOErAkB34ym+cLlX4nxR24tCWRyeKVSW+2k5sKOgXExj66sY/YzRS1wn16szlaV47szaJp9wLL47Xd/hCm1XtEZj12xZBXkPdMxrOFopsisF/KrwDnujsdG57x08NFJF/4oOGPWcSbO7kPLaFFBVDBDZXmyh1cKbUm3WeVtZuK6P22Mq3/ynajbNWCQXGmWmm0tYl3dwqOy9OhfCk24ahjCRXPkXApSlVRWmKqTYrScj5Rq/f/9JcXYnxVCoV+FI19MbU14c0KYD4taH+5rjg9+/kvx9U99LJrJVpz9lvPIVkD637QhvvHJc+GgP05SdTllyrs+FpduZiDTTb9tig99+61x1ONWkyM7idq75fHQvTdDXSZC5Hks7GiW6oKQ6c7oJ2lK68GJGpvAjEDvzZVOzJAGaYI9qTk0QY7ATNdTfQNHTS5WvRwz4Npushl7aJg7Q2RnSmp8ajeNgZvjngfvjx9/9oM+LEqKa8E7t69EClZO+uCYJeqOb4b2nEGjpqClBpOAKbbVRADZHr/4znfB1xbi/w+DvcHM4PVzl9CWkiCkiqwqjVNza/S9CklS6ndZ/RKoZXLfnG0KmMqlCFdWcee/vaeyh4U4oGDpc/sDYYyp+Phnvxvr6QVRt2dQDmi6C8Xc+AE1G1vb3LyRipasUKWtrqIJ3qCTmB9WOwuPNnHjsHlveSM1DVL7u45iMbOpnGoOffK5ipDVfK0cGcuDiKf85Xcj8ZVffjV++a1PxtHPPCme8ZSTY7gfZL3rgbj4HWgraeCesNSuCpcS4jNNx/W/GokvX/fRWH3QQLztzGfG3PZT6aN1fexDEGAbJzO0CRxqchxTSK6wrINZABillFA5Fm5qEHYkpnAG57se0LIeJkTDJPgUYOWEPgsnGT1Ga24KZWnUNY4mcl1kkzZS8NpLc44vXXdzbL3+W0U7qc4sRM0xyfLYrdXnZ+IxVjnk5vEnKcnk/wwCELJ2ePu/+dlVFKgekM1phQ3sfTpNe4BVhy+HdIi2I7GdoLLLUGVSynyistMpV2rcCqfKaqhMxxWzKfdOp7342d7GY0hBGir95Uph+N1bvOTj34u1Dz8QdT0DwA2i2SVzUyTVz0vTLO2Ff1Ql7kVEamawwPgCAVmanyLymBBZfl8KVEtapghe7nBGS0UpangL1GF+sAiT/yeb1Vd792ifbAtOFoDPed+Ft8X3r/sSrXT+HC94zVmx/4LF8dDanvjSl16J2Togk7w5eLNKaOs3eB17Ul33i9G46Iqz49THwys6ZjBe8uxPxS1/uTV6hvqg9JJ6ARqYkJLMWWvMJv4U8tJWaASt1A4QaTQYwxZqoNEIq63Rc5jEjHlMuOwDDF9qtVkbWmh8fAfV0jyb86NRNqO8v4XcwlYi0S9/4X9p1bWh0F4MUDB5dVZngJHp7BdV62mzNwJCm2wKtJeGyqzA/Ib4IQ16l81eQRvLsneSnmzgYtulo6iTdAhB0f3lgJQ5R8UK2EzFv9t/I4XDLVaYqr0q/TqK2fTnSU5wn9JUl4OaspYm0JF95cu845ve+4F45D5G3u0eZECuvlWyEtLdKf5Febzy9zRD1cWrmytmqrQg0rb/H8Gq3psTuXK4ZQ2bUvT0eTwFagA7cxYXLTuqVCZYoSzsBhdYh7/0ZWjlBJ13wbfiu1+7PCZn7Ys3vPGdsEc4xX0PxaXvv4L0jazXciBKp4eiERNL46FvuHYsPvyNf49VyxfFkgV3xv9e9Lu4/94dmNF1sZdRHeNoENMRU3DG7DZo/3MFaDRmQUOeBZCKrzVEjs8Jpo5pw99yclcGNazCCK9stFkbWewpmonoEjU5ntdMgwWe9DvdS/vvL3ziwlIQkSG2DEiwC5s45A6pqfSp7CeB31ULmARIWbf2ea1x9RXfi/0W7cd9qMk9pOBneQCp9eOtRx19EGbR6WJKQNk7J3bVBKMM1HLYeBGd2tf/Oygr0buRZVnR1E7pgLuvvrNE+JOV4mlBwt8OLdyC3RQsL6yZqV2opkUk89m2KLu5VHhS8ekKJFHIw5WmqvlZ1TmpWcVCGnzUVlaq191X2OxTUIDV/KqkOTkTCqUpIR7GB1Puuwjrz7nov+Mq7Hj7YQvixaedSYQ2EW98xZpYvvAkHFdfX9O6LoALWBVmcPkrvr4hfvvPzyWjd+H0vfHty38GT2sibvr7X+nCMkgEh9ag4cWQgsBrmpjqFY1Md8ihS7OSmzSeDWyBDoAhssYQwUnqo2xRe7sT4Y1D1TVtItPTszIKfGAR8ASa9O/3rI8ff+bNlfesuQYXM/6lg3H6TtnrVRxLjUVrAPtuwUVXywuQ/vSbX47lSw6jXbp+tc/GM8N+GLZSGjbnHsDTU087meUV3hRe9x6cRv/o8hINlkPcmI23HhWrmir5l58UjZWDyLNA5rGC4kSY+G+Sw1wCL9t1NsQXv/7JuPUBEuA7+0eyjZF/POOuaHGLnBWjeiwblNLsfYhpIKWyCUvfUosufH1RvMIVKpoENfM8lJs3Afto9JhRpAJlJXU5STW1m2NTUjgK/OA1J+X4YA5bCF/f8IGL46rPfSqOetZzYuH8ZbGCCV2f/eR5LKzRiaglb/EkphMgx0yfsKjp3/5yT/zir5dTx0cb6dGN8Z2PfBTmQ8Sdd66LXXDNBwBK6xECxCNH8daR/5tgpnC7rR5lV2DuBqHltKN9xHYcPzLJFKScjArNt44+VNNsvumxnNjBZ1rb53pawDpDSuUHf70jbv/GpQisXCo+XEqM6yFACuhpglAWqiVjZiUyF2FpPc7957/10Th29clZem/u026AJUkvEA2AiwalEi1OOImmKNLBiXCba2D1ozJUIr5HkfRHxegxv/ZRUUsfqgiWH1K6NlZmuhKmYrKLFhtG01/2iavw92Cw7ugbQqkUG6zflumaKlrPG6hSPMWIVQ6b3Wmq8ns/KHNMqffYULGOlKFiv8tUMG16EdZatFcAN02B7y1qJsG5hCGKkJu+zVBWP4LXW8dz9gUfjZ996/I45bUvj2W0exwhOfvNT306c2GF91UJsmqcT5SX74K08fs7/tEaz734efH0pUfRHnFT3PDlD7ONc2PT5l7KnB6OfmoQ+9U6Hg6ExhygWYdGmAb2pKqrWwzblJ9Z2kXaRvM8TAl8t9MpaIDbgLM95tjeHNhXXIgxBFV+1swkeUk00LdvvCnu/yHFHNm0RE1dXIXsf+F4ODWD5WA66ZLTdOr531nnnRlvPeM1LFN3NhmZQrvZNikLVNGEox7QIZp+YL7XPPnQDCJcgdKlsQQhjwqMCsDfpi9VhKb8KX7T/xEsXZE0nTJSSL8ZGFa9zfJ1qa7c5JnYtXc83nvhx+PBkc0FIPVaWfvm5RNhLwJUgwxSk2kKEbRG84EKlqcmw/Fqwr0XKX6d+HyRYvVOxu25zmUhq4HiRQzLmvpdCo3PWfytcq9TyUgFQbcAlh+iQGLNy86NjbdfEy87941wrKZoItaT849HRLkr9VwpWe6vIMZ+WSWzaf1MXPS5t8Wq+ctj7SP3xNWX/ScnfTnmkDY/6x8hb9hHQQPFEqzEGONNxk3YYgZbUclDBAX19EsXFO9A+05aPGGRbdIc4ZHi0DcjxM4gagA+qCdCmwLiUKP4uhEEs42o8qs3/C7+efXl3JCTLBQ48S5u3PXTWff1JprhZc3AhnVD5z/pcXHlh/6bQtTlOXou8UTW0epq54FpVdTMw2jTYRy7U099Wulu4w466cN7yu0pe1QEqLgIBQf4//96tCpKAXNH07UoucNM7amPjeiRm/Wb98VnPv3puJO+Y3Vb9go3KNEKDn/SDv6r1OpTFmnO5HdqN17HQXNZNYX6nbXowtf5mhxfloJUvTcxkYq//f/xHNm8TdAtncJyC2oqJU1SWjPm4fY7J+LUFx0PhNEbZ73iP6J7QWccexjVNs+Beqx7QkOPGk0nc+A+eIWFmMNa/1BdXPL5C6OvbzhWHbo83vLi/SlxOjX27qZhxtae2LITvhYMzkYdc3OINvynvm+cqpZJTNVsBKuXXF09Kl8SgdkFCYjjJJubScvUZUJdUhP3i+vqxDQnQxj4TUJtbgfU++Jvfx1rv/dpFtOkN+CouFTm4xSwwmNPfnvmuyjuWNgRH/ng6+P4xz2PhDY9HgAzpEyrsWw5aXPdOsIgkjoiAAAFxklEQVTOqZa50K9HweR2x2knP6PMQrR6SjKL4GYtAGNJc0xdCkW1b7ofqdUeS9X96xb52owcBUM9A6mBKhS+co/N2ty8dmd89euXieCVJHSB7AuyLgiZiPm/cCUmKn9JCc8hcfLC/c779LWadJprd5Intthd81FlkKXOfi0CKhhw7auGg9SGVUvIf1Swkolqo33MCcvx1a+AP11wSDQ9bkW86MnPo0W2DdMOoKLklHRQU0PXYIv/E6baM7U+/nlfXfzHJa+NvfQpWLpqSVx27vFxyJGvjJ6dTEelxm4bldNbKZ0aAZOaRMMN0kys3t7xPJ0tqYfHaW2En7SP9RGTamKTnfrVSuMxgdIRJjrMBqR0RIiaZwKz2AriP1GNI54kD/ir66+JP175cZw+u7jiu3G9DB9z3cvBSgq4kSF9s97znvPiqENPYMwun22BLD93sKhm3yLaCeCFaYS9H6FuxpQO0JzjtGecXs3q0SUuYEIiCaltiikTopK/9q+1mjXt9K9ZlUfbUfE+z7kYYVGw+sU19VcU0y9veCCu/NaXY8XKeVG3FVOYOqXSxsUMFs1cZIsQNqVbh7jklrxeowOFdGD5u60Ltb1SXMqvS2+GCrjNn2VZmCeikqjHToeOaIkyFTLteZoD1Wsi+YT3hLFMdIm3Xfrn+NJHzoo1r3pRHAoleGhyXlz5mdei2eAjycXPULj2AeUomTTO6+PI/vmm0fjMVa+NVY87LHq2woI4qiFeeub7Yu9ek8K0Qtq5J9bRp3OUlIuLP4Jmku44zUN2QJeR1zWZ5e0IKoUO3vM4gtMIe2EabWNbRwcDTELA6+eAtLs2Eqa5FSNsW1Be8ZtfxJ3f/UR6Px7e9IXUUrnwku2VA0wo13rZ614WLzyZQwMjdN48ePskyQ0Ya7QlJ8CKhW1iLN4ciib6B/dB0ZqJE59ySq5lcT+KdnJiRzo37m0ujBv8aLxeesrWlq4ydpMVo8XBpTVhSwOr/1ppuEJj1HTPxO+v3xzX3/YjhjnRH2t73zh7yIdUTmIB4WomrACTBQb12ctUTT9PnywT15wEp1cUZkThVslTqj28j1H6L5Qh4jZom1b9Vw+ZjVsrHMQFqAlWmkIT1FzQTsmdCPKrLrwivn/5JfFMHPdFFDnMau2L/73ki2iN4qilKa3ghTylKcjVKUXLXv3DzXHbw5+PDVv2xeknnEZZ+E3xifd/KHYMjEffzv7YsXVX8uP39e/gHkHgCfGHrMhx5AmQQCeznfuZHVMHom73wmYgB0fI0dkVhx1yoCZUoBkn1yBkGJ9KrlYdn51deHjW39x5W1xz+fvTDNo1Oc09wCo17gktpCPJpp/+hpfG845AUy1eGT0MRDpw1UEU5SxAkPFG7bZsoMUa9OxDg7n2I2pafg5H/4lHHa9TUyRI378GcrvmblMV3WUrKf+dlqgIVhIRPNgGXvlaoYrK3j0qeo+Z0Ckrtfw0XvvLnz0YH/7qRXHIYYcYFVLqYJ+l3ISKSpwdXgr/pmiwyiaXO0xfrMxy1jksUaHvt5jBE1EqoYsZm5LHU6VuJIYlfvIvKHAp+fLzyoOlr2WtnfdjyMziOLK3A7P6nH+/IG78zY/i5a96I8I4Ek9+an+c96LP4uvUQuVyIGw8kjERC9eUyDtfPM9VV22Lb/zu61T23h5Hrtg/mkfb4ztfPp8WiF30juqjk2Qvznw93e+259DuvRDxsqgE2nM9wtMIRDBhe0gEZRR/phHMygKEOhBH/Uq709gzdwpSn626mWJIn41O7s+mH2rk8ejdMxWXXvyG0sk5j2HxVeoAVR3L5gIectqJ8fYzz8DXWxIdMCNoJonGooqIOsUWe2Yg0JOYTwl5U/VzaKe9hQwAiD/J7wbK6I89+tgEi/8FGSguQvrR7mUxXU4gSenTVRFXTCErbrFpNEff+V8O0EjnvbgbReNVPqwKQEXE81959R/iJwx0n0WLpP8H1cqaigaz89QAAAAASUVORK5CYII=" style="border:0px solid black; height:150px; margin-bottom:0px; margin-left:0px; margin-right:0px; margin-top:0px; width:150px" /></strong></span></p>\r\n\r\n<table align="center" border="1" cellpadding="1" cellspacing="1" style="width:500px">\r\n	<tbody>\r\n		<tr>\r\n			<td style="text-align:center">Spec 1</td>\r\n			<td style="text-align:center">Description</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="text-align:center">Spec 2</td>\r\n			<td style="text-align:center">Description</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="text-align:center">Spec 3</td>\r\n			<td style="text-align:center">Description</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p style="text-align:center">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod<br />\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,<br />\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo<br />\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse<br />\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non<br />\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', 'PRO5698', 'Active', '2017-12-01 05:34:07', '2018-01-23 07:14:14');
INSERT INTO `sts_product` (`id`, `product_name`, `sts_category_id`, `sts_brand_id`, `product_image`, `product_desc`, `product_code`, `status`, `create_date`, `update_date`) VALUES
(5, 'Iphone 6MB Colour 56 Gsm 45.5 x 58.5 - 7.2 Kg Blue', 7, 4, '1512568442.png', '<p>I phone 6 64GB</p>\r\n', 'PRO4523', 'Active', '2017-12-01 05:35:07', '2018-01-23 07:17:32'),
(6, 'MB Colour 56 Gsm 45.5  x 58.5 - 7.2 Kg Yellow', 3, 3, '1512543878.png', '', 'WOOD5645', 'Active', '2017-12-06 06:15:26', '2018-01-23 07:18:25');

-- --------------------------------------------------------

--
-- Table structure for table `sts_role_master`
--

CREATE TABLE IF NOT EXISTS `sts_role_master` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) NOT NULL,
  `role_code` varchar(100) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `sts_role_master`
--

INSERT INTO `sts_role_master` (`role_id`, `role_name`, `role_code`, `status`, `create_date`, `update_date`) VALUES
(1, 'Super Admin', 'SUPER_ADMIN', 'Active', '2017-11-27 11:44:01', '2018-01-22 11:49:14'),
(2, 'Admin', 'ADMIN', 'Active', '2017-11-27 11:44:21', '2018-01-18 07:08:28'),
(3, 'Manager', 'MANAGER', 'Active', '2017-11-27 11:44:48', '0000-00-00 00:00:00'),
(4, 'Employee', 'EMPLOYEE', 'Active', '2017-11-27 11:44:48', '2018-01-22 11:49:09');

-- --------------------------------------------------------

--
-- Table structure for table `sts_store`
--

CREATE TABLE IF NOT EXISTS `sts_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `store_name` varchar(100) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `sts_store`
--

INSERT INTO `sts_store` (`id`, `store_name`, `contact_person`, `contact_number`, `status`, `create_date`, `update_date`) VALUES
(1, 'Chroma', 'Kishan Bhai', '9989789568', 'Active', '2017-12-01 05:50:46', '2017-12-01 05:51:15'),
(2, 'Sales India', 'Nikhil Bhai', '9989789568', 'Active', '2017-12-01 05:50:55', '2017-12-01 05:50:55'),
(3, 'Vijay sales', 'Divyeshbhai', '9989789896', 'Active', '2017-12-01 05:51:38', '2017-12-01 05:51:38'),
(4, 'Woodland', 'Krunalbhai', '9989789896', 'Active', '2017-12-01 05:52:55', '2018-01-31 11:43:12'),
(5, 'Bata', 'Axitbhai', '9989789568', 'Active', '2017-12-01 05:53:26', '2017-12-01 05:53:26');

-- --------------------------------------------------------

--
-- Table structure for table `sts_store_branch`
--

CREATE TABLE IF NOT EXISTS `sts_store_branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sts_store_id` int(11) NOT NULL,
  `branch_name` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `latitude` varchar(100) NOT NULL,
  `longitude` varchar(100) NOT NULL,
  `contact_person` varchar(200) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `sts_store_branch`
--

INSERT INTO `sts_store_branch` (`id`, `sts_store_id`, `branch_name`, `address`, `latitude`, `longitude`, `contact_person`, `contact_number`, `status`, `create_date`, `update_date`) VALUES
(1, 1, 'Ahmedabad', 'Jb tower, Ahmedabad', '23.046228', '72.528112', 'Maulikbhai', '9989789568', 'Active', '2017-12-05 06:07:54', '2017-12-06 12:20:43'),
(2, 1, 'Baroda', 'Near. Express way,baroda', '-22.313937', '-73.222933', 'Nikhil bhai', '9989789896', 'Active', '2018-01-22 11:41:43', '2018-01-22 11:41:43'),
(3, 1, 'Surat', 'Varacha road.Surat', '0', '0', 'Shyambhai', '9989789568', 'Active', '2018-01-22 11:45:22', '2018-01-31 11:43:36'),
(4, 3, 'Memnagar', 'R3-mall, manav mandir,ahmedabad', '23.046364', '72.540361', 'Harshad', '9989789568', 'Active', '2017-12-05 06:10:30', '2017-12-05 06:10:30'),
(5, 4, 'Woodland shoes', 'Gurukul Road, Ahmedabad', '23.048389', '72.533551', 'Sujitbhai', '9989789568', 'Active', '2017-12-07 13:27:38', '2017-12-07 13:27:38');

-- --------------------------------------------------------

--
-- Table structure for table `sts_store_employee_int`
--

CREATE TABLE IF NOT EXISTS `sts_store_employee_int` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sts_branch_id` int(10) NOT NULL,
  `sts_employee_id` int(10) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `sts_store_employee_int`
--

INSERT INTO `sts_store_employee_int` (`id`, `sts_branch_id`, `sts_employee_id`, `status`, `create_date`, `update_date`) VALUES
(1, 1, 1, 'Active', '2018-01-22 11:29:42', '2018-01-31 06:54:21'),
(2, 1, 2, 'Inactive', '2018-01-24 05:17:12', '2018-01-31 06:54:21'),
(3, 2, 4, 'Active', '2018-01-25 10:01:37', '0000-00-00 00:00:00'),
(4, 3, 2, 'Active', '2018-01-31 07:33:23', '0000-00-00 00:00:00'),
(5, 5, 3, 'Active', '2018-01-31 07:33:48', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `sts_store_product_int`
--

CREATE TABLE IF NOT EXISTS `sts_store_product_int` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sts_product_id` int(10) NOT NULL,
  `sts_branch_id` int(10) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `sts_store_product_int`
--

INSERT INTO `sts_store_product_int` (`id`, `sts_product_id`, `sts_branch_id`, `status`, `create_date`, `update_date`) VALUES
(1, 1, 2, 'Active', '2018-01-25 10:10:39', '0000-00-00 00:00:00'),
(2, 2, 2, 'Active', '2018-01-25 10:10:39', '0000-00-00 00:00:00'),
(3, 3, 2, 'Active', '2018-01-25 10:10:39', '0000-00-00 00:00:00'),
(4, 4, 2, 'Active', '2018-01-25 10:10:39', '0000-00-00 00:00:00'),
(16, 1, 1, 'Active', '2018-01-31 07:33:09', '0000-00-00 00:00:00'),
(17, 2, 1, 'Active', '2018-01-31 07:33:09', '0000-00-00 00:00:00'),
(18, 4, 1, 'Active', '2018-01-31 07:33:09', '0000-00-00 00:00:00'),
(19, 6, 1, 'Active', '2018-01-31 07:33:09', '0000-00-00 00:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
