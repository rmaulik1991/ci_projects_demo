var oTable;
$(document).ready(function() {

	oTable = $('#companyTable').dataTable( {
		"processing": true,
		"serverSide": true,
		"ajax": {
			"url": base_path()+'company/ajax_list/',
			"type": "POST"
		},
		aoColumnDefs: [
		  {
			 bSortable: false,
			 aTargets: [ -1 ]
		  }
		]
	} );

	
	$('#companyFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		 fields: {
            CompanyName: {
                 message: 'The Company Name is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Company Name is required and cannot be empty'
                    },
                    stringLength: {
                        min: 2,
                        max: 30,
                        message: 'The Company Name must be more than 2 and less than 30 characters long'
                    },
                    regexp: {
                        regexp: /^[a-zA-Z\s]+$/,
                        message: 'The Company Name can only consist of alphabetical'
                    }
                }
            },
            Address: {
                 message: 'The Address is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Address is required and cannot be empty'
                    }
                }
            }, 
            Mobile1: {
                message: 'The mobile no is not valid',
                validators: {
                    notEmpty: {
                        message: 'The mobile no is required and cannot be empty'
                    },
                    stringLength: {
                        min: 10,
                        max: 13,
                        message: 'The mobile no must be 10 digits'
                    },
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The mobile no can only number'
                    }
                }
            },
            office_number: {
                message: 'The Office Number is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Office Number is required and cannot be empty'
                    },
                    stringLength: {
                        min: 10,
                        max: 13,
                        message: 'The Office Number must be 10 digits'
                    },
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The Office Number can only number'
                    }
                }
            },
            Email1: {
                validators: {
                    notEmpty: {
                        message: 'The Email address is required and cannot be empty'
                    },
                     emailAddress: {
                        message: 'The input is not a valid email address'
                    }
                }
            },
            Admin_email1: {
                validators: {
                    notEmpty: {
                        message: 'The Email address is required and cannot be empty'
                    },
                     emailAddress: {
                        message: 'The input is not a valid email address'
                    }
                }
            },
           contact_person_name: {
                 message: 'The Contact Person Name is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Contact Person Name is required and cannot be empty'
                    },
                    stringLength: {
                        min: 2,
                        max: 30,
                        message: 'The Contact Person Name must be more than 2 and less than 30 characters long'
                    },
                    regexp: {
                        regexp: /^[a-zA-Z\s]+$/,
                        message: 'The Contact Person Name can only consist of alphabetical'
                    }
                }
            },			
            status: {
                message: 'The status is not valid',
                validators: {
                    notEmpty: {
                        message: 'The status is required and cannot be empty'
                    }
                }
            }
		 }
    });
} );
function delete_compnay (del_id) 
{
    bootbox.confirm("Are you sure to delete user?", function(result) 
    {
	   if(result)
        {
    	startLoading();
    	$.ajax({
    		type: 'post',
    		url: base_path()+'company/delete',
    		data: 'id='+del_id,
    		success: function (data) 
            {
    			
                if (data == "success") 

                {
    				oTable.fnClearTable(0);
    				oTable.fnDraw();
    				$("#flash_msg").html(success_msg_box ('User deleted successfully.'));
    			}
                else
                {
    				$("#flash_msg").html(error_msg_box ('An error occurred while processing.'));
    			}
    			stopLoading();
    		}
    	});
    }
 });
}
$(document).on('click','.status_checks',function(e)
{
    var id = $(this).attr('ser_id');
    var status = ($(this).hasClass("btn-success")) ? 'Active' : 'Inactive';
    var msg = (status=='Active')? 'Inactive' : 'Active';
    
    bootbox.confirm("Are you sure to chnage status?", function(result)
    {
        if(result)
        {
            $.ajax({
            type: 'post',
            url: base_path()+'company/statuschange',
            data: {id:id,status:status},
            success: function (data) 
            {
                if(data == 'success')
                {
                    $('#ser_suc'+id).text(msg);
                    if(status == 'Active')
                    {
                        $('#ser_suc'+id).removeClass('btn btn-success status_checks').addClass('btn btn-danger status_checks');
                    }
                    else
                    {
                        $('#ser_suc'+id).removeClass('btn btn-danger status_checks').addClass('btn btn-success status_checks'); 
                    }
                }
            }

            });
        }
    });
});