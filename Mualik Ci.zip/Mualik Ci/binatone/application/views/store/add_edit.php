<section class="content-header">
    <h1>
        
        <small>
            <?=($this->router->fetch_method() == 'add')?'Add Store':'Edit Store'?>            
        </small>
    </h1>
    <?php
		$this->load->view("/template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">
    	<div class="col-md-6">
    		<div class="box-body">
                 <div id="flash_msg"></div>
                 <?php echo form_open('',array('name'=>"storeFrm",'id'=>"storeFrm")); ?>
                    <div class="form-group">
                        <?php echo form_error('store_name'); ?>    
                        <?php echo form_label('Store Name:');?>
                        <?php echo form_input(array('id' => 'store_name', 'name' => 'store_name' , 'class'=>'form-control', 'placeholder'=>'Enter Store Name...','value'=>@$store[0]->store_name)); ?>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('contact_per'); ?>    
                        <?php echo form_label('Contact Person:');?>
                        <?php echo form_input(array('id' => 'contact_per', 'name' => 'contact_per' , 'class'=>'form-control', 'placeholder'=>'Enter Last Name...','value'=>@$store[0]->contact_person)); ?>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('contact_num'); ?>    
                        <?php echo form_label('Contact Number:');?>
                        <?php echo form_input(array('id' => 'contact_number', 'name' => 'contact_number' , 'class'=>'form-control', 'placeholder'=>'Enter Mobile Number...','value'=>@$store[0]->contact_number)); ?>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('status'); ?>    
                        <?php echo form_label('Status :');?>
                        <select class="form-control" name="status" id="status">
                            <option value="">Select</option>
                            <option value="Active" <?=(@$store[0]->status == 'Active')?'selected':''?> >Active</option>
                            <option value="Inactive" <?=(@$store[0]->status == 'Inactive')?'selected':''?> >Inactive</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary btn-flat" type="submit" >Submit</button>
                        <a href="<?=base_url()?>adminmaster/" class="btn btn-defauly btn-flat">Cancel</a>
                    </div>    
				<?php echo form_close(); ?>
             </div>
    	</div>
    </div>
</section>    	