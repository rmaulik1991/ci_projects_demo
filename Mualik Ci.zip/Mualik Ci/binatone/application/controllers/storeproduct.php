<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require ("common/Index_Controller.php");

class storeproduct extends Index_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('storeproduct_model');
		$this->user_session = $this->session->userdata('user_session');
		is_login();
	}

	public function index() {	
		$data['flash_msg'] = $this->msg_session;		
		$data['view'] = "index";
		$data['store_list']=$this->storeproduct_model->selectData(STORE,'*');
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');
	}
	public function get_branch($id){
		header('Content-Type: application/json');
		$where = 'sts_store_id = '.$id;
		$data['branch_list']=$this->storeproduct_model->selectData(STORE_BRANCH_TABLE,'*',$where);
		echo json_encode($data);
	}
	public function assign_product($id) {
	  	if ($id == "" || $id <= 0) {
			redirect('storeproduct');
		}

		$post = $this->input->post();

		if ($post) {					
			$data=$post['allocate_product'];
			$assign_data=array();
			foreach ($post['allocate_product'] as $row) {
				$assign_data[]=array('sts_branch_id'=>$id,'sts_product_id'=>$row);
			}
			//echo '<pre>'; print_r($assign_data); exit();
			
					$result=$this->storeproduct_model->deleteBulk(STORE_PRODUCT_INT, $id);
					if($assign_data!=''){
					$ret = $this->storeproduct_model->insertDatabatch(STORE_PRODUCT_INT, $assign_data);
					}
					if ($ret > 0) {						
						$flash_arr = array('flash_type' => 'success',
										'flash_msg' => 'List Updated successfully.'
									);
					}else{
						$flash_arr = array('flash_type' => 'error',
										'flash_msg' => 'An error occurred while processing.'
									);
					}
					$this->session->set_userdata('msg_session',$flash_arr);
					redirect("storeproduct/assign_product/".$id);
				
				$this->session->set_userdata('msg_session',$flash_arr);
			}
		$where = "status = 'Active'";	
		$data['flash_msg'] = $this->msg_session;		
		$data['view'] = "assign_product";
		$data['id']=$id;
		$data['product_list']=$this->storeproduct_model->selectallproduct(PRODUCT_TABLE, '*', $id);
		$data['asn_product_list']=$this->storeproduct_model->selectproduct(STORE_PRODUCT_INT, '*', $id);
		//echo '<pre>'; print_r($data['asn_product_list']); exit();
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');
	}

	public function ajax_list($branch,$limit=0) {
		$post = $this->input->post();
		$columns = array(
			array( 'db' => 'p`.`product_name', 'dt' => 0,'field' => 'product_name' ),
			array( 'db' => 's`.`Id',
					'dt' => 1,
					'formatter' => function( $d, $row ) {
						return '<a href="javascript:void(0);" onclick="delete_brand('.$d.')" class="fa fa-trash-o"></a>';
					},'field' => 'Id'
			),
		);
		$join1 = array(PRODUCT_TABLE.' as p','s.sts_product_id = p.id','left');
		echo json_encode( SSP::simple( $post, STORE_PRODUCT_INT.' as s', "s.Id", $columns,array($join1),"s.status !='Inactive' and s.sts_branch_id = '".$branch."'") );
		exit;
	}

	public function add() {
		$post = $this->input->post();
		if ($post) {					
			$data=$post['allocate_product'];
			echo '<pre>'; print_r($data); exit();
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('<label class="form-error-msg"><i class="fa fa-times-circle-o"></i>', '</label><br/>');
			$this->form_validation->set_rules('brand_name', 'Brand Name', 'trim|required|min_length[2]');
			$this->form_validation->set_rules('brand_desc', 'Brand Description', 'trim|required|min_length[2]');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			
			if ($this->form_validation->run()) {				
					$flash_arr=0;
					$data=array('brand_name'=>$post['brand_name']
								,'brand_desc'=>$post['brand_desc']
								,'status' => $post['status']
						);
					$ret = $this->storeproduct_model->insertData(BRAND_TABLE, $data);
					
					if ($ret > 0) {						
						$flash_arr = array('flash_type' => 'success',
										'flash_msg' => 'Brand added successfully.'
									);
					}else{
						$flash_arr = array('flash_type' => 'error',
										'flash_msg' => 'An error occurred while processing.'
									);
					}
					$this->session->set_userdata('msg_session',$flash_arr);
					redirect("storeproduct/assign_product/'".$id."'");
				}
				$this->session->set_userdata('msg_session',$flash_arr);
			}
			$post=(object)$post;
			$data['admin']=array('0'=>$post);
		
		$data['flash_msg'] = $this->msg_session;
		$data['view'] = "add_edit";
		$data['current_view'] = "add";
		$data['user_role'] = $this->user_session['role'];
		$this->load->view('content', $data);
	}
	
	public function edit($id) {
		if ($id == "" || $id <= 0) {
			redirect('storeproduct');
		}

		$where = 'id = '.$id;
		$is_error=0;
		$post = $this->input->post();
		
		if ($post) {			
			
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('<label class="form-error-msg"><i class="fa fa-times-circle-o"></i>', '</label><br/>');
			$this->form_validation->set_rules('brand_name', 'Brand Name', 'trim|required|min_length[2]');
			$this->form_validation->set_rules('brand_desc', 'Brand Description', 'trim|required|min_length[2]');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			
			if ($this->form_validation->run()) {				
				
				$data=array('brand_name'=>$post['brand_name']
								,'brand_desc'=>$post['brand_desc']
								,'status' => $post['status']
						);
					$ret = $this->storeproduct_model->updateData(BRAND_TABLE, $data, $where);

				if ($ret > 0) {
					$flash_arr = array('flash_type' => 'success',
										'flash_msg' => 'Brand updated successfully.'
									);
				}else{
					$flash_arr = array('flash_type' => 'error',
										'flash_msg' => 'An error occurred while processing.'
									);
				}
				$this->session->set_userdata('msg_session',$flash_arr);
				redirect("storeproduct");
				}
			$this->session->set_userdata('msg_session',$flash_arr);
			}
		
		$data['storeproduct'] = $storeproduct = $this->storeproduct_model->selectData(BRAND_TABLE, '*', $where);
		
		if (empty($storeproduct)) {
			redirect('storeproduct/index');
		}
		$data['flash_msg'] = $this->msg_session;
		$data['view'] = "add_edit";
		$data['current_view'] = "edit";
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');		
	}

	public function delete() {
		$post = $this->input->post();
		$data=array("status"=>"Inactive");

		if ($post) {
			$ret = $this->storeproduct_model->updateData(BRAND_TABLE, $data,array('Id' => $post['id'] ));
			//$ret = $this->storeproduct_model->deleteData(ADMIN_MASTER, array('Id' => $post['id'] ));
			if ($ret > 0) {
				echo "success";
				exit;
				#echo success_msg_box('User deleted successfully.');;
			}else{
				echo "error";
				exit;
				#echo error_msg_box('An error occurred while processing.');
			}
		}
	}
}
