<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require ("common/Index_Controller.php");
class Index extends Index_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('adminmaster_model');
	}

	public function index()
	{
		
		$session = $this->session->userdata('user_session');
		#pr($session,1);
		if (isset($session['id'])) {
			//echo admin_path();exit;
			redirect(base_path()."dashboard");
		}

		$data = array();
		$post = $this->input->post();
		if ($post) {


			$error = array();
			$e_flag=0;
			if(trim($post['userid']) == ''){
				$error['userid'] = 'Please enter userid.';
				$e_flag=1;
			}
			if(trim($post['password']) == ''){
				$error['password'] = 'Please enter password.';
				$e_flag=1;
			}

			if ($e_flag == 0) {
				$where = array('username' => $post['userid'],
								'password' => sha1($post['password']),
								'status' => 'active'
							 );
							# pr($where,1);
				$user = $this->adminmaster_model->selectData(EMPLOYEE, '*', $where);
				
				if (count($user) > 0) {					
					# create session

					$data = array('id' => $user[0]->id,
									'username' => $user[0]->username,
									'contact' => $user[0]->contact_number,
									'email' => $user[0]->email,
									'role' => $user[0]->sts_role_id,
									'create_date'=>$user[0]->create_date

					);
					$this->session->set_userdata('user_session',$data);

					
					if($post['remember_me'] == 'on'){

						$year = time() + 31536000;
						setcookie('remember_me_u', $post['userid'], $year);
						setcookie('remember_me_pass', $post['password'], $year);
					}
					redirect('dashboard');	
				}else{
					$error['invalid_login'] = "Invalid userid or password";
				}
			}

			$data['error_msg'] = $error;


		}

		$this->load->view('index/index', $data);
	}






	public function logout()
	{
		$this->session->sess_destroy();
		redirect(index_path());
	}



	public function forgotpassword()
	{
		$data = '';
		$post = $this->input->post();
		if ($post) {
			$error = array();
			$e_flag=0;
			if(!valid_email(trim($post['email'])) && trim($post['email']) == ''){
				$error['email'] = 'Please enter email.';
				$e_flag=1;
			}

			if ($e_flag == 0) {
				$where = array('email' => trim($post['email']));
				$user = $this->adminmaster_model->selectData(EMPLOYEE, '*', $where);
				if (count($user) > 0) {

					$newpassword = random_string('alnum', 8);
					$data = array('password' => sha1($newpassword));
					$userUpdate = $this->adminmaster_model->updateData(EMPLOYEE,$data,$where);

					$login_details = array('username' => $user[0]->username,'password' => $newpassword);
					$emailTpl = $this->get_forgotpassword_tpl($login_details);
					$ret = sendEmail($user[0]->email, SUBJECT_LOGIN_INFO, $emailTpl);
					if ($ret) {
						$flash_arr = array('flash_type' => 'success',
										'flash_msg' => 'Login details sent successfully.'
									);
					}else{
						$flash_arr = array('flash_type' => 'error',
										'flash_msg' => 'An error occurred while processing.'
									);
					}
					$data['flash_msg'] = $flash_arr;
				}else{
					$error['email'] = "Invalid email address.";
				}
			}
			$data['error_msg'] = $error;
		}
		$this->load->view('index/forgotpassword', $data);
	}


	public function get_forgotpassword_tpl($details)
	{
		$html = '<p>Your login details are: </p>
				<p>
					Username: '.$details['username'].'<br/>
					Password: '.$details['password'].'
				</p>
				<p>
					Thank you
				</p>
				';

		return $html;
	}
}
