<section class="content-header">
    <h1>
        
        <small>
            <?=($this->router->fetch_method() == 'add')?'Add Brand':'Edit Brand'?>            
        </small>
    </h1>
    <?php
		$this->load->view("/template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">
    	<div class="col-md-6">
    		<div class="box-body">
                 <div id="flash_msg"></div>
                 <?php echo form_open('',array('name'=>"storeFrm",'id'=>"storeFrm")); ?>
                    <div class="form-group">
                        <?php echo form_error('brand_name'); ?>    
                        <?php echo form_label('Brand Name:');?>
                        <?php echo form_input(array('id' => 'brand_name', 'name' => 'brand_name' , 'class'=>'form-control', 'placeholder'=>'Enter Brand Name...','value'=>@$brand[0]->brand_name)); ?>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('brand_desc'); ?>    
                        <?php echo form_label('Contact Person:');?>
                        <textarea name="brand_desc" id="brand_desc" class="form-control" placeholder="Enter Berand Details..."><?php echo @$brand[0]->brand_desc;?></textarea>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('status'); ?>    
                        <?php echo form_label('Status :');?>
                        <select class="form-control" name="status" id="status">
                            <option value="">Select</option>
                            <option value="Active" <?=(@$brand[0]->status == 'Active')?'selected':''?> >Active</option>
                            <option value="Inactive" <?=(@$brand[0]->status == 'Inactive')?'selected':''?> >Inactive</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary btn-flat" type="submit" >Submit</button>
                        <a href="<?=base_url()?>brand/" class="btn btn-defauly btn-flat">Cancel</a>
                    </div>    
				<?php echo form_close(); ?>
             </div>
    	</div>
    </div>
</section>    	