var oTable;
$(document).ready(function() {

	oTable = $('#adminTable').dataTable( {
		"processing": true,
		"serverSide": true,
		"ajax": {
			"url": base_path()+'adminmaster/ajax_list/',
			"type": "POST"
		},
		aoColumnDefs: [
		  {
			 bSortable: false,
			 aTargets: [ -1 ]
		  }
		]
	} );

	
	$('#adminFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		 fields: {
            fname: {
                 message: 'The firstname is not valid',
                validators: {
                    notEmpty: {
                        message: 'The firstname is required and cannot be empty'
                    },
                    stringLength: {
                        min: 2,
                        max: 30,
                        message: 'The firstname must be more than 2 and less than 30 characters long'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The firstname can only consist of alphabetical'
                    // }
                }
            },
            lname: {
                 message: 'The lastname is not valid',
                validators: {
                    notEmpty: {
                        message: 'The lastname is required and cannot be empty'
                    },
                    stringLength: {
                        min: 2,
                        max: 30,
                        message: 'The lastname must be more than 2 and less than 30 characters long'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The lastname can only consist of alphabetical'
                    // }
                }
            },
                       
            contact_number: {
                message: 'The mobile no is not valid',
                validators: {
                    notEmpty: {
                        message: 'The mobile no is required and cannot be empty'
                    },
                    stringLength: {
                        min: 10,
                        max: 10,
                        message: 'The mobile no must be 10 digits'
                    },
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The mobile no can only number'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: 'The Email address is required and cannot be empty'
                    },
                     emailAddress: {
                        message: 'The input is not a valid email address'
                    }
                }
            },
            username: {
                 message: 'The username is not valid',
                validators: {
                    notEmpty: {
                        message: 'The username is required and cannot be empty'
                    },
                    stringLength: {
                        min: 3,
                        max: 30,
                        message: 'The username must be more than 3 and less than 30 characters long'
                    },
                    regexp: {
                        regexp: /^[a-zA-Z0-9_\.]+$/,
                        message: 'The username can only consist of alphabetical, number, dot and underscore'
                    }
                }
            },			
			role: {
                message: 'The role is not valid',
                validators: {
                    notEmpty: {
                        message: 'The role is required and cannot be empty'
                    }
                }
            },
            status: {
                message: 'The status is not valid',
                validators: {
                    notEmpty: {
                        message: 'The status is required and cannot be empty'
                    }
                }
            },            
			 password: {
                validators: {
                    notEmpty: {
                        message: 'The password is required and cannot be empty'
                    },
                    identical: {
                        field: 're_password',
                        message: 'The password and its confirm are not the same'
                    },
                    different: {
                        field: 'username',
                        message: 'The password cannot be the same as username'
                    }
                }
            },
            re_password: {
                validators: {
                    notEmpty: {
                        message: 'The confirm password is required and cannot be empty'
                    },
                    identical: {
                        field: 'password',
                        message: 'The password and its confirm are not the same'
                    },
                    different: {
                        field: 'username',
                        message: 'The password cannot be the same as username'
                    }
                }
            }
		 }
    });
} );

function delete_admin (del_id) {
bootbox.confirm("Are you sure to delete user?", function(result) {
	if(result){
	startLoading();
	$.ajax({
		type: 'post',
		url: base_path()+'adminmaster/delete',
		data: 'id='+del_id,
		success: function (data) {
			if (data == "success") {
				oTable.fnClearTable(0);
				oTable.fnDraw();
				$("#flash_msg").html(success_msg_box ('Admin deleted successfully.'));
			}else{
				$("#flash_msg").html(error_msg_box ('An error occurred while processing.'));
			}
			stopLoading();
		}
	});
	}
	});
}