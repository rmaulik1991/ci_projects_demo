var oTable;
$(document).ready(function() {

	
	
	$('#categoryFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		 fields: {
            sub_category_name: {
                 message: 'The Sub Category Name is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Sub Category Name is required and cannot be empty'
                    }//,
                    // stringLength: {
                    //     min: 2,
                    //     max: 30,
                    //     message: 'The Sub Category Name must be more than 2 and less than 30 characters long'
                    // }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The firstname can only consist of alphabetical'
                    // }
                }
            },
            status: {
                message: 'The status is not valid',
                validators: {
                    notEmpty: {
                        message: 'The status is required and cannot be empty'
                    }
                }
            }
		 }
    });
} );

// function edit_category(edit_id) {
// bootbox.confirm("Are you sure to delete category?", function(result) {
//     if(result){
//     startLoading();
//     $.ajax({
//         type: 'post',
//         url: base_path()+'category/delete',
//         data: 'id='+del_id,
//         success: function (data) {
//             if (data == "success") {
//                 oTable.fnClearTable(0);
//                 oTable.fnDraw();
//                 $("#flash_msg").html(success_msg_box ('Category deleted successfully.'));
//             }else{
//                 $("#flash_msg").html(error_msg_box ('An error occurred while processing.'));
//             }
//             stopLoading();
//         }
//     });
//     }
//     });
// }


function delete_category(del_id) {
bootbox.confirm("Are you sure to delete category?", function(result) {
	if(result){
	startLoading();
	$.ajax({
		type: 'post',
		url: base_path()+'category/delete',
		data: 'id='+del_id,
		success: function (data) {
			if (data == "success") {
				oTable.fnClearTable(0);
				oTable.fnDraw();
				$("#flash_msg").html(success_msg_box ('Category deleted successfully.'));
			}else{
				$("#flash_msg").html(error_msg_box ('An error occurred while processing.'));
			}
			stopLoading();
		}
	});
	}
	});
}