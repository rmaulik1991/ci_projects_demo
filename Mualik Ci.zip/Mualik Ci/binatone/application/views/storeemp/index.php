<section class="content-header">
    <h1>
        <?= translate('STORE_EMP_TITLE') ?>
    </h1>
    <?php
		$this->load->view("template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">
    	<div class="col-md-12">
    	<div id="flash_msg">
			</div>
			<?php //if(accessControl('users','add',$this->user_session['role'])){ ?>
    		
			<?php //} ?>
            <div id="list">
				<div class="box">
					<div class="box-header">
						<h3 class="box-title"><?= translate('STORE_EMP_TITLE') ?></h3>                                    
					</div><!-- /.box-header -->
					<div class="box-body table-responsive">
						<table id="storebranchTable" class="table table-bordered table-striped">
							<thead>
								<tr>
                                    <th>Employee name</th>
                                    <th>Branch name</th>                                  
                                    <th>Store name</th>									
									<th>Action</th>
								</tr>
							</thead>
						</table>
					</div><!-- /.box-body -->
				</div><!-- /.box -->
			</div>
    	</div>
    </div>
   <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
        <form action="<?php echo base_path()?>storeemp/assign_emp" method="post" id="storeFrm">
         <div class="row">
                <div class="col-md-3" style="text-align: right;"><?php echo form_label('Store Name:');?></div>
                    <div class="col-md-6">
            <div class="form-group">
                        <select class="form-control" name="store_name" id="store_name" onchange="get_branch();">
                            <option value="">Select</option>
                            <?php foreach($store_list as $row){ ?>
                            <option value="<?php echo $row->id; ?>"><?php echo $row->store_name; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3" style="text-align: right;"><?php echo form_label('Branch Name:');?></div>
                    <div class="col-md-6">
            <div class="form-group">
                        <select class="form-control" name="branch_name" id="branch_name">
                            <option value="">Select</option>
                        </select>
                    </div>
                </div>
            </div>
            <input type="hidden" name="emp_id" id="emp_id">
            <div class="row"><div class="col-md-12"><div class="col-md-4"></div>
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <input type="submit" class="btn btn-info" value="Save">
            </div></div>
          </form>
        </div>
        
      
    </div>
  </div>
</section>
