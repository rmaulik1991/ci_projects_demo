<section class="content-header">
    <h1>
        <?= translate('COM_PRODUCT_TITLE') ?>
    </h1>
    <?php
		$this->load->view("template/bread_crumb");
	?>
</section>
			
<section class="content">
	<div class="row">
    	<div class="col-md-12">
    		<div class="row">
    			
			    <div class="col-md-3">
			         <div class="form-group">
                        <?php echo form_label('Branch Name:');?>
                        <select class="form-control" name="branch_id" id="branch_id">
                            <option value="">Select</option>
                            <?php foreach($branch_list as $row){ ?>
                            <option value="<?php echo $row->id; ?>"><?php echo $row->branch_name; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                     <div class="form-group">
                        <?php echo form_label('Product Name:');?>
                        <select class="form-control" name="product" id="product">
                            <option value="">Select</option>
                            
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                     <div class="form-group">
                    <label>Select Date :</label>
                    <div class="input-group">
                        <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
                        <input type="text" class="form-control pull-right" id="daterange" name="daterange">
                    </div></div>
                </div>
                <div class="col-md-3" style="margin-top: 25px;">
                     <div class="form-group">
                        <button class="btn btn-primary btn-flat" id="filter_data"><i class="fa fa-filter"></i> Filter</button>
                    </div>
                </div>
            </div>
    		<div id="flash_msg">
			</div>
			<div id="list">
				<div class="box">
					<div class="box-header">
						<h3 class="box-title"><?= translate('COM_PRODUCT_TITLE') ?></h3>                                    
					</div><!-- /.box-header -->
					<div class="box-body table-responsive">
						<table id="attTable" class="table table-bordered table-striped">
							<thead>
								<tr>                                   
                                    <th>Employee Name</th>
                                    <th>Product Name</th>									
                                    <th>Branch Name</th>  
                                    <th>Is own product</th>
									<th>Date</th>
									<th>Action</th>
								</tr>
							</thead>
						</table>
					</div><!-- /.box-body -->
				</div><!-- /.box -->
			</div>
    	</div>
    </div>
</section>
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-6" id="img"></div>
            <div class="col-md-6" id="desc"></div>
        </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<script type="text/javascript">
	$(document).ready(function() {
		oTable = $('#attTable').dataTable();
	$( "#filter_data" ).click(function() {
    var branch_id = $('#branch_id').val();
    var product = $('#product').val();
    var daterange = $('#daterange').val();
    $('#attTable').DataTable().destroy();
    oTable = $('#attTable').dataTable( {
        "processing": true,
        "serverSide": true,
        "ajax": {
            data: {branch_id:branch_id,product:product,daterange:daterange},
            "url": base_path()+'comproduct/ajax_list/',
            "type": "POST"
        },
        aoColumnDefs: [
          {
             bSortable: false,
             aTargets: [ -1 ]
          }
        ]
    } );
    } );
    } );

   $( "#branch_id" ).change(function() {
    var branch_id = $('#branch_id').val();
    $('#product')
    .find('option')
    .remove()
    .end()
    .append('<option value="">Select</option>');
    $.ajax({
        type: 'post',
        url: base_path()+'comproduct/get_product/'+branch_id,
        success: function (data) {
            if(data['product_list']!=''){
            var i=0;
             $.each(data['product_list'], function(id, category_name) {
                $('#product').append("<option value='" +data['product_list'][i]['id'] + "'>" + data['product_list'][i]['product_name'] + "</option>");
                i++;
            });
         }
        }
    });
    });
   $(function() {
    $('input[name="daterange"]').daterangepicker({
        timePicker: false,
        timePickerIncrement: 30,
        locale: {
            format: 'DD/MM/YYYY'
        }
    });
});

   function view_data(id){
    $('#img').html('');
    $('#desc').html('');
    var url="<?php echo base_url(); ?>";
    $.ajax({
        type: 'post',
        url: base_path()+'comproduct/view_data/'+id,
        success: function (data) {
            console.log(data['view_data'][0]['image']);
            $('#img').append("<img src='"+url+"public/uploads/display_product/"+data['view_data'][0]['image']+"' width='200px' height='200px'>");
            $('#desc').append("<p>"+data['view_data'][0]['product_detail']+"</p>");
        }
    });
   }
</script>