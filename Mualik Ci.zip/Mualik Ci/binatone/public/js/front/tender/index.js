var oTable;
$(document).ready(function()
{
    //Goverment Tender Listing
    oTable = $('#govermentTable').dataTable( {
        "processing": false,
        "serverSide": true,
        "ajax": {
            "url": base_path()+'tender/ajax_list_goverment/',
            "type": "POST"
        },
        aoColumnDefs: [
          {
             bSortable: false,
             aTargets: [ -1 ]             
          }
        ]
    } );    

    //Tender First Page Validation
    $('#tenderFrm').bootstrapValidator({
            message: 'This value is not valid',
            feedbackIcons: {
                valid: '',
                invalid: '',
                validating: ''
            },
         fields: {

            'contract[]': {
                 message: 'The tender type is not valid',
                validators: {
                    notEmpty: {
                        message: 'The tender type is required'
                    }
                }
            }
            ,'service[]': {
                 message: 'The Service is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Service is required'
                    }
                }
            }
         }
    });

    //Tender Details Form Validation
	$('#tenderDetailsFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		 fields: {

            companyname: {
                 message: 'The companyname is not valid',
                validators: {
                    notEmpty: {
                        message: 'The companyname is required and cannot be empty'
                    },                    
                    regexp: {
                        regexp: /^[a-zA-Z\s]+$/,
                        message: 'The companyname can only consist of alphabetical'
                    }
                }
            }
            ,headoffice: {
                message: 'The head office is not valid',
                validators: {
                    notEmpty: {
                        message: 'The head office is required and cannot be empty'
                    }
                }
            }
            ,work_location_city: {
                 message: 'The city is not valid',
                validators: {                    
                    stringLength: {
                        min: 2,
                        max: 20,
                        message: 'The city must be more than 2 and less than 20 characters long'
                    },
                    regexp: {
                        regexp: /^[a-zA-Z\s]+$/,
                        message: 'The city can only consist of alphabetical'
                    }
                }
            }
            ,work_location_state: {
                 message: 'The state is not valid',
                validators: {                    
                    stringLength: {
                        min: 2,
                        max: 20,
                        message: 'The state must be more than 2 and less than 20 characters long'
                    },
                    regexp: {
                        regexp: /^[a-zA-Z\s]+$/,
                        message: 'The state can only consist of alphabetical'
                    }
                }
            }
            ,work_location_pincode: {
                 message: 'The pincode is not valid',
                validators: {
                    stringLength: {
                        min: 6,
                        max: 6,
                        message: 'The pincode no must be 6 digits'
                    },
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The pincode can only consist of number'
                    }
                }
            }
            ,tender_no: {
                 message: 'The tender no is not valid',
                validators: {
                    notEmpty: {
                        message: 'The tender no is required and cannot be empty'
                    }
                }
            }            
            ,tender_contact_person: {
                 message: 'The person name is not valid',
                validators: {
                    stringLength: {
                        min: 2,
                        max: 30,
                        message: 'The person name must be more than 2 and less than 30 characters long'
                    }                    
                }
            }
            ,tender_office_number: {
                message: 'The office no is not valid',
                validators: {
                    stringLength: {
                        min: 10,
                        max: 13,
                        message: 'The office no must be 10 and less than 13 digits long'
                    }                    
                }
            }
            ,tender_mobile_number: {
                message: 'The mobile no is not valid',
                validators: {
                    stringLength: {
                        min: 10,
                        max: 13,
                        message: 'The mobile no must be 10 and less than 13 digits long'
                    }                    
                }
            }
            ,tender_email: {
                validators: {
                    emailAddress: {
                        message: 'The value is not a valid email address'
                    }
                }
            }
		 }
    });

    //Tender Details Form Validation
    $('#tenderDetailsFrm1').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
         fields: {            
            
            // 'labour_compliances[]': {
            //     message: 'The Labour Compliances is not valid',
            //     validators: {
            //         notEmpty: {
            //             message: 'The Labour Compliances is required and cannot be empty'
            //         }
            //     }
            // },
            'pre_bid_meeting[]': {
                message: 'The pre bid meeting field is not valid',
                validators: {
                    notEmpty: {
                        message: 'The pre bid meeting field is required and cannot be empty'
                    }
                }
            }, 
            pre_bid_meeting_date: {
                 message: 'The date is not valid',
                validators: {
                    notEmpty: {
                        message: 'The date is required'
                    },
                    date: {
                            format: 'DD-MM-YYYY HH:mm',
                            message: 'The date is not valid'
                        }
                }
            }  
            ,pre_bid_meeting_place: {
                message: 'The meeting place is not valid',
                validators: {                    
                    notEmpty: {
                        message: 'The meeting place is required'
                    }
                }
            }  
            ,tender_closing_date_online: {
                 message: 'The date is not valid',
                validators: {
                    notEmpty: {
                        message: 'The date is required'
                    },
                    date: {
                            format: 'DD-MM-YYYY HH:mm',
                            message: 'The date is not valid'
                        }
                }
            } 
            ,tender_closing_date_ofline: {
                 message: 'The date is not valid',
                validators: {
                    notEmpty: {
                        message: 'The date is required'
                    },
                    date: {
                            format: 'DD-MM-YYYY HH:mm',
                            message: 'The date is not valid'
                        }
                }
            } 
            ,technical_bid_opening_date: {
                 message: 'The date is not valid',
                validators: {
                    date: {
                            format: 'DD-MM-YYYY HH:mm',
                            message: 'The date is not valid'
                        }
                }
            } 
            ,financial_bid_opening_date: {
                 message: 'The date is not valid',
                validators: {
                    date: {
                            format: 'DD-MM-YYYY HH:mm',
                            message: 'The date is not valid'
                        }
                }
            }                      
            ,security_deposit: {
                message: 'The security deposit is not valid',
                validators: {                    
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The security deposit can only consist of number'
                    }
                }
            }
            ,tender_fee: {
                message: 'The tender fee is not valid',
                validators: {                    
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The tender fee can only consist of number'
                    }
                }
            }
            ,material_list_give: {
                 message: 'The material list is not valid',
                validators: {
                    notEmpty: {
                        message: 'The material list is required'
                    }
                }
            }
            ,material_qty_give: {
                 message: 'The material quantity is not valid',
                validators: {
                    notEmpty: {
                        message: 'The material quantity is required'
                    }
                }
            }
            ,machinery_list_give: {
                 message: 'The machinery list is not valid',
                validators: {
                    notEmpty: {
                        message: 'The machinery list is required'
                    }
                }
            }
            ,machinery_qty_give: {
                 message: 'The machinery quantity is not valid',
                validators: {
                    notEmpty: {
                        message: 'The machinery quantity is required'
                    }
                }
            }
            ,working_no_of_day: {
                message: 'The day is not valid',
                validators: {                    
                    notEmpty: {
                        message: 'The day is required'
                    }
                }
            }
            ,no_of_man_power_req: {
                message: 'The no of manpower req. is not valid',
                validators: {                    
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The no of manpower req. can only consist of number'
                    }
                }
            }
            ,condition_rem: {
                message: 'The condition remarks is not valid',
                validators: {                    
                    notEmpty: {
                        message: 'The condition remarks is required'
                    }
                }
            }
            ,'site_visit_required[]': {
                 message: 'The site visit is not valid',
                validators: {
                    notEmpty: {
                        message: 'The site visit is required'
                    }
                }
            }
         }
    });

    //Tender Site Visit Form Validation
    $('#tenderSitevisitFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
         fields: {                                  
            tender_contact_number: {
                message: 'The mobile no is not valid',
                validators: {
                    stringLength: {
                        min: 10,
                        max: 13,
                        message: 'The mobile no must be 10 and less than 13 digits long'
                    }                    
                }
            }            
            ,present_manepower: {
                message: 'The Present Manepower is not valid',
                validators: {
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The Present Manepower can only consist of number'
                    }                   
                }
            }            
            ,'site_visit[]': {
                message: 'The mobile no is not valid',
                validators: {
                    notEmpty: {
                        message: 'The site visit is required'
                    }                  
                }
            }
         }
    });

    // Tender Login Form Validation
    $('#tenderLoginFrm').bootstrapValidator({
            message: 'This value is not valid',
            feedbackIcons: {
                valid: '',
                invalid: '',
                validating: ''
            },
         fields: {
            'tender_login[]': {
                 message: 'The Tender Login is not valid',
                validators: {
                   notEmpty: {
                        message: 'The Tender Login is required'
                    }
                }
            }            
            ,tender_doc: {
                 message: 'The selected file is not valid',
                validators: {                    
                    file: {
                        extension: 'gif,jpg,png,jpeg,pdf,doc',
                        type: '',                        
                        message: 'The selected file is not valid'
                    }
                }
            }
            ,Technical_bid_docs: {
                 message: 'The selected file is not valid',
                validators: {                    
                    file: {
                        extension: 'gif,jpg,png,jpeg,pdf,doc',
                        type: '',                        
                        message: 'The selected file is not valid'
                    }
                }
            }            
            ,tender_login_date: {
                 message: 'The date is not valid',
                validators: {
                    date: {
                            format: 'DD-MM-YYYY',
                            message: 'The date is not valid'
                        }
                }
            }
            ,form_fee_date: {
                 message: 'The date is not valid',
                validators: {
                    date: {
                            format: 'DD-MM-YYYY',
                            message: 'The date is not valid'
                        }
                }
            }
            ,emd_fee_date: {
                 message: 'The date is not valid',
                validators: {
                    date: {
                            format: 'DD-MM-YYYY',
                            message: 'The date is not valid'
                        }
                }
            }
            ,disqualified_reason: {
                 message: 'The Service is not valid',
                validators: {
                    notEmpty: {
                        message: 'The site visit is required'
                    } 
                }
            }
         }
    });

    //Tender Result Form validation
    $('#tenderResultFrm').bootstrapValidator({
            message: 'This value is not valid',
            feedbackIcons: {
                valid: '',
                invalid: '',
                validating: ''
            },
         fields: {

            total_bidders: {
                 message: 'The Total No of Bidders is not valid',
                validators: {
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The Total No of Bidders can only consist of number'
                    } 
                }
            }
            // ,safal_rate: {
            //      message: 'The Safal Rate is not valid',
            //     validators: {
            //         regexp: {
            //             regexp: /^[0-9]+$/,
            //             message: 'The Safal Rate can only consist of number'
            //         } 
            //     }
            // }
            // ,'bidder_name[]': {
            //      message: 'The Bidder Name is not valid',
            //     validators: {
            //         regexp: {
            //             regexp: /^[a-zA-Z\s]+$/,
            //             message: 'The Bidder Name can only consist of alphabetical'
            //         }  
            //     }
            // }
            // ,'rate[]': {
            //      message: 'The Rate is not valid',
            //     validators: {
            //         regexp: {
            //             regexp: /^[0-9]+$/,
            //             message: 'The Rate can only consist of number'
            //         } 
            //     }
            // }
         }
    });  

    //Tender Awarded Form Validation
    $('#tenderAwardedDataFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
         fields: { 
            attached_work_order: {
                 message: 'The selected file is not valid',
                validators: {                    
                    file: {
                        extension: 'gif,jpg,png,jpeg,pdf,doc',
                        type: '',                        
                        message: 'The selected file is not valid'
                    }
                }
            }            
            ,'letters_of_communications[]': {
                 message: 'The selected file is not valid',
                validators: {                    
                    file: {
                        extension: 'gif,jpg,png,jpeg,pdf,doc',
                        type: '',                        
                        message: 'The selected file is not valid'
                    }
                }
            }                                                     
            ,contract_duration_start_date: {
                 message: 'The date is not valid',
                validators: {
                    date: {
                            format: 'DD-MM-YYYY',
                            message: 'The date is not valid'
                        }
                }
            }
            ,contract_duration_end_date: {
                 message: 'The date is not valid',
                validators: {
                    date: {
                            format: 'DD-MM-YYYY',
                            message: 'The date is not valid'
                        }
                }
            }
            ,type_security_deposit: {
                 message: 'The Type of Security Deposit is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Type of Security Deposit is required'
                    }
                }
            }
            ,sd_amount: {
                 message: 'The SD amount is not valid',
                validators: {
                    notEmpty: {
                        message: 'The SD amount is required'
                    }
                }
            }
            ,sd_date: {
                 message: 'The date is not valid',
                validators: {
                    notEmpty: {
                        message: 'The date is required'
                    }
                    ,date: {
                            format: 'DD-MM-YYYY',
                            message: 'The date is not valid'
                        }
                }
            }
			,sd_return_date: {
                 message: 'The date is not valid',
                validators: {
                    notEmpty: {
                        message: 'The date is required'
                    }
                    ,date: {
                            format: 'DD-MM-YYYY',
                            message: 'The date is not valid'
                        }
                }
            }
            ,sd_bank_name: {
                 message: 'The SD bank name is not valid',
                validators: {
                    notEmpty: {
                        message: 'The SD bank name is required'
                    }
                }
            }
            ,sd_instrument_no: {
                 message: 'The instrument no is not valid',
                validators: {
                    notEmpty: {
                        message: 'The instrument no is required'
                    }
                }
            }
            ,sd_favour: {
                 message: 'The sd favour is not valid',
                validators: {
                    notEmpty: {
                        message: 'The sd favour is required'
                    }
                }
            }
            ,sd_start_date: {
                 message: 'The date is not valid',
                validators: {
                    notEmpty: {
                        message: 'The date is required'
                    }
                    ,date: {
                            format: 'DD-MM-YYYY',
                            message: 'The date is not valid'
                        }
                }
            }
            ,sd_end_date: {
                 message: 'The date is not valid',
                validators: {
                    notEmpty: {
                        message: 'The date is required'
                    }
                    ,date: {
                            format: 'DD-MM-YYYY',
                            message: 'The date is not valid'
                        }
                }
            }
            ,sd_retention_amount: {
                 message: 'The amount is not valid',
                validators: {
                    notEmpty: {
                        message: 'The amount is required'
                    }                    
                }
            } 
            ,wc_policy_end_date: {
                 message: 'The date is not valid',
                validators: {
                    notEmpty: {
                        message: 'The date is required'
                    }
                    ,date: {
                            format: 'DD-MM-YYYY',
                            message: 'The date is not valid'
                        }
                }
            }
            ,wc_policy_start_date: {
                 message: 'The date is not valid',
                validators: {
                    notEmpty: {
                        message: 'The date is required'
                    }
                    ,date: {
                            format: 'DD-MM-YYYY',
                            message: 'The date is not valid'
                        }
                }
            }                        
            ,total_persons_wc_policy: {
                 message: 'The person is not valid',
                validators: {
                    notEmpty: {
                        message: 'The total persons is required'
                    }
                    ,regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The person can only consist of number'
                    }
                }
            }
            ,wc_upload_file: {
                 message: 'The selected file is not valid',
                validators: {                    
                    // notEmpty: {
                    //     message: 'The WC policy attachment is required'
                    // }, 
                    file: {
                        extension: 'gif,jpg,png,jpeg,pdf,doc',
                        type: '',                        
                        message: 'The selected file is not valid'
                    }
                }
            }
            ,ll_start_date: {
                 message: 'The date is not valid',
                validators: {
                    notEmpty: {
                        message: 'The date is required'
                    }
                    ,date: {
                            format: 'DD-MM-YYYY',
                            message: 'The date is not valid'
                        }
                }
            }   
            ,ll_end_date: {
                 message: 'The date is not valid',
                validators: {
                    notEmpty: {
                        message: 'The date is required'
                    }
                    ,date: {
                            format: 'DD-MM-YYYY',
                            message: 'The date is not valid'
                        }
                }
            }
            ,ll_total_persons: {
                 message: 'The person is not valid',
                validators: {
                    notEmpty: {
                        message: 'The total persons is required'
                    }
                    ,regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The person can only consist of number'
                    }
                }
            }   
            ,ll_upload_file: {
                 message: 'The selected file is not valid',
                validators: { 
                    // notEmpty: {
                    //     message: 'The ll policy attachment is required'
                    // },                   
                    file: {
                        extension: 'gif,jpg,png,jpeg,pdf,doc',
                        type: '',                        
                        message: 'The selected file is not valid'
                    }
                }
            }            
         }
    });

    //Tender Contract Extented Form Validation
    $('#tenderContractExtendFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
         fields: {                                              
            'contract_extented[]': {
                message: 'The contract extended is not valid',
                validators: {
                    notEmpty: {
                        message: 'The contract extended is required'
                    }                  
                }
            }            
         }
    });


} );

//Done Contract
$(document).on('click','.contract_complited',function(e)
{
    var id = $(this).attr('id');    
    
    bootbox.confirm("Are you sure to complite contract ?", function(result)
    {        
        if(result)
        {
            startLoading(); 
            $.ajax(
            {           
                type: "POST",
                url: base_path()+'tender/complitecontract',  
                data:{id:id},          
                success: function (res) 
                {
                    var result = $.parseJSON(res);              
                    if(result.code == '100') 
                    {                                                                        
                        stopLoading();
                        $('#govermentTable').DataTable().ajax.reload();
                        $('#flash_msg').html(success_msg_box(result.message));
                    }
                    else
                    {
                        $('#flash_msg').html(success_msg_box(result.message));
                    }
                }
            });
        }
    });
});

//Allow Only Numeric Value
function isNumberKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

//Compare Two Difference Date
function dateCompare(seq,sdname,edname)
{   
    var sd=$(sdname).val();
    var ed=$(edname).val();                 
    if(seq == 1)
    {
        if(sd > ed)
        {
            //$(edname).val(sd);                                  
            $(edname).focus();
        }                                           
    }
    if(seq == 2)
    {
        if(sd > ed)
        {
            //$(sdname).val(ed);            
            $(sdname).focus();
        }                                       
    }           
}
