<section class="content-header">
    <h1>
        
        <small>
            <?=($this->router->fetch_method() == 'add')?'Add Employee':'Edit Employee'?>            
        </small>
    </h1>
    <?php
		$this->load->view("/template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">
    	<div class="col-md-6">
    		<div class="box-body">
                 <div id="flash_msg"></div>
                 <?php echo form_open('',array('name'=>"adminFrm",'id'=>"adminFrm")); ?>
                    <div class="form-group">
                        <?php echo form_error('fname'); ?>    
                        <?php echo form_label('First Name:');?>
                        <?php echo form_input(array('id' => 'fname', 'name' => 'fname' , 'class'=>'form-control', 'placeholder'=>'Enter First Name...','value'=>@$user[0]->first_name)); ?>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('lname'); ?>    
                        <?php echo form_label('Last Name:');?>
                        <?php echo form_input(array('id' => 'lname', 'name' => 'lname' , 'class'=>'form-control', 'placeholder'=>'Enter Last Name...','value'=>@$user[0]->last_name)); ?>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('role'); ?>    
                        <?php echo form_label('Role :');?>
                        <select class="form-control" name="role" id="role">
                            <option value="">Select</option>
                            <?php foreach ($role_list as $row) { ?>
                            <option value="<?php echo $row->role_id; ?>" <?=(@$user[0]->sts_role_id == $row->role_id)?'selected':''?> ><?php echo $row->role_name; ?></option>    
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('contact_number'); ?>    
                        <?php echo form_label('Mobile Number:');?>
                        <?php echo form_input(array('id' => 'contact_number', 'name' => 'contact_number' , 'class'=>'form-control', 'placeholder'=>'Enter Mobile Number...','value'=>@$user[0]->contact_number)); ?>
                    </div>                   
                    <div class="form-group">
                        <?php echo form_error('email'); ?>    
                        <?php echo form_label('Email address:');?>
                        <?php echo form_input(array('id' => 'email', 'name' => 'email' , 'class'=>'form-control', 'placeholder'=>'Enter Email ...','value'=>@$user[0]->email)); ?>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('address'); ?>    
                        <?php echo form_label('Address:');?>
                        <?php echo form_input(array('id' => 'address', 'name' => 'address' , 'class'=>'form-control', 'placeholder'=>'Enter Address ...','value'=>@$user[0]->address)); ?>
                    </div>
                    
                    <div class="form-group">
                        <?php echo form_error('username'); ?>    
                        <?php echo form_label('User Name:');?>
						<?php echo form_input(array('id' => 'username', 'name' => 'username' , 'class'=>'form-control', 'placeholder'=>'Enter User Name...','value'=>@$user[0]->username)); ?>
                    </div>
                    <div class="form-group">
                        <?php echo form_error('password'); ?>    
                        <?php echo form_label('Password:');?>
                        <?php echo form_input(array('id' => 'password','type'=>'password' ,'name' => 'password' , 'class'=>'form-control', 'placeholder'=>'Password ...')); ?>
                    </div>
                    <div class="form-group">
                    <?php echo form_error('re_password'); ?>    
                        <?php echo form_label('Repeat Password:');?>
                        <?php echo form_input(array('id' => 're_password','type'=>'password' ,'name' => 're_password' , 'class'=>'form-control', 'placeholder'=>'Repeat Password ...')); ?>
                    </div>
                   
                    <div class="form-group">
                        <?php echo form_error('status'); ?>    
                        <?php echo form_label('Status :');?>
                        <select class="form-control" name="status" id="status">
                            <option value="">Select</option>
                            <option value="Active" <?=(@$user[0]->status == 'Active')?'selected':''?> >Active</option>
                            <option value="Inactive" <?=(@$user[0]->status == 'Inactive')?'selected':''?> >Inactive</option>
                           
                        </select>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary btn-flat" type="submit" >Submit</button>
                        <a href="<?=base_url()?>adminmaster/" class="btn btn-defauly btn-flat">Cancel</a>
                    </div>    
				<?php echo form_close(); ?>
             </div>
    	</div>
    </div>
</section>    	