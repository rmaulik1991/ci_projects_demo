var oTable;
$(document).ready(function() {

	oTable = $('#brandTable').dataTable( {
		"processing": true,
		"serverSide": true,
		"ajax": {
			"url": base_path()+'brand/ajax_list/',
			"type": "POST"
		},
		aoColumnDefs: [
		  {
			 bSortable: false,
			 aTargets: [ -1 ]
		  }
		]
	} );

	
	$('#storeFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		 fields: {
            brand_name: {
                 message: 'The Brand Name is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Brand Name is required and cannot be empty'
                    },
                    stringLength: {
                        min: 2,
                        max: 30,
                        message: 'The Brand Name must be more than 2 and less than 30 characters long'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The firstname can only consist of alphabetical'
                    // }
                }
            },
            brand_desc: {
                 message: 'The Brand Description is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Brand Description is required and cannot be empty'
                    },
                    stringLength: {
                        min: 2,
                        max: 200,
                        message: 'The Brand Description must be more than 2 and less than 200 characters long'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The lastname can only consist of alphabetical'
                    // }
                }
            },
            status: {
                message: 'The status is not valid',
                validators: {
                    notEmpty: {
                        message: 'The status is required and cannot be empty'
                    }
                }
            }
		 }
    });
} );

function delete_brand(del_id) {
bootbox.confirm("Are you sure to delete brand?", function(result) {
	if(result){
	startLoading();
	$.ajax({
		type: 'post',
		url: base_path()+'brand/delete',
		data: 'id='+del_id,
		success: function (data) {
			if (data == "success") {
				oTable.fnClearTable(0);
				oTable.fnDraw();
				$("#flash_msg").html(success_msg_box ('Store deleted successfully.'));
			}else{
				$("#flash_msg").html(error_msg_box ('An error occurred while processing.'));
			}
			stopLoading();
		}
	});
	}
	});
}