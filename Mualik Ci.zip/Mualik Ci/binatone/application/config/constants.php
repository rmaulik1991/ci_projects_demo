<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
define('FILE_READ_MODE', 0644);
define('FILE_WRITE_MODE', 0666);
define('DIR_READ_MODE', 0755);
define('DIR_WRITE_MODE', 0777);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/

define('FOPEN_READ',							'rb');
define('FOPEN_READ_WRITE',						'r+b');
define('FOPEN_WRITE_CREATE_DESTRUCTIVE',		'wb'); // truncates existing file data, use with care
define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE',	'w+b'); // truncates existing file data, use with care
define('FOPEN_WRITE_CREATE',					'ab');
define('FOPEN_READ_WRITE_CREATE',				'a+b');
define('FOPEN_WRITE_CREATE_STRICT',				'xb');
define('FOPEN_READ_WRITE_CREATE_STRICT',		'x+b');

/************ Application settings **********/

#custom constants
define('DOC_ROOT_APPLICATION_PATH',  DOC_ROOT."/application/");
define('DOC_ROOT_LANGUAGE_PATH',  DOC_ROOT_APPLICATION_PATH."language/");
define('DOC_ROOT_LOGS_PATH',  DOC_ROOT_APPLICATION_PATH."logs/");
define('SYSTEM_ROOT_PATH',  DOC_ROOT."/system/");
define('DOC_ROOT_PROFILE_IMG',  DOC_ROOT."/public/uploads/profile_images/");
define('DOC_ROOT_PUBLIC_PATH',  DOC_ROOT."/public/");
define('DOC_ROOT_GOVERMENT',  DOC_ROOT."/public/uploads/government/");
define('DOC_ROOT_PRIVATE',  DOC_ROOT."/public/uploads/private/");
define('DOC_ROOT_DP',  DOC_ROOT."/public/uploads/display_product/");


define('ADMIN',	'admin');
define('DEAL_USER',	'user');
define('DEAL_CATEGORY',	'category');
define('PAGES','pages');
define('PRODUCT','product');
define('LANGUAGE','language');
define('ADMIN_MASTER','admin_master');
define('STORE','sts_store');
define('CATEGORY','sts_category');
define('EMPLOYEE','sts_employee');
define('ROLE_MASTER','sts_role_master');
define('STORE_BRANCH_TABLE','sts_store_branch');
define('BRAND_TABLE','sts_brand');
define('PRODUCT_TABLE','sts_product');
define('STORE_PRODUCT_INT','sts_store_product_int');
define('STORE_EMP_INT','sts_store_employee_int');
define('PRODUCT_CATEGORY_TABLE','sts_category');
define('ATTENDENCE_TABLE','sts_employee_attendance');
define('DISPLAY_PRODUCT','sts_display_product');
define('DISPLAY_TRACKER','sts_display_tracker');
define('COM_PRODUCT_TABLE','sts_competitor_product');
define('EMAIL_TEMPLATE','email_template');
define('SERVICE_MASTER','service_master');
define('CUSTOMER_SERVICE','customer_service');
define('NOTIFICATION','notification');
define('SERVICE_NOTIFICATION','service_notification');
define('CUSTOMER_NOTIFICATION','customer_notification');
define('COMPANY_MASTER','company_master');
define('TD_TENDER','td_tender');
define('TD_TENDER_DETAIL','td_tender_detail');
define('TD_TENDER_RESULT','td_tender_result');
define('TD_TENDER_BIDDERS','td_tender_bidders');
define('TD_SITE_VISIT_DATA','td_site_visit_data');
define('TD_TENDER_LOGIN_DATA','td_tender_login_data');
define('TD_TENDER_CONTRACT','td_tender_contract');
define('TD_TENDER_PRIVATE_MATERIAL','td_private_material');
define('TD_TENDER_PRIVATE_MATERIAL_LIST','td_private_material_list');
define('TD_TENDER_AWARDED_DATA','td_tender_awarded_data');
define('TD_TENDER_MANPOWER','td_tender_manpower');
define('UPLOAD_FILES','upload_files');

// Private Table..

define('TD_PRIVATE_TENDER_INQUIRY','td_private_tender_inq');
define('TD_PRIVATE_MANPOWER','td_private_manpower');
define('TD_MACHINARY_MATERIAL_AUDIT','td_machinary_material_audit');
define('TD_PRIVATE_PROPOSAL','td_private_proposal');
define('TD_PRIVATE_FEEDBACK','td_private_feedback');


/******** || SMTP Mail Configuration || **********/
//define('SMTP_HOST', 'ssl://smtp.ipage.com');
//define('SMTP_USERNAME', 'portal@parextech.com');
//define('SMTP_PASSWORD', 'Parextech01');
//define('SMTP_PORT', '465');

//define('FROM_EMAIL', 'noreply@parextech.com');
//define('FROM_NAME', 'Parex Technology');

/* new config for smtp */
define('PROTOCOL','smtp');
define('SMTP_CRYPTO','STARTTLS');
define('SMTP_HOST','smtp.parextech.com');
define('SMTP_PORT', '587');
define('SMTP_USERNAME', 'portal@parextech.com');
define('SMTP_PASSWORD', 'Parextech01');

define('FROM_EMAIL', 'noreply@parextech.com');
define('FROM_NAME', 'Store Sales');

define('REPLY_TO', 'noreply@parextech.com');
define('REPLY_NAME', 'Store Sales');

define('BCC', '');
define('CC', '');
define('REMINDER_EMAIL_ADDRESS','chirag@parextech.com');
define('SUBJECT_LOGIN_INFO','Forgot Password on Store Sales');


global $languages;

$Languages=array('english','spanish');

global $SupportedLanguages;
	$SupportedLanguages = array(
		'af'	=> array('title' => 'Afrikaans', 'flag' => 'Afrikaans.png')
		,'sq'	=> array('title' => 'Albanian', 'flag' => 'Albanian.png')
		,'ar'	=> array('title' => 'Arabic', 'flag' => 'Arabic.png')
		,'be'	=> array('title' => 'Belarusian', 'flag' => 'Belarusian.png')
		,'bg'	=> array('title' => 'Bulgarian', 'flag' => 'Bulgarian.png')
		,'ca'	=> array('title' => 'Catalan', 'flag' => 'Catalan.png')
		,'zh'	=> array('title' => 'Chinese', 'flag' => 'Chinese.png')
		,'zh-CN'	=> array('title' => 'Chinese Simplified', 'flag' => 'Chinese_Simplified.png')
		,'zh-TW'	=> array('title' => 'Chinese Traditional', 'flag' => 'Chinese_Traditional.png')
		,'hr'	=> array('title' => 'Croatian', 'flag' => 'Croatian.png')
		,'cs'	=> array('title' => 'Czech', 'flag' => 'Czech.png')
		,'da'	=> array('title' => 'Danish', 'flag' => 'Danish.png')
		,'nl'	=> array('title' => 'Dutch', 'flag' => 'Dutch.png')
		,'en'	=> array('title' => 'English', 'flag' => 'English.png')
		,'et'	=> array('title' => 'Estonian', 'flag' => 'Estonia.png')
		,'tl'	=> array('title' => 'Filipino', 'flag' => 'Filipino.png')
		,'fi'	=> array('title' => 'Finnish', 'flag' => 'Finnish.png')
		,'fr'	=> array('title' => 'French', 'flag' => 'French.png')
		,'gl'	=> array('title' => 'Galician', 'flag' => 'Galician.png')
		,'de'	=> array('title' => 'German', 'flag' => 'German.png')
		,'el'	=> array('title' => 'Greek', 'flag' => 'Greek.png')
		,'ht'	=> array('title' => 'Haitian Creole', 'flag' => 'Haitian_Creole.png')	// Currently not supported in Zend 1.11.7 check Zend_Locale for supported Languages
		,'iw'	=> array('title' => 'Hebrew', 'flag' => 'Hebrew.png')
		,'hi'	=> array('title' => 'Hindi', 'flag' => 'Hindi.png')
		,'hu'	=> array('title' => 'Hungarian', 'flag' => 'Hungarian.png')
		,'is'	=> array('title' => 'Icelandic', 'flag' => 'Icelandic.png')
		,'id'	=> array('title' => 'Indonesian', 'flag' => 'Indonesian.png')
		,'ga'	=> array('title' => 'Irish', 'flag' => 'Irish.png')
		,'ja'	=> array('title' => 'Japanese', 'flag' => 'Japanese.png')
		,'ko'	=> array('title' => 'Korean', 'flag' => 'Korean.png')
		,'lv'	=> array('title' => 'Latvian', 'flag' => 'Latvian.png')
		,'lt'	=> array('title' => 'Lithuanian', 'flag' => 'Lithuanian.png')
		,'mk'	=> array('title' => 'Macedonian', 'flag' => 'Macedonian.png')
		,'ms'	=> array('title' => 'Malay', 'flag' => 'Malay.png')
		,'mt'	=> array('title' => 'Maltese', 'flag' => 'Maltese.png')
		,'no'	=> array('title' => 'Norwegian', 'flag' => 'Norwegian.png')
		,'fa'	=> array('title' => 'Persian', 'flag' => 'Persian.png')
		,'pl'	=> array('title' => 'Polish', 'flag' => 'Polish.png')
		,'pt'	=> array('title' => 'Portuguese', 'flag' => 'Portuguese.png')
		,'pt-PT'	=> array('title' => 'Portuguese Portugal', 'flag' => 'Portuguese_Portugal.png')
		,'ro'	=> array('title' => 'Romanian', 'flag' => 'Romanian.png')
		,'ru'	=> array('title' => 'Russian', 'flag' => 'Russian.png')
		,'sr'	=> array('title' => 'Serbian', 'flag' => 'Serbian.png')
		,'sk'	=> array('title' => 'Slovak', 'flag' => 'Slovak.png')
		,'sl'	=> array('title' => 'Slovenian', 'flag' => 'Slovenian.png')
		,'es'	=> array('title' => 'Spanish', 'flag' => 'Spanish.png')
		,'sw'	=> array('title' => 'Swahili', 'flag' => 'Swahili.png')		
		,'sv'	=> array('title' => 'Swedish', 'flag' => 'Swedish.png')
		,'tl'	=> array('title' => 'Tagalog', 'flag' => 'Tagalog.png')
		,'th'	=> array('title' => 'Thai', 'flag' => 'Thai.png')
		,'tr'	=> array('title' => 'Turkish', 'flag' => 'Turkish.png')	
		,'uk'	=> array('title' => 'Ukrainian', 'flag' => 'Ukrainian.png')
		,'vi'	=> array('title' => 'Vietnamese', 'flag' => 'Vietnamese.png')
		,'cy'	=> array('title' => 'Welsh', 'flag' => 'Welsh.png')	
		,'yi'	=> array('title' => 'Yiddish', 'flag' => 'Yiddish.png')	// Currently not supported in Zend 1.11.7 check Zend_Locale for supported Languages
	);



global $EmailContentById;
	$EmailContentById = array(
							"4"=>array(
								"customer_name"=>"FirstName",
								"licencename"=>"ServiceName",
								"licence_number"=>"LicenceNo"
								),
							"6"=>array(
								"customer_name"=>"FirstName",
								"licencename"=>"ServiceName",
								"licence_number"=>"LicenceNo"
								),
							"8"=>array(
								"customer_name"=>"FirstName",
								"licencename"=>"ServiceName",
								"licence_number"=>"LicenceNo"
								),
							"9"=>array(
								"customer_name"=>"FirstName",
								"licencename"=>"ServiceName",
								"licence_number"=>"LicenceNo"
								),
							"10"=>array(
								"customer_name"=>"FirstName",
								"achieve"=>"achieve",
								"completion"=>"completion"
								),
							"11"=>array(
								"customer_name"=>"FirstName",
								"achieve"=>"achieve",
								"completion"=>"completion"
								),
							"12"=>array(
								"customer_name"=>"FirstName",
								"licence_number"=>"LicenceNo",
								"token"=>"token",
								"ExpiryDate"=>"ExpiryDate"
								),
							"13"=>array(
								"customer_name"=>"FirstName",
								"licence_number"=>"LicenceNo",
								"ExpiryDate"=>"ExpiryDate"
								)
		);

/* End of file constants.php */
/* Location: ./application/config/constants.php */
