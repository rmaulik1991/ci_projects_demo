<section class="content-header">
    <h1>
        
        <small>
           Change Password            
        </small>
    </h1>
    <?php
		$this->load->view("/template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">
    	<div class="col-md-6">
    		<div class="box-body">
                 <div id="flash_msg"></div>
                 <?php echo form_open('',array('name'=>"changepwd",'id'=>"changepwd")); ?>
                    
                    <div class="form-group">
                        <?php echo form_error('oldpassword'); ?>    
                        <?php echo form_label('Old Password:');?>
                        <?php echo form_input(array('id' => 'password','type'=>'password' ,'name' => 'password' , 'class'=>'form-control', 'placeholder'=>'Password ...')); ?>
                    </div>

                    <div class="form-group">
                        <?php echo form_error('password'); ?>    
                        <?php echo form_label('New Password:');?>
                        <?php echo form_input(array('id' => 'newpassword','type'=>'password' ,'name' => 'newpassword' , 'class'=>'form-control', 'placeholder'=>'Password ...')); ?>
                    </div>

                    <div class="form-group">
                    <?php echo form_error('re_password'); ?>    
                        <?php echo form_label('Repeat New Password:');?>
                        <?php echo form_input(array('id' => 're_password','type'=>'password' ,'name' => 're_password' , 'class'=>'form-control', 'placeholder'=>'Repeat Password ...')); ?>
                    </div>
                   
                    <div class="form-group">
                        <button class="btn btn-primary btn-flat" type="submit" >Submit</button>
                        <a href="<?=base_url()?>adminmaster/" class="btn btn-defauly btn-flat">Cancel</a>
                    </div>    
				<?php echo form_close(); ?>
             </div>
    	</div>
    </div>
</section>
<script>
$(document).ready(function() {    
    $('#changepwd').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
         fields: {
            password: {
                 message: 'The firstname is not valid',
                validators: {
                    notEmpty: {
                        message: 'The firstname is required and cannot be empty'
                    },
                    stringLength: {
                        min: 2,
                        max: 30,
                        message: 'The firstname must be more than 2 and less than 30 characters long'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The firstname can only consist of alphabetical'
                    // }
                }
            },
                       
             newpassword: {
                validators: {
                    notEmpty: {
                        message: 'The password is required and cannot be empty'
                    },
                    identical: {
                        field: 're_password',
                        message: 'The password and its confirm are not the same'
                    }
                }
            },
            re_password: {
                validators: {
                    notEmpty: {
                        message: 'The confirm password is required and cannot be empty'
                    },
                    identical: {
                        field: 'newpassword',
                        message: 'The password and its confirm are not the same'
                    }
                }
            }
         }
    });
} );
</script>    	