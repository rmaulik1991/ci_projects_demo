<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require ("common/Index_Controller.php");
class Dashboard extends Index_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('store_model');
		is_login();
		$this->user_session = $this->session->userdata('user_session');

	}

	public function index()
	{ 
		
		$data['view'] = "index";
		$where = 'status = "Active"';	
		$data['total_emp'] = $this->store_model->selectData(EMPLOYEE, '*', $where,$order_by="", $order_type="", $group_by="", $limit="", $rows="", $type='rowcount');	
		$data['total_store'] = $this->store_model->selectData(STORE, '*', $where,$order_by="", $order_type="", $group_by="", $limit="", $rows="", $type='rowcount');	
		$data['total_product'] = $this->store_model->selectData(PRODUCT_TABLE, '*', $where,$order_by="", $order_type="", $group_by="", $limit="", $rows="", $type='rowcount');	
		$data['total_branch'] = $this->store_model->selectData(STORE_BRANCH_TABLE, '*', $where,$order_by="", $order_type="", $group_by="", $limit="", $rows="", $type='rowcount');	
		$data['total_brands'] = $this->store_model->selectData(BRAND_TABLE, '*', $where,$order_by="", $order_type="", $group_by="", $limit="", $rows="", $type='rowcount');	
		$where1 = 'sts_display_status_id = "1" OR  sts_display_status_id = "2"';
		$group_by = 'sts_product_id,added_date,sts_store_branch_id';
		$data['total_dp'] = $this->store_model->selectData(DISPLAY_TRACKER, '*', $where1,$order_by="", $order_type="", $group_by, $limit="", $rows="", $type='rowcount');	
		$this->load->view('content', $data);
	}
	
}
?>