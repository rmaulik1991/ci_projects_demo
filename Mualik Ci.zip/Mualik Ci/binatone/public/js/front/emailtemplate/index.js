var oTable;
$(document).ready(function() {
	oTable = $('#emailTable').dataTable( {
		"processing": true,
		"serverSide": true,
		"ajax": {
			"url": base_path()+'emailtemplate/ajax_list/',
			"type": "POST"
		},
		aoColumnDefs: [
		  {
			 bSortable: false,
			 aTargets: [ -1 ]
		  }
		]
	} );
	
	$('#emailTempFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		 fields: {
            emailSubject: {
                message: 'The Email Subject no is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Email Subject is required and cannot be empty'
                    }
                }
            },
			
			emailContent: {
                message: 'The Email contect no is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Email content is required and cannot be empty'
                    }
                }
            },            
            status: {
                message: 'The status is not valid',
                validators: {
                    notEmpty: {
                        message: 'The status is required and cannot be empty'
                    }
                }
            }
		 }
    });
	
} );


function delete_emailtemp(del_id) {
bootbox.confirm("Are you sure to delete page?", function(result) {
	if(result){
	startLoading();
	$.ajax({
		type: 'post',
		url: base_path()+'emailtemplate/delete',
		data: 'id='+del_id,
		success: function (data) {
			if (data == "success") {
				oTable.fnClearTable(0);
				oTable.fnDraw();
				$("#flash_msg").html(success_msg_box ('Template deleted successfully.'));
			}else{
				$("#flash_msg").html(error_msg_box ('An error occurred while processing.'));
			}
			stopLoading();
		}
	});
	}
	});
}