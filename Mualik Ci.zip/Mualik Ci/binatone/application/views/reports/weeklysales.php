<?php 
//load our new PHPExcel library
$this->load->library('excel');
//activate worksheet number 1
$this->excel->setActiveSheetIndex(0);
//name the worksheet
$this->excel->getActiveSheet()->setTitle('test worksheet');

//echo "<pre>";//$data[1];
//echo "<pre>";print_r($data);exit;
$qty=array();

$val="";
$val1="";
$week=array();
$w=array();
$monthheader=array();
$categoryheader=array();
$catcount=3;
$categoryname=array();

foreach ($data[3] as $key => $value) {
	$categoryheader[$key][]=$key;
	foreach ($data[1] as $key1 => $value1) {
		$month=date('M',strtotime($value1));
		$week1=ceil( date( 'j', strtotime( $value1 ) ) / 7 );
		$w[$key][$week1]=$month.' week '.$week1;
		$categoryheader[$key][$week1]="";
		
	}

	$categoryname[]=$key;	
	$w[$key][]=$month." total";
}


foreach ($categoryheader as $key => $value) {
	foreach ($value as $key1 => $value1) {
		$categoryheader1[]=$value1;	
	}
	
}


$monthheader[]=$data[2];
foreach ($w as $key => $value) {
	foreach ($value as $key1 => $value1) {
		$monthheader[]=$value1;	
	}
	
}
$this->excel->getActiveSheet()->fromArray($categoryheader1, NULL, 'B3');
$this->excel->getActiveSheet()->fromArray($monthheader, NULL, 'A4');

foreach ($data[0] as $key => $value) {
	foreach ($data[1] as $key1 => $value1) {
		//$month=date('M',strtotime($value1));
		$week1=ceil( date( 'j', strtotime( $value1 ) ) / 7 );
		foreach ($value as $key2 => $value2) {
			if(isset($value2) && !empty($value2)){
				foreach ($value2 as $key3 => $value3) {

				 	if($key3==$value1){
				 		if(!isset($week[$key][$key2][$week1]) && empty($week[$key][$key2][$week1]))
				 		{
				 			$week[$key][$key2][$week1]=$value3;	
				 
					 	}else{
					 
					 		$week[$key][$key2][$week1]=$value3+$week[$key][$key2][$week1];	
					 
					 	}
				 	}
				} 
			}
		
			
			if(isset($week[$key][$key2][$week1])){
				$week[$key][$key2][$week1]=$week[$key][$key2][$week1];
				
			}else{
				$week[$key][$key2][$week1]='0';
			}
				
			
		}
	 		
	}

	
}


// foreach ($categoryname as $key => $value) {
// 	//echo $value;
// 	foreach ($week as $key1 => $value1) {
		
// 		foreach ($value1 as $key2 => $value2) {
// 			//echo $value1;
// 			//print_r($value1[$value]);
// 			if($value==$key2){
// 				echo $key2;	
// 			}else{
// 				$val=0;
// 			}
			
// 			// $keyvalue="";
// 			// if(isset($value1[$value])){
// 			// 	$keyvalue=$value;
// 			// }else{
// 			// 	$keyvalue1="0";
// 			// }
// 			// echo $keyvalue." ";
// 		}
		
// 	}
// 	echo $val;
// }
// exit;
// print_r($week);

$colcount=5;
$val="";
$val1="";

foreach ($week as $key => $value) {
	$category=array();
	$category[]=$key;
	
	foreach ($value as $key1 => $value1) {

	//	foreach ($categoryname as $key4 => $value4) {
			//echo $key1;
		//	if($value4==$key1){
				//echo $key1;
			//	foreach ($value1 as $key2 => $value2) {
					$val='0';
					//print_r($key1 );
					foreach ($value1 as $key3 => $value3) {
							 	$val+=$value3;
							 	$category[]=$value3;			
						
					}
					//echo $val;
					
					if($val==0){
						$category[]='0';	
					}else{
						$category[]=$val;
					}
					
			//	}		
			//}else{
			//	$val1=0;
		//	}
	//	}
		// if($val1==0){
		// 	$category[]=0;
		// }
		

		
	}

	//print_r($category);
	$this->excel->getActiveSheet()->fromArray($category, NULL, 'A'.$colcount);
	$colcount++;
}

//exit;
$filename='PHPExcelDemo.xlsx'; //save our workbook as this file name
	ob_end_clean();		
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="item_list.xlsx"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($this->excel,'Excel2007');

$objWriter->save('php://output');
?>