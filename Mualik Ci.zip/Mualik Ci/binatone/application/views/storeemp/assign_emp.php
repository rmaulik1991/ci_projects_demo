<section class="content-header">
    <h1>
        
        <small>
            Assign Product            
        </small>
    </h1>
    <?php
		$this->load->view("/template/bread_crumb");
	?>
</section>
<style></style>
<section class="content">
	<div class="row">
    	<div class="col-md-8 col-md-offset-2">
    		<div class="box-body">
                 <div id="flash_msg"></div>
                 <?php echo form_open('',array('name'=>"storeFrm",'id'=>"storeFrm")); ?>
                    <div class="box-body"> 
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>UnAllocated Product</label>
                                <div> 
                                    <input type="text" id="search" class="form-control" placeholder="Search" oninput="searchDesignation(this.id)">
                                    <select name="product[]" id="ename" class="form-control" multiple>
                                    <!-- <option value="">Select Employee Name</option> -->
                                    <?php foreach ($emp_list as $row) { ?>
                                       <option value="<?php echo $row->id; ?>"><?php echo $row->first_name.' '.$row->last_name; ?></option>
                                    <?php } ?>
                                </select>
                                </div>
                            </div> 
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Allocated Product</label>
                                <div>
                                    <select name="allocate_emp[]" id="sename" class="form-control" multiple>
                                        <?php foreach ($asn_emp_list as $asn_emp) { ?>
                                            <option class="optcolcor" value="<?php echo $asn_emp->id; ?>" selected="selected"><?php echo $asn_emp->first_name.' '.$asn_emp->last_name; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>                            
                        </div>           
                    </div>
                    <button class="btn btn-primary btn-flat" type="submit" >Submit</button>              
                </div>  
				<?php echo form_close(); ?>
             </div>
    	</div>
    </div>
</section>
<script type="text/javascript">
    $('#ename').click(function()
{
    var allocate = $('#tallocate').text();
   
        selectValues = $(this).val();
        if(selectValues!=null){
        selectText = $("#ename option[value='"+ selectValues +"']").text();
        $('#sename').append($("<option></option>")
                            .attr("value",selectValues)
                            .attr('selected', true).text(selectText)); 
        $("#ename option[value='"+ selectValues +"']").remove();
        
        //$('#tallocate').text(allocate);
    }
    
});

$('#sename').click(function()
{
    var allocate = $('#tallocate').text();
    selectValues = $(this).val();
    if(selectValues!=null){
    selectText = $("#sename option[value='"+ selectValues +"']").text();
    $('#ename').append($("<option></option>")
                        .attr("value",selectValues).text(selectText)); 
    $("#sename option[value='"+ selectValues +"']").remove();
    $("#sename option").prop("selected", "selected");

    //$('#tallocate').text(allocate);
    }
});

function searchDesignation(id)
{
    var dval = $('#'+id).val();
    if(dval != '')
    {
        $('#ename').find('option').hide();
        // $('#ename').find('option:contains('+dval+')').show();
        var re = new RegExp(dval, 'gim');
        $("#ename option").each(function()
        {
            var str = $(this).text();
            var n = str.lastIndexOf('-');
            var str1 = str.substring(n + 1);
            var result = str1.match(re);
            if(result != null)
                $(this).show();
        });
    }
    else
    {
        $('#ename').find('option').show();
    }
}
</script>    	