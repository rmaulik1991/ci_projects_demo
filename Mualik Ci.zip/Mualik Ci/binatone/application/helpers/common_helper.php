<?php

	function pr($arr, $option="")
	{
		echo "<pre>";
		print_r($arr);
		echo "</pre>";
		if ($option != "") {
			exit();
		}
	}

	function base_path($type="www")
	{
		return base_url();
	}

	function public_path($type="www")
	{
		return base_url()."public/";
	}

	function index_path($type="www")
	{
		return base_url()."index/";
	}

	function admin_path($type="www")
	{
		return base_url()."admin/";
	}

    function profile_img_path($type="www")
    {
        return base_url()."public/uploads/profile_images/";
    }
	function upload_path($type="www")
    {
        return base_url()."public/uploads/";
    }
	function is_login()
	{

		$CI =& get_instance();
		$session = $CI->session->userdata('user_session');
		if (!isset($session['id'])) {
			redirect(base_url());
		}
	}

    function is_front_login()
    {

        $CI =& get_instance();
        $session = $CI->session->userdata('front_session');

        if (!isset($session['id'])) {
            redirect(base_url());
        }
    }

	function success_msg_box($msg)
	{
		$html = '<div class="alert alert-success alert-dismissable">
                    <i class="fa fa-check"></i>
                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                    '.$msg.'
                </div>';
        return $html;
	}

	function error_msg_box($msg)
	{
		$html = '<div class="alert alert-danger alert-dismissable">
                    <i class="fa fa-ban"></i>
                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                    '.$msg.'
                </div>';
        return $html;
	}

	function get_active_tab($tab)
    {
    	$CI =& get_instance();
        if ($CI->router->fetch_class() == $tab) {
            return 'active';
        }
    }


    function sendEmail($list,$subject,$content,$attachment=array())	{
    		
        //$to, $subject, $emailTpl, $from, $from_name, $cc='', $bcc=''
        $ci =& get_instance();
        $ci->load->library('email');
		$config['protocol'] = PROTOCOL;
		$config['smtp_crypto'] = SMTP_CRYPTO;
		$config['smtp_host'] = SMTP_HOST;
		$config['smtp_port'] = SMTP_PORT;
		$config['smtp_user'] = SMTP_USERNAME; 
		$config['smtp_pass'] = SMTP_PASSWORD;
		$config['charset'] = "utf-8";
		$config['mailtype'] = "html";
		$config['newline'] = "\r\n";
		$ci->email->initialize($config);
		$ci->email->from(FROM_EMAIL, FROM_NAME);
		//$list = array('manali@parextech.com');
		foreach($attachment as $k=>$v){
			$ci->email->attach($v);	
		}
		
		$ci->email->to($list);
		$ci->email->bcc(BCC);
		$ci->email->reply_to(REPLY_TO, REPLY_NAME);
		$ci->email->subject($subject);
		$ci->email->message($content);
		$email_Sent=$ci->email->send();
        return $email_Sent;
    }
	function converdateformat($date,$currentFormat,$convertFormat='Ymd',$reqSeprat,$convSeprat)
	{
		if(trim($date)=='' || trim($date)=='1970-01-01' || trim($date)=='0000-00-00')
		{
			return $result='';
		}
		$tempDate=explode($reqSeprat,$date);
		if($currentFormat=='dmY')
		{
			$day=$tempDate[0];
			$month=$tempDate[1];
			$year=$tempDate[2];
		}
		else if($currentFormat=='mdY')
		{
			$day=$tempDate[1];
			$month=$tempDate[0];
			$year=$tempDate[2];
		}
		$result='';
		
		if($convertFormat=='Ymd')
		{
			$result=$year.$convSeprat.$month.$convSeprat.$day;
		}
		else if($convertFormat=='dmY')
		{
			$result=$year.$convSeprat.$month.$convSeprat.$day;
		}
		else if($convertFormat=='mdY')
		{
			$result=$year.$convSeprat.$month.$convSeprat.$day;
		}
		else
		{
			$result=date('Y-m-d');
		}
		return $result;
	}
	
	function translate($text)
	{
		$CI =& get_instance();
		$line=$CI->lang->line($text);
		if(empty($line))
		{
			$line=$text;
		}
		
		return $line;
	}

		function accessControl($controller='',$action='',$type='g')
		{
			if(config_item('access_control')){
				if(in_array($controller,array_keys(config_item('user_role'))))
				{
					if(in_array($action,array_keys(config_item('user_role')[$controller])))
					{
						if(in_array($type,config_item('user_role')[$controller][$action]))
						{
							return true;	
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return true;
			}
		}
	
?>
