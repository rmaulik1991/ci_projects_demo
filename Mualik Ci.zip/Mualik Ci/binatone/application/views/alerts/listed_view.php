<section class="content-header">
    <h1>
       Listed Stocked but not Displayed & 
		Listed but no Stocks
    </h1>
    <?php
		$this->load->view("template/bread_crumb");
	?>
</section>
			
<section class="content">
	<div class="row">
    	<div class="col-md-12">
    		
    		<div id="flash_msg">
			</div>
            <?php //echo '<pre>'; print_r($data); exit(); ?>
			<?php //if(accessControl('users','add',$this->user_session['role'])){ ?>
    		<a class="btn btn-default pull-right" href="<?php echo base_path()?>alerts/report_listed?daterange=<?php echo $daterange; ?>">
            &nbsp;Export Data</a>
			<?php //} ?>
            <div id="list">
				<div class="box">
					<div class="box-header">
						<h3 class="box-title"><?= translate('STORE_BRANCH_TITLE') ?></h3>                                    
					</div><!-- /.box-header -->
					<div class="box-body table-responsive">
						<table id="storebranchTable" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>Store Name</th>									
									<th>Branch Name</th>									
									<th>Product</th>
									<th>Date</th>
									<th>Status</th>
								</tr>
                                <?php foreach ($data as $key => $value) { ?>
                                	<?php foreach ($value as $key1 => $value1) { ?>
	                                    <?php foreach ($value1 as $key2 => $value2) { ?>
	                                        <tr>
	                                        <td><?php echo $key; ?></td>
	                                        <td><?php echo $key1; ?></td>
	                                        <td><?php echo $value2[0]; ?></td>
	                                        <td><?php echo date('d-m-Y',strtotime($value2[1])); ?></td>
	                                        <td><?php echo $value2[2]; ?></td>
	                                        </tr>   
                                <?php } } }?>
							</thead>
						</table>
					</div><!-- /.box-body -->
				</div><!-- /.box -->
			</div>
    	</div>
    </div>
</section>
