<section class="content-header">
    <h1>
        <?= translate('BRAND_MASTER_TITLE') ?>
    </h1>
    <?php
		$this->load->view("template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">
    	<div class="col-md-12">
    		<div id="flash_msg">
			</div>
			<?php //if(accessControl('users','add',$this->user_session['role'])){ ?>
    		<a class="btn btn-default pull-right" href="<?php echo base_path()?>brand/add">
            <i class="fa fa-plus"></i>&nbsp;<?= translate('BRAND_BUTTON_ADD'); ?></a>
			<?php //} ?>
            <div id="list">
				<div class="box">
					<div class="box-header">
						<h3 class="box-title"><?= translate('BRAND_MASTER_TITLE') ?></h3>                                    
					</div><!-- /.box-header -->
					<div class="box-body table-responsive">
						<table id="brandTable" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>Brand name</th>									
									<th>Brand Details</th>
									<th>Status</th>
									<th>Action</th>
								</tr>
							</thead>
						</table>
					</div><!-- /.box-body -->
				</div><!-- /.box -->
			</div>
    	</div>
    </div>
</section>