<section class="content-header">
    <h1>
        <?= translate('STORE_BRANCH_TITLE') ?>
    </h1>
    <?php
		$this->load->view("template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">
    	<div class="col-md-12">
    		<div id="flash_msg">
			</div>
			<input type="hidden" id="store_id" value="<?php echo $store_id; ?>">
			<?php if(accessControl('users','add',$this->user_session['role'])){ ?>
    		<a class="btn btn-default pull-right" href="<?php echo base_path()?>storebranch/add">
            <i class="fa fa-plus"></i>&nbsp;<?= translate('STORE_BRANCH_ADD'); ?></a>
			<?php } ?>
            <div id="list">
				<div class="box">
					<div class="box-header">
						<h3 class="box-title"><?= translate('STORE_BRANCH_TITLE') ?></h3>                                    
					</div><!-- /.box-header -->
					<div class="box-body table-responsive">
						<table id="branchTable" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>Branch name</th>									
									<th>Address</th>									
									<th>Contact Person</th>
									<th>Contact Number</th>
									<th>Status</th>
									<th>Action</th>
								</tr>
							</thead>
						</table>
					</div><!-- /.box-body -->
				</div><!-- /.box -->
			</div>
    	</div>
    </div>
</section>
<script type="text/javascript">
	$(document).ready(function() {
    var store_id = $('#store_id').val();
    oTable = $('#branchTable').dataTable( {
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": base_path()+'storebranch/ajax_branch_list/'+store_id,
            "type": "POST"
        },
        aoColumnDefs: [
          {
             bSortable: false,
             aTargets: [ -1 ]
          }
        ]
    } );
    } );
</script>