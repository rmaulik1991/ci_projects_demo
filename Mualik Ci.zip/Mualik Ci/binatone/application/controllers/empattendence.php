<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require ("common/Index_Controller.php");

class empattendence extends Index_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('empattendence_model');
		$this->user_session = $this->session->userdata('user_session');
		is_login();
	}

	public function index() {	
		$data['flash_msg'] = $this->msg_session;
		$data['employee_list']=$this->empattendence_model->selectData(EMPLOYEE,'*');		
		$data['view'] = "index";
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');
	}

	public function ajax_list($store_id,$limit=0) {
		$post = $this->input->post();
		$columns = array(		
			array( 'db' => 'attendance_time',  'dt' => 0,'formatter' => function( $d, $row ) {
						return date('d-m-Y h:i:s' ,strtotime($row['attendance_time']));
					}, ),
			array( 'db' => 'location_lat',  'dt' => 1 ),
			array( 'db' => 'location_lon',  'dt' => 2 ),
			array( 'db' => 'attendance_status','dt'=> 3 ),
			array( 'db' => 'Id',
					'dt' => 4,
					'formatter' => function( $d, $row ) {
						return '<a href='.site_url('/empattendence/view_data/'.$row['Id']).' class="fa fa-eye"></a> ';
					},
			),
		);
		
		echo json_encode( SSP::simple( $post, ATTENDENCE_TABLE, "Id", $columns,array(),"attendance_status !='Inactive' AND sts_employee_id=".$store_id."" ) );
		exit;
	}

	public function view_data($id) {
		if ($id == "" || $id <= 0) {
			redirect('empattendence');
		}
		$where = 'id = '.$id;	
		$data['flash_msg'] = $this->msg_session;		
		$data['view'] = "attendence";
		$data['lat_lon'] = $this->empattendence_model->selectData(ATTENDENCE_TABLE,'*',$where);
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');
	}

}
