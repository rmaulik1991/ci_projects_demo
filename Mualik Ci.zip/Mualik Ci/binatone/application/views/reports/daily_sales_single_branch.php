<?php 
//load our new PHPExcel library
$this->load->library('excel');
//activate worksheet number 1
$this->excel->setActiveSheetIndex(0);
//name the worksheet
$this->excel->getActiveSheet()->setTitle('test worksheet');
//set cell A1 content with some text
$this->excel->getActiveSheet()->setCellValue('A6', 'Model');
$this->excel->getActiveSheet()->setCellValue('A2', 'DAILY SALES TRACKER');
$this->excel->getActiveSheet()->setCellValue('A3', "PROMOTER'S NAME: ");
$this->excel->getActiveSheet()->setCellValue('B3', $data[2]['name']);
$this->excel->getActiveSheet()->setCellValue('H3', 'OUTLET: ');
$this->excel->getActiveSheet()->setCellValue('I3', $data[2]['branch_name']);
$this->excel->getActiveSheet()->setCellValue('M3', 'MONTH/YEAR: ');
$this->excel->getActiveSheet()->setCellValue('N3', $data[2]['monthdate']);
$this->excel->getActiveSheet()->setCellValue('B6', 'Selling Price');
$this->excel->getActiveSheet()->getColumnDimension('A')->setWidth(28);
$this->excel->getActiveSheet()->fromArray($data[0], NULL, 'C6');
$qty=array();

$val="";
$val1="";
$colcount=7;
foreach ($data[1] as $key => $value) {
	$product=array();
	$product[]=$key;
	$product[]="";
	foreach ($data[0] as $key1 => $value1) {
		//echo $value1;
		$val="";
		foreach ($value as $key2 => $value2) {
			//echo $key2;
			if($key2==$value1 && isset($value2)){
				//$qty[$key2]=$value2;	
				$val=$value2;
			}else{
				$val1=0;
			}
			
		}
		if(isset($val)){
			$product[]=$val;
		}else{
			$product[]=$val1;
		}
	}
	$this->excel->getActiveSheet()->fromArray($product, NULL, 'A'.$colcount);
	$colcount++;
	
}

// foreach ($data[0] as $key => $value) {
	
// }
//exit;
//echo "<pre>";print_r($product);exit;
//$this->excel->getActiveSheet()->fromArray($data, NULL, 'C6');
/*$row=6;
for($i=0;$i<50;$i++){
 $this->excel->getActiveSheet()->setCellValue('A'.$row, 'My Value'.$row);
 $row++;
}*/


$filename=$data[2]['branch_name'].'.xlsx'; //save our workbook as this file name
	ob_end_clean();		
 header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename='.$filename.'');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($this->excel,'Excel2007');

$objWriter->save('php://output');
?>