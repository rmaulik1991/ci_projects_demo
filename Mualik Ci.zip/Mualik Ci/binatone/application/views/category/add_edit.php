<section class="content-header">
    <h1>
        
        <small>
            <?=($this->router->fetch_method() == 'add')?'Add Category':'Edit Category'?>            
        </small>
    </h1>
    <?php
		$this->load->view("/template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">
    	<div class="col-md-6">
    		<div class="box-body">
                 <div id="flash_msg"></div>
                 <?php echo form_open('',array('name'=>"categoryFrm",'id'=>"categoryFrm")); ?>
                    <div class="form-group">
                        <?php echo form_error('category_name'); ?>    
                        <?php echo form_label('Category Name :');?>
                         <?php if($current_view=="edit"){
                         ?>
                            <select class="form-control" name="category_name" id="category_name" >
                                
                            <?php 
                           foreach (@$allcategory as $key=>$value){
                             
                            ?>
                                <option value="<?php echo $value->id;?>" 
                                    <?=(@$allcategory[$key]->id == $category[0]->pcategory_id)?'selected':''?>><?php echo $value->category_name;?></option>    

                            <?php
                            }
                            ?>
                              
                            </select>
                            </div>
                            <div class="form-group">
                                <?php echo form_error('sub_category_name'); ?>    
                                <?php echo form_label('Sub Category Name:');?>
                                <?php echo form_input(array('id' => 'sub_category_name', 'name' => 'sub_category_name' , 'class'=>'form-control', 'placeholder'=>'Enter Sub Category Name...','value'=>@$category[0]->category_name)); ?>
                                <span style="color:#a94442;visibility: hidden;" id="error"></span>

                            </div>

                        <?php
                    }else{
                    ?>
                         <select class="form-control" name="category_name" id="category_name">
                                <option value="">Select</option>
                                <?php 
                                foreach (@$category as $key=>$value){
                                ?>
                                    <option value="<?php echo $value->id;?>"><?php echo $value->category_name;?></option>    

                                <?php
                                }?>
                             
                            </select>
                             </div>
                         <div class="form-group">
                            <?php echo form_error('sub_category_name'); ?>    
                            <?php echo form_label('Sub Category Name:');?>
                            <?php echo form_input(array('id' => 'sub_category_name', 'name' => 'sub_category_name' , 'class'=>'form-control', 'placeholder'=>'Enter Sub Category Name...','value'=>"")); ?>
                            <span style="color:#a94442;visibility: hidden;" id="error"></span>
                        </div>

                    <?php
                    }
                    ?>
                    
                   
                  
                    <?php  if($current_view=="edit"){
                    ?>
                        <div class="form-group">
                                <?php echo form_error('status'); ?>    
                                <?php echo form_label('Status :');?>
                                <select class="form-control" name="status" id="status">
                                    <option value="">Select</option>
                                    <option value="Active" <?=(@$category[0]->status == 'Active')?'selected':''?> >Active</option>
                                    <option value="Inactive" <?=(@$category[0]->status == 'Inactive')?'selected':''?> >Inactive</option>
                                </select>
                        </div> 
                    <?php
                    }
                    ?>
                    
                    <div class="form-group">
                        <button class="btn btn-primary btn-flat" type="submit" >Submit</button>
                        <a href="<?=base_url()?>category/" class="btn btn-defauly btn-flat">Cancel</a>
                    </div>    
				<?php echo form_close(); ?>
             </div>
    	</div>
    </div>
</section>    	

<script type="text/javascript">
    $(document).ready(function(){
        $("#sub_category_name").blur(function(){
            startLoading();
            var parent_id=$('#category_name').find(":selected").val();
           
            if($(this).val()=="" || $(this).val().trim()=="" ){
                 stopLoading();
                 $('#error').css('visibility','hidden');
            }
            $.ajax({
                url:base_path()+'category/checkduplicatecategory',
                 type:"POST",
                 data:{category_name:$(this).val(),parent_id:parent_id},
                 success:function(result){
                   if(result){
                        stopLoading();
                        $('#error').html('Category name already exiest');
                        $(".btn").prop('disabled', true);
                        $('#error').css('visibility','visible');

                   }else{
                        stopLoading();
                        $('#error').css('visibility','hidden'); 
                        $(".btn").prop('disabled', false);                         
                   }
                }  
                   
                
            });
        });
    });
        
                           
</script>