<?php
class displayproduct_model extends CI_Model{
		var $table;
	public function  __construct(){
		parent::__construct();
		$this->load->database();
		//$this->table ='admin_master';
	}


/*
	| -------------------------------------------------------------------
	| check unique fields
	| -------------------------------------------------------------------
	|
	*/
	public function isUnique($table, $field, $value,$id='')
	{
		$this->db->select('*');
		$this->db->from($table);
		$this->db->where($field,$value);
		if($id!='')
		{
			$this->db->where("id != ",$id);
		}
		$query = $this->db->get();
		// echo "<pre>";
		// print_r($query);exit();
		$data = $query->num_rows();
		return ($data > 0)?FALSE:TRUE;
	}

		/*
	| -------------------------------------------------------------------
	| Insert data
	| -------------------------------------------------------------------
	|
	| general function to insert data in table
	|
	*/
	public function insertData($table, $data)
	{
		
		$result = $this->db->insert($table, $data);
		// echo "<pre>";
		// print_r($result);exit();
		if($result == 1){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}



		/*
	| -------------------------------------------------------------------
	| Insert Batch
	| -------------------------------------------------------------------
	|
	| general function to insert data in table
	|
	*/
	public function insertDatabatch($table, $data)
	{
		
		$result = $this->db->insert_batch($table, $data);
		// echo "<pre>";
		// print_r($result);exit();
		if($result == 1){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	
	/*
	| -------------------------------------------------------------------
	| Update data
	| -------------------------------------------------------------------
	|
	| general function to update data
	|
	*/
	public function updateData($table, $data, $where)
	{
		$this->db->where($where);
		if($this->db->update($table, $data)){
			return 1;
		}else{
			return 0;
		}
	}


	public function deleteDataemp($table, $where){
		$this->db->where($where);
		if($this->db->delete($table)){
			return 1;
		}else{
			return 0;
		}
	}
	
	
	
	/*
	| -------------------------------------------------------------------
	| Select data
	| -------------------------------------------------------------------
	|
	| general function to get result by passing nesessary parameters
	|
	*/
	public function selectData($table, $fields='*', $where='', $order_by="", $order_type="", $group_by="", $limit="", $rows="", $type='')
	{
		$this->db->select($fields);
		$this->db->from($table);
		if ($where != "") {
			$this->db->where($where);
		}

		if ($order_by != '') {
			$this->db->order_by($order_by,$order_type);
		}

		if ($group_by != '') {
			$this->db->group_by($group_by);
		}

		if ($limit > 0 && $rows == "") {
			$this->db->limit($limit);
		}
		if ($rows > 0) {
			$this->db->limit($rows, $limit);
		}


		$query = $this->db->get();

		if ($type == "rowcount") {
			$data = $query->num_rows();
		}else{
			$data = $query->result();
		}

		#echo "<pre>"; print_r($this->db->queries); exit;
		$query->result();

		return $data;
	}

	/*
	| -------------------------------------------------------------------
	| Select data
	| -------------------------------------------------------------------
	|
	| general function to get result by passing nesessary parameters
	|
	*/
	public function selectProduct($table,$where='')
	{
		$query=$this->db->select('sp.product_name,sp.id')
		->from('sts_store_product_int as sspi', 'left')
		->join('sts_product as sp','sspi.sts_product_id=sp.id')
		->where($where)
		->get();
		$data = $query->result();
		return $data;
	}

	/*
	| -------------------------------------------------------------------
	| Select All product
	| -------------------------------------------------------------------
	|
	| general function to get result by passing nesessary parameters
	|
	*/
	public function selectallemp($table, $fields='*', $id,$type='')
	{
		/*$this->db->select('*');
		$this->db->from($table.' as pro,sts_store_product_int');
		$this->db->join('sts_store_product_int as pin', 'pro.id != pin.sts_product_id','left outer');
		$this->db->where('pro.status','Active');
		$this->db->where('sts_store_product_int.sts_branch_id',$id);
		$this->db->group_by('pro.id');*/
		$sql="SELECT emp.* FROM sts_employee emp LEFT JOIN sts_store_employee_int eit ON emp.id = eit.sts_employee_id and eit.sts_branch_id='".$id."' and eit.status='Active' WHERE emp.status='Active' and (eit.id is null or eit.sts_branch_id != '".$id."')";
			//echo $sql; exit();
		$query=$this->db->query($sql);

		if ($type == "rowcount") {
			$data = $query->num_rows();
		}else{
			$data = $query->result();
		}

		#echo "<pre>"; print_r($this->db->queries); exit;
		$query->result();

		return $data;
	}

	/*
	| -------------------------------------------------------------------
	| Select Product
	| -------------------------------------------------------------------
	|
	| general function to get result by passing nesessary parameters
	|
	*/
	public function selectemp($table, $fields='*', $id, $order_by="", $order_type="", $group_by="", $limit="", $rows="", $type='')
	{
		$this->db->select($fields,'sts_employee.*,sts_employee.id as emp_id');
		$this->db->from($table.' as store');
		$this->db->join('sts_employee as emp','store.sts_employee_id=emp.id');
		$this->db->where('store.sts_branch_id',$id);
		$this->db->where('store.status','Active');

		$query = $this->db->get();

		if ($type == "rowcount") {
			$data = $query->num_rows();
		}else{
			$data = $query->result();
		}

		#echo "<pre>"; print_r($this->db->queries); exit;
		$query->result();

		return $data;
	}

	/*
	| -------------------------------------------------------------------
	| Update data
	| -------------------------------------------------------------------
	|
	| general function to update data
	|
	*/
	public function deleteBulk($table, $id)
	{
		$this->db->where('sts_branch_id',$id);
		if($this->db->delete($table)){
			return 1;
		}else{
			return 0;
		}
	}

	
		/*
	| -------------------------------------------------------------------
	| Delere data
	| -------------------------------------------------------------------
	|
	| general function to delete the records
	|
	*/
	public function deleteData($table, $data)
	{
		if($this->db->delete($table, $data)){
			return 1;
		}else{
			return 0;
		}
	}


}
?>
