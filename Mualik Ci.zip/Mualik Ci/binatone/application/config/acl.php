<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Use to access control to user Types 
|--------------------------------------------------------------------------
|
| This array is initialize user access control.
|
*/

$config['user_role'] = array('adminmaster' => array(
								   'index'=>array(1,2,3)
								   ,'ajax_list'=>array(1,2,3)
								   ,'add'=>array(1)
								   ,'edit'=>array(1)
								   ,'delete'=>array(1)
								   ,'adminprofile'=>array(1,2,3)
								   ,'changepassword'=>array(1,2,3)
								)
								,'alerts' => array(
								   'index'=>array(1,2,3)
								   ,'report_listed'=>array(1,2,3)
								   ,'employee_status'=>array(1,2,3)
								   ,'sales_update'=>array(1,2,3)
								)
								,'brand' => array(
								   'index'=>array(1,2,3)
								   ,'ajax_list'=>array(1,2,3)
								   ,'add'=>array(1,2,3)
								   ,'edit'=>array(1,2,3)
								   ,'delete'=>array(1,2,3)
								)
								,"category"=>array(
									'index'=>array(1,2,3)
								   ,'ajax_list'=>array(1,2,3)
								   ,'add'=>array(1,2,3)
								   ,'edit'=>array(1,2,3)
								   ,'delete'=>array(1,2,3)
								   ,'checkduplicatecategory'=>array(1,2,3)
								)
								,'comproduct' => array(
								   'index'=>array(1,2,3)
								   ,'ajax_list'=>array(1,2,3)
								   ,'get_product'=>array(1,2,3)
								   ,'view_data'=>array(1,2,3)
								)
								,'index' => array(
								   'index'=>array(1,2,3,4)
								   ,'logout'=>array(1,2,3,4)
								   ,'forgotpassword'=>array(1,2,3,4)
								)
								,'dashboard' => array(
								   'index'=>array(1,2,3)
								)
							    ,'displayproduct' => array(
								   'index'=>array(1,2,3)
								   ,'ajax_list'=>array(1,2,3)
								   ,'get_product'=>array(1,2,3)
								   ,'view_data'=>array(1,2,3)
								   ,'approve_data'=>array(1,2,3)
							    )
							    ,'empattendence' => array(
								   'index'=>array(1,2,3)
								   ,'ajax_list'=>array(1,2,3)
								   ,'view_data'=>array(1,2,3)
							    )
							    ,'product' => array(
								   'index'=>array(1,2,3)
								   ,'ajax_list'=>array(1,2,3)
								   ,'add'=>array(1,2,3)
								   ,'edit'=>array(1,2,3)
								   ,'delete'=>array(1,2,3)
								   ,'get_subcat_edit'=>array(1,2,3)
								   ,'get_subcat'=>array(1,2,3)
								)
								,'reports' => array(
								   'index'=>array(1,2,3)
								   ,'get_branch'=>array(1,2,3)
								   ,'generate_report'=>array(1,2,3)
								)
								,'store' => array(
								   'index'=>array(1,2,3)
								   ,'ajax_list'=>array(1,2,3)
								   ,'add'=>array(1,2,3)
								   ,'edit'=>array(1,2,3)
								   ,'delete'=>array(1,2,3)
								)
								,'storebranch' => array(
								   'index'=>array(1,2,3)
								   ,'ajax_branch_list'=>array(1,2,3)
								   ,'branch'=>array(1,2,3)
								   ,'add'=>array(1,2,3)
								   ,'edit'=>array(1,2,3)
								   ,'delete'=>array(1,2,3)
								)
								,'storeemp' => array(
								   'index'=>array(1,2,3)
								   ,'get_branch'=>array(1,2,3)
								   ,'assign_emp'=>array(1,2,3)
								   ,'ajax_list'=>array(1,2,3)
								   ,'delete'=>array(1,2,3)
								)
								,'storeproduct' => array(
								   'index'=>array(1,2,3)
								   ,'get_branch'=>array(1,2,3)
								   ,'assign_product'=>array(1,2,3)
								   ,'ajax_list'=>array(1,2,3)
								   ,'add'=>array(1,2,3)
								   ,'edit'=>array(1,2,3)
								   ,'delete'=>array(1,2,3)
								)

							);

/* End of file acl.php */
/* Location: ./application/config/acl.php */
