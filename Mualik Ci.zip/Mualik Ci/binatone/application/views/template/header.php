<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Store Sales</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- bootstrap 3.0.2 -->
        <link href="<?=public_path()?>css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="<?=public_path()?>css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Ionicons -->
        <link href="<?=public_path()?>css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <!-- Morris chart -->
        <!--  link href="<?=public_path()?>css/morris/morris.css" rel="stylesheet" type="text/css" /-->
        <!-- jvectormap -->
        <link href="<?=public_path()?>css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
        <!-- fullCalendar -->
        <link href="<?=public_path()?>css/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css" />
		<!-- datatable -->
        <link href="<?=public_path()?>css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
        <!-- Daterange picker -->
       <link href="<?=public_path()?>css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" /> 
        <link href="<?=public_path()?>css/datepicker/datepicker.css" rel="stylesheet" type="text/css" />
       <!--  <link href="//192.168.100.171/bookmytrip\public/global/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet" type="text/css"/>-->       
        <link href="<?=public_path()?>css/bootstrap-datetimepicker/bootstrap-datetimepicker.min.css" rel="stylesheet" type="text/css" />      
        <!-- bootstrap wysihtml5 - text editor -->
        <link href="<?=public_path()?>css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
        <!-- bootstrap Validator -->
        <link href="<?=public_path()?>css/bootstrapValidator.css" rel="stylesheet" type="text/css" />        
		<!-- custom styles -->
        <link href="<?=public_path()?>css/custom.css" rel="stylesheet" type="text/css" />  
        <link href="<?=public_path()?>js/image_crop/components/imgareaselect/css/imgareaselect-default.css" rel="stylesheet" type="text/css" />  
        <link href="<?=public_path()?>js/image_crop/css/jquery.awesome-cropper.css" rel="stylesheet" type="text/css" />  

		<?php if ($this->router->fetch_class() == "deal") { ?>
			<link href="<?=public_path()?>css/tagedit/jquery.tagedit.css" rel="stylesheet" type="text/css" />
		<?php } ?>

        <!-- Theme style -->
        <link href="<?=public_path()?>css/AdminLTE.css" rel="stylesheet" type="text/css" />
		<link href="<?=public_path()?>css/admin/main.css" rel="stylesheet" type="text/css" />
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
        <link href="<?=public_path()?>css/jQueryUI/jquery-ui.css" rel="stylesheet" type="text/css" />
        <script src="<?=public_path()?>js/jquery.2.0.2.min.js"></script>		
    </head>
