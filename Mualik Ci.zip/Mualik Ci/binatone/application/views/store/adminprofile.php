<section class="content-header">
    <h1>
        <?= translate('ADMIN_MASTER_PROFILE') ?>
    </h1>
    <?php
		//$this->load->view("template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">
    	<div class="col-md-12">
    		<div id="flash_msg">
			</div>
			<?php //if(accessControl('users','add',$this->user_session['role'])){ ?>
    		<!-- <a class="btn btn-default pull-right" href="<?php echo base_path()?>adminmaster/adminprofileedit">
            <i class="fa fa-plus"></i>&nbsp;<?= translate('ADMIN_BUTTON_PROFILE_EDIT') ?></a> -->
			<?php //} ?>
            <div id="list">
				<div class="box">
					<div class="box-header">
						<h3 class="box-title"><?= translate('ADMIN_LABLE_MASTER_PROFILE') ?></h3>                                    
					</div><!-- /.box-header -->
					<div class="box-body table-responsive">
					<table>
						<tr>
							<th>User Name:</th>
							<td><?php echo $user[0]->UserName; ?></td>
						</tr>
						<tr>
							<th>Role:</th> 
							<td><?php echo $user[0]->Role; ?></td>						
						</tr>
						<tr>
							<th>Email Id1:</th> 
							<td><?php echo $user[0]->Email1; ?></td>
						</tr>	
						<tr>
							<th>Email Id2:</th> 
							<td><?php echo $user[0]->Email2; ?></td>
						</tr>
						<tr>
							<th>Mobile Number1:</th> 
							<td><?php echo $user[0]->Mobile1; ?></td>
						</tr>
						<tr>
							<th>Mobile Number2:</th> 
							<td><?php echo $user[0]->Mobile2; ?></td>
						</tr>
					</table>
					</div><!-- /.box-body -->
				</div><!-- /.box -->
			</div>
    	</div>
    </div>
</section>