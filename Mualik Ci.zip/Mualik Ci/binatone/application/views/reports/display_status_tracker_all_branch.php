<?php 
//load our new PHPExcel library
$this->load->library('excel');
//activate worksheet number 1
$sheet=0;
foreach ($data[1] as $key => $value) {
$objWorkSheet = $this->excel->createSheet($sheet);
$this->excel->setActiveSheetIndex($sheet);
//name the worksheet
$this->excel->getActiveSheet()->setTitle($key);
//set cell A1 content with some text

$this->excel->getActiveSheet()
    ->getStyle('B2:C2')
    ->getFill()
    ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
    ->getStartColor()
    ->setARGB('32CD32');
$this->excel->getActiveSheet()
    ->getStyle('D2:E2')
    ->getFill()
    ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
    ->getStartColor()
    ->setARGB('FFA500');
$this->excel->getActiveSheet()
    ->getStyle('F2:G2')
    ->getFill()
    ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
    ->getStartColor()
    ->setARGB('B4ABAB');
$this->excel->getActiveSheet()
    ->getStyle('H2:I2')
    ->getFill()
    ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
    ->getStartColor()
    ->setARGB('88FFEA');
$this->excel->getActiveSheet()
    ->getStyle('J2:K2')
    ->getFill()
    ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
    ->getStartColor()
    ->setARGB('9CE599');
$styleArray = array(
  'borders' => array(
    'allborders' => array(
      'style' => PHPExcel_Style_Border::BORDER_THIN
    )
  )
);

$this->excel->getActiveSheet()->getStyle('A2:K2')->applyFromArray($styleArray);
unset($styleArray);
$this->excel->getActiveSheet()->getStyle('A2:K2')->getAlignment()->setWrapText(true);
$this->excel->getActiveSheet()->getStyle('B2:K2')->getFont()->setSize(9);
$this->excel->getActiveSheet()->getStyle('A2')->getFont()->setBold(true);
$this->excel->getActiveSheet()->getStyle('A2:K2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$this->excel->getActiveSheet()->getStyle('A2:K2')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$this->excel->getActiveSheet()->setCellValue('B2', '_/');
$this->excel->getActiveSheet()->setCellValue('C2', 'Displayed');
$this->excel->getActiveSheet()->setCellValue('D2', 'X');
$this->excel->getActiveSheet()->setCellValue('E2', 'Not Listed');
$this->excel->getActiveSheet()->setCellValue('F2', 'O');
$this->excel->getActiveSheet()->setCellValue('G2', 'Listed Stocked but not Displayed');
$this->excel->getActiveSheet()->setCellValue('H2', 'S');
$this->excel->getActiveSheet()->setCellValue('I2', 'Listed but no Stocks');
$this->excel->getActiveSheet()->setCellValue('J2', 'N');
$this->excel->getActiveSheet()->setCellValue('K2', 'Product not yet launched');
$this->excel->getActiveSheet()->setCellValue('A4', 'Model');
$this->excel->getActiveSheet()->getStyle("A4:AE4")->getFont()->setBold(true);
$this->excel->getActiveSheet()->setCellValue('A2', $key);
$this->excel->getActiveSheet()->getColumnDimension('A')->setWidth(28);
$this->excel->getActiveSheet()->getRowDimension('2')->setRowHeight(40);
$this->excel->getActiveSheet()->fromArray($data[0], NULL, 'B4');
$qty=array();

$val="";
$val1="";
$colcount=5;
foreach ($value as $key3 => $value3) {
	$product=array();
	$product[]=$key3;
	foreach ($data[0] as $key1 => $value1) {
		//echo $value1;
		$val="";
		foreach ($value3 as $key2 => $value2) {
			//echo $key2;
			if($key2==$value1 && isset($value2)){
				//echo $value2.'<br>';	
				//$val=$value2;
				if($value2=='Displayed'){
					$val='_/';
				}
				if($value2=='Not Listed'){
					$val='X';
				}
				if($value2=='Listed Stocked but not Displayed'){
					$val='O';
				}
				if($value2=='Listed but no Stocks'){
					$val='S';
				}
				if($value2=='Product not yet launched'){
					$val='N';
				}
			}else{
				$val1=0;
			}
			
		}
		if(isset($val)){
			$product[]=$val;
		}else{
			$product[]=$val1;
		}
	}
	$this->excel->getActiveSheet()->fromArray($product, NULL, 'A'.$colcount);
	$colcount++;
	
}
$sheet++;
}

// foreach ($data[0] as $key => $value) {
	
// }
//exit;
//echo "<pre>";print_r($product);exit;
//$this->excel->getActiveSheet()->fromArray($data, NULL, 'C6');
/*$row=6;
for($i=0;$i<50;$i++){
 $this->excel->getActiveSheet()->setCellValue('A'.$row, 'My Value'.$row);
 $row++;
}*/


$filename='Display Status Tracker.xlsx'; //save our workbook as this file name
	ob_end_clean();		
 header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename='.$filename.'');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($this->excel,'Excel2007');

$objWriter->save('php://output');
?>