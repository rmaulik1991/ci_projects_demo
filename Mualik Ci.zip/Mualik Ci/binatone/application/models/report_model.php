<?php
class report_model extends CI_Model{
	var $table;
	public function  __construct(){
		parent::__construct();
		$this->load->database();
		//$this->table ='admin_master';
	}


	public function selectSalesData($where,$start_date,$end_date)
	{
		$query = $this->db->select('sp.product_name,sdst.qty,sdst.added_date,se.first_name,ssb.branch_name,st.store_name')
            ->from('sts_store_product_int as sspi', 'left')
            ->join('sts_product as sp', 'sp.id=sspi.sts_product_id','left')
            ->join('sts_daily_sales_tracker as sdst', 'sspi.sts_product_id=sdst.sts_product_id and sdst.added_date BETWEEN "'.$start_date.'" AND "'.$end_date.'"', 'left')
            ->join('sts_store_employee_int as ssei', 'ssei.sts_branch_id=sdst.sts_store_branch_id and ssei.status="Active"', 'left')
            ->join('sts_employee as se', 'ssei.sts_employee_id=se.id', 'left')
            ->join('sts_store_branch as ssb', 'ssei.sts_branch_id=ssb.id','left')
            ->join('sts_store as st', 'ssb.sts_store_id=st.id','left')
            ->where("ssb.sts_store_id",$where)
            //->where("sdst.added_date >=",'2017-11-01')
            //->where("sdst.added_date <=",'2017-11-30')
            ->order_by('sdst.added_date','ASC')
            ->get();
		$query = $query->result_array();
		$date=array();
		$pro=array();
		$branch_name=array();
		$name=array();
		$i=0;
		
		$date_from = strtotime($start_date);  
		$date_to = strtotime($end_date);
		$j=1;  
		for ($i=$date_from; $i<=$date_to; $i+=86400) {  
		    $date[$j]= date("M d", $i); 
		    $j++; 
		} 
		/*$days=cal_days_in_month(CAL_GREGORIAN,date('m' ,strtotime('2017/11/01')),date('Y' ,strtotime('2017/11/01')));
		for($i=1;$i<=$days;$i++){
			$date[$i]=date('M d',strtotime('2017/11/'.$i)) ;
		}*/
		
		foreach ($query as $key => $value) {
			//$date[$i++]=date('M d' ,strtotime($value['added_date']));
			$pro[$value['branch_name']][$value['product_name']][date('M d' ,strtotime($value['added_date']))]=$value['qty'];
			$name[$value['branch_name']]=$value['first_name'];
			$store_name=$value['store_name'];
			if(isset($value['branch_name']) && !empty($value['branch_name'])){
			$branch_name[$value['branch_name']]=$value['branch_name'];
			}
			$monthdate=date('M/Y',strtotime($start_date));
		}
		$detail=array($name,"monthdate"=>$monthdate,"store_name"=>$store_name);
		$data=array(0=>$date,1=>$pro,2=>$detail,3=>$branch_name);
		 return $data;
	}

	public function selectSalesDatasingle($where,$start_date,$end_date)
	{
		$query = $this->db->select('sp.product_name,sdst.qty,sdst.added_date,se.first_name,ssb.branch_name')
            ->from('sts_store_product_int as sspi', 'left')
            ->join('sts_product as sp', 'sp.id=sspi.sts_product_id', 'left')
            ->join('sts_daily_sales_tracker as sdst', 'sspi.sts_product_id=sdst.sts_product_id and sdst.added_date BETWEEN "'.$start_date.'" AND "'.$end_date.'" and sdst.sts_store_branch_id="'.$where.'"', 'left')
            ->join('sts_store_employee_int as ssei', 'ssei.sts_branch_id=sdst.sts_store_branch_id and ssei.status="Active"', 'left')
            ->join('sts_employee as se', 'ssei.sts_employee_id=se.id', 'left')
            ->join('sts_store_branch as ssb', 'sdst.sts_store_branch_id=ssb.id','left')
            ->where("sspi.sts_branch_id",$where)
            //->where("sdst.added_date >=",'2017-11-01')
            //->where("sdst.added_date <=",'2017-11-30')
            ->order_by('sdst.added_date','ASC')
            ->get();
           // echo $this->db->last_query();exit;
		$query = $query->result_array();
		$date=array();
		$pro=array();
		$i=0;
		//echo "<pre>";cal_days_in_month(CAL_GREGORIAN,date('m' ,strtotime('2017/11/01')),date('Y' ,strtotime('2017/11/01'))); 
		$date_from = strtotime($start_date);  
		$date_to = strtotime($end_date);
		$j=1;  
		for ($i=$date_from; $i<=$date_to; $i+=86400) {  
		    $date[$j]= date("M d", $i); 
		    $j++; 
		} 
		//exit();
		/*//$days=cal_days_in_month(CAL_GREGORIAN,date('m' ,strtotime($start_date)),date('Y' ,strtotime($end_date)));
		for($i=1;$i<=$days;$i++){
			$date[$i]=date('M d',strtotime(''.$y.'/'.$m.'/'.$i.'')) ;
		}*/
		//print_r($date);exit;
		foreach ($query as $key => $value) {
			//$date[$i++]=date('M d' ,strtotime($value['added_date']));
			$pro[$value['product_name']][date('M d' ,strtotime($value['added_date']))]=$value['qty'];
			$name=$value['first_name'];
			$branch_name=$value['branch_name'];
			$monthdate=date('M/Y',strtotime($start_date));
		}
		//print_r($pro);
		//exit;
		$detail=array("name"=>$name,"branch_name"=>$branch_name,"monthdate"=>$monthdate);
		$data=array(0=>$date,1=>$pro,2=>$detail);

		 return $data;
	}

	public function selectDisplayData($where,$start_date,$end_date)
	{
		$query = $this->db->select('sp.product_name,sds.name,sdt.added_date,se.first_name,ssb.branch_name')
            ->from('sts_store_product_int as sspi', 'left')
            ->join('sts_product as sp', 'sp.id=sspi.sts_product_id', 'left')
            ->join('sts_display_tracker as sdt', 'sspi.sts_product_id=sdt.sts_product_id and sdt.added_date BETWEEN "'.$start_date.'" AND "'.$end_date.'" and sdt.sts_store_branch_id="'.$where.'"', 'left')
            ->join('sts_store_employee_int as ssei', 'ssei.sts_branch_id=sdt.sts_store_branch_id and ssei.status="Active"', 'left')
            ->join('sts_display_status as sds', 'sdt.sts_display_status_id=sds.id and ssei.status="Active"', 'left')
            ->join('sts_employee as se', 'ssei.sts_employee_id=se.id', 'left')
            ->join('sts_store_branch as ssb', 'sdt.sts_store_branch_id=ssb.id','left')
            ->where("sspi.sts_branch_id",$where)
            ->order_by('sdt.added_date','ASC')
            ->get();
           // echo $this->db->last_query();exit;
		$query = $query->result_array();
		$date=array();
		$pro=array();
		$i=0;
		//echo "<pre>";cal_days_in_month(CAL_GREGORIAN,date('m' ,strtotime('2017/11/01')),date('Y' ,strtotime('2017/11/01')));
		/*$days=cal_days_in_month(CAL_GREGORIAN,date('m' ,strtotime('2017/11/01')),date('Y' ,strtotime('2017/11/01')));
		for($i=1;$i<=$days;$i++){
			$date[$i]=date('M d',strtotime('2017/11/'.$i)) ;
		}*/
		$date_from = strtotime($start_date);  
		$date_to = strtotime($end_date);
		$j=1;  
		for ($i=$date_from; $i<=$date_to; $i+=86400) {  
		    $date[$j]= date("M d", $i); 
		    $j++; 
		}
		//print_r($date);exit;
		foreach ($query as $key => $value) {
			//$date[$i++]=date('M d' ,strtotime($value['added_date']));
			$pro[$value['product_name']][date('M d' ,strtotime($value['added_date']))]=$value['name'];
			$name=$value['first_name'];
			$branch_name=$value['branch_name'];
			$monthdate=date('M/Y',strtotime($start_date));
		}
		//print_r($pro);
		//exit;
		$detail=array("name"=>$name,"branch_name"=>$branch_name,"monthdate"=>$monthdate);
		$data=array(0=>$date,1=>$pro,2=>$detail);
		//print_r($pro);
		//exit;
		
		//$data = $query->result();
		// }

		// #echo "<pre>"; print_r($this->db->queries); exit;
		// $query->result();

		 return $data;
	}

	public function selectDisplayDataAll($where,$start_date,$end_date)
	{
		$query = $this->db->select('sp.product_name,sdt.added_date,ssb.branch_name,sds.name,st.store_name')
            ->from('sts_display_tracker as sdt')
            ->join('sts_store_product_int as sspi', 'sdt.sts_product_id = sspi.sts_product_id and sdt.sts_store_branch_id=sspi.sts_branch_id', 'left')
            ->join('sts_product as sp','sspi.sts_product_id=sp.id','left')
            ->join('sts_store_branch as ssb', 'sdt.sts_store_branch_id=ssb.id')
            ->join('sts_display_status as sds', 'sdt.sts_display_status_id = sds.id', 'left')
            ->join('sts_store as st', 'ssb.sts_store_id=st.id', 'left')
            ->where("sdt.added_date >=",$start_date)
            ->where("sdt.added_date <=",$end_date)
            ->where("st.id",$where)
            ->order_by('sdt.added_date','ASC')
            ->get();
           //echo $this->db->last_query();exit;
         //$query=$this->db->query($sql);
		$query = $query->result_array();
		$date=array();
		$pro=array();
		$i=0;
		//echo "<pre>";cal_days_in_month(CAL_GREGORIAN,date('m' ,strtotime('2017/11/01')),date('Y' ,strtotime('2017/11/01')));
		/*$days=cal_days_in_month(CAL_GREGORIAN,date('m' ,strtotime('2017/11/01')),date('Y' ,strtotime('2017/11/01')));
		for($i=1;$i<=$days;$i++){
			$date[$i]=date('M d',strtotime('2017/11/'.$i)) ;
		}*/
		$date_from = strtotime($start_date);  
		$date_to = strtotime($end_date);
		$j=1;  
		for ($i=$date_from; $i<=$date_to; $i+=86400) {  
		    $date[$j]= date("M d", $i); 
		    $j++; 
		}
		//print_r($date);exit;
		foreach ($query as $key => $value) {
			//$date[$i++]=date('M d' ,strtotime($value['added_date']));
			$pro[$value['branch_name']][$value['product_name']][date('M d' ,strtotime($value['added_date']))]=$value['name'];
			$branch_name[$value['branch_name']]=$value['branch_name'];
			$monthdate=date('M/Y',strtotime($start_date));
		}
		
		$detail=array("monthdate"=>$monthdate);
		$data=array(0=>$date,1=>$pro,2=>$detail,3=>$branch_name);
		

		 return $data;
	}

	public function selectWeeklySalesData($where,$start_date,$end_date)
	{
		$query = $this->db->select('ss.store_name,stb.branch_name,sc.category_name,sp.product_name,sum(sdst.qty) as qty,sdst.added_date')
            ->from('sts_daily_sales_tracker as sdst')
            ->join('sts_product as sp', 'sdst.sts_product_id=sp.id','left')
            ->join('sts_category as sc', 'sc.id=sp.sts_category_id','left')
            ->join('sts_store_branch as stb', 'sdst.sts_store_branch_id=stb.id', 'left')
           // ->join('sts_employee as se', 'ssei.sts_employee_id=se.id', 'left')
            //->join('sts_store_branch as ssb', 'sdst.sts_store_branch_id=ssb.id','left')
            ->join('sts_store as ss', 'stb.sts_store_id=ss.id','left')
           // ->join('sts_store_branch as ssb', 'sdst.sts_store_branch_id=ssb.id','left')
           // ->join('sts_store as ss', 'ssb.sts_store_id= ss.id','left')
            ->where("sdst.added_date BETWEEN '".$start_date."' AND '".$end_date."'")
            ->where("ss.id",$where)
            //->where("sspi.sts_branch_id",$where)
            //->where("sdst.added_date >=",'2017-11-01')
            //->where("sdst.added_date <=",'2017-11-30')
            ->group_by('sdst.added_date')
            ->group_by('sdst.sts_store_branch_id')
            ->group_by('sc.category_name')
            ->order_by('sdst.added_date','ASC')
            ->get();

        //echo $this->db->last_query();exit;
        $query = $query->result_array();
		$date=array();
		$category=array();
		$i=0;
		/*$days=cal_days_in_month(CAL_GREGORIAN,date('m' ,strtotime('2017/11/01')),date('Y' ,strtotime('2017/11/01')));
		for($i=1;$i<=$days;$i++){
			$date[$i]=date('Y-m-d',strtotime('2017/11/'.$i)) ;
		}*/
		$date_from = strtotime($start_date);  
		$date_to = strtotime($end_date);
		$j=1;  
		for ($i=$date_from; $i<=$date_to; $i+=86400) {  
		    $date[$j]= date("Y-m-d", $i); 
		    $j++; 
		}
		//echo "<pre>";
		//print_r($query);exit;
		$data=array();
		if(isset($query) && !empty($query)){
			foreach ($query as $key => $value) {
					
				//$category[$value['branch_name']][$value['category_name']][date('Y-m-d' ,strtotime($value['added_date']))]=$value['qty'];
				$store_name=$value['store_name'];
				//$category_name[$value['category_name']]=$value['category_name'];
				$category_name[$value['category_name']]=$value['category_name'];
				$branch_name1[$value['branch_name']]=$value['branch_name'];
			}
			foreach ($branch_name1 as $key => $value) {
				foreach ($category_name as $key1 => $value1) {
					$branch_name[$key][$key1]="";
				}
			}
				
			foreach ($query as $key => $value) {
				foreach ($branch_name as $key1 => $value1) {
					$branch_name[$value['branch_name']][$value['category_name']][date('Y-m-d' ,strtotime($value['added_date']))]=$value['qty'];	
				}
				
				//$store_name=$value['store_name'];
				//$category_name[$value['category_name']]=$value['category_name'];
				//$category_name[$value['category_name']]=$value['category_name'];
			//	$branch_name1[$value['branch_name']]=$value['branch_name'];
			}
			//echo "<pre>";
			//print_r($branch_name);exit;
			// foreach ($query as $key => $value) {
			// 	foreach ($category_name as $key1 => $value1) {
			// 		$category[$value['branch_name']][$value1][date('Y-m-d' ,strtotime($value['added_date']))]=$value['qty'];
					
			// 	}
			// }

		//	print_r($category);
			//exit;
			
			$data=array(0=>$branch_name,1=>$date,2=>$store_name,3=>$category_name);
			
			//echo "<pre>";
		//	print_r($data);exit;
			return $data;
		}

		
	}

}