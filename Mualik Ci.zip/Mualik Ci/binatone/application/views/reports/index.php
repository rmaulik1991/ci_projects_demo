<section class="content-header">
    <h1>
        <?= translate('STORE_PRODUCT_TITLE') ?>
    </h1>
    <?php
		$this->load->view("template/bread_crumb");
	?>
</section>
<section class="content">
	<div class="row">
    	<div class="col-md-12">
            <form action="<?php echo base_path()?>reports/generate_report" id="reportFrm" method="post">
    		<div class="row">
    			<div class="col-md-3"></div>
			    	<div class="col-md-4">
						<div class="form-group">
                        <?php echo form_label('Report Name:');?>
                        <select class="form-control" name="report_name" id="report_name">
                            <option value="">Select</option>
                            <option value="daily_sales">Daily Sales Tracker</option>
                            <option value="display_tracker">Display Tracker</option>
                            <option value="weekly_sales_tracker">Merchandisers weekly sales Tracker</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
    			<div class="col-md-3"></div>
			    	<div class="col-md-4">
						<div class="form-group">
                        <?php echo form_label('Store Name:');?>
                        <select class="form-control" name="store_name" id="store_name" onchange="get_branch();">
                            <option value="">Select</option>
                            <?php foreach($store_list as $row){ ?>
                            <option value="<?php echo $row->id; ?>"><?php echo $row->store_name; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row" id="branch_select">
    			<div class="col-md-3"></div>
			    	<div class="col-md-4">
				<div class="form-group">
                        <?php echo form_label('Branch Name:');?>
                        <select class="form-control" name="branch_name" id="branch_name">
                            <option value="">Select</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
    			<div class="col-md-3"></div>
			    	<div class="col-md-4">
			         <div class="form-group">
                    <label>Select Date :</label>
                    <div class="input-group">
                        <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
                        <input type="text" class="form-control pull-right" id="daterange" value="<?php echo date('m/01/Y').' - '.date('m/d/Y');?>" name="daterange">
                    </div></div>
                    <div class="form-group">
                        <button class="btn btn-primary btn-flat" type="submit" >Submit</button>
                        <a href="<?=base_url()?>reports/" class="btn btn-defauly btn-flat">Cancel</a>
                    </div> 
                </div>
            </div>
            
    		<div id="flash_msg">
			</div>
			</form>
    	</div>
    </div>
</section>
<script type="text/javascript">
$(function() {
    $('input[name="daterange"]').daterangepicker({
        timePicker: false,
        maxDate: new Date(),
        locale: {
            format: 'DD/MM/YYYY'
        }
    });
});

$( "#report_name" ).change(function() {
  if($('#report_name').val()=='weekly_sales_tracker'){
  	$('#branch_select').hide();
  }
  else{
  	$('#branch_select').show();
  }
});
</script>