var oTable;
$(document).ready(function() {

    $("#RequestDate").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
    $('#RequestDate').datepicker({ format: 'dd/mm/yyyy' });
    
    $("#extend_request_date").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
    $('#extend_request_date').datepicker({ format: 'dd/mm/yyyy' });

    $("#eodc_discharge_date").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
    $('#eodc_discharge_date').datepicker({ format: 'dd/mm/yyyy' });

    $("#eodc_apply_date").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
	$('#eodc_apply_date').datepicker({ format: 'dd/mm/yyyy' });

    $("#installation_date").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
    $('#installation_date').datepicker({ format: 'dd/mm/yyyy' });   


    $('#RequestDate').on('changeDate', function(e) {
            $(this).datepicker('hide');
        });

     $('#IssueDate').on('changeDate', function(e) {
            getexpirydate();
            $(this).datepicker('hide');
        });

    $('#extend_request_date').on('changeDate', function(e) {
            $(this).datepicker('hide');
        });

    $('#eodc_discharge_date').on('changeDate', function(e) {
            $(this).datepicker('hide');
        });

    $('#eodc_apply_date').on('changeDate', function(e) {
            $(this).datepicker('hide');
        });

    $('#installation_date').on('changeDate', function(e) {
            $(this).datepicker('hide');
        });

	oTable = $('#customer_serviceTable').dataTable( {
		"processing": true,
		"serverSide": true,
		"ajax": {
			"url": base_path()+'customerservice/ajax_list/',
			"type": "POST"
		},
		aoColumnDefs: [
		  {
			 bSortable: false,
			 aTargets: [ -1 ]
		  }
		]
	} );
       
        /*$('#RequestDate')
        .datepicker({
           // format: 'mm/dd/yyyy'
        })
        .on('changeDate', function(e) {
            // Revalidate the date field
            $('#customerServiceFrm').bootstrapValidator('revalidateField', 'RequestDate');
        });*/
      /*  $('#RequestDate').on('changeDate show', function(e) {
            $('#customerServiceFrm').bootstrapValidator('revalidateField', 'RequestDate');
        });

         $('#IssueDate').on('changeDate show', function(e) {
            $('#customerServiceFrm').bootstrapValidator('revalidateField', 'IssueDate');
        });

          $('#ExpiryDate').on('changeDate show', function(e) {
            $('#customerServiceFrm').bootstrapValidator('revalidateField', 'ExpiryDate');
        });
	*/


	$('#customerServiceFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		 fields: {

            LicenceNo: {
                message: 'The role is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Email address is required and cannot be empty'
                    }
                }
            },
            Customer_id: {
                message: 'The role is not valid',
                validators: {
                    notEmpty: {
                        message: 'The role is required and cannot be empty'
                    }
                }
            },			
			Service_id: {
                message: 'The role is not valid',
                validators: {
                    notEmpty: {
                        message: 'The role is required and cannot be empty'
                    }
                }
            },
            RequestDate: {
                 validators: {
                 notEmpty: {
                   message: 'The Apply Date is required and cannot be empty'
                 }
               }
            },
            IssueDate: {
                message: 'The Issue Date is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Issue Date is required and cannot be empty'
                    }                   
                }
            },
            token_validity: {
                message: 'Must select token validity',
                validators: {
                    notEmpty: {
                        message: 'Must select token validity'
                    }
                }
            },
            token: {
                message: 'The token is not valid',
                validators: {
                    notEmpty: {
                        message: 'The token is required and cannot be empty'
                    }
                }
            }
		 }
    });
} );

function delete_admin (del_id) {
    
bootbox.confirm("Are you sure to delete user?", function(result) {
	if(result){
	startLoading();
	$.ajax({
		type: 'post',
		url: base_path()+'customerservice/delete',
		data: 'id='+del_id,
		success: function (data) {
			if (data == "success") {
				oTable.fnClearTable(0);
				oTable.fnDraw();
				$("#flash_msg").html(success_msg_box ('Customer Service Relation deleted successfully.'));
			}else{
				$("#flash_msg").html(error_msg_box ('An error occurred while processing.'));
			}
			stopLoading();
		}
	});
	}
	});
}