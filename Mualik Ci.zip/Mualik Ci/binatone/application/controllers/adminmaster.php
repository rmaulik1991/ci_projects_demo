<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require ("common/Index_Controller.php");

class Adminmaster extends Index_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('adminmaster_model');
		$this->user_session = $this->session->userdata('user_session');
		is_login();
	}

	public function index() {	
		$data['flash_msg'] = $this->msg_session;		
		$data['view'] = "index";
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');
	}

	public function ajax_list($limit=0) {
		$post = $this->input->post();
		$columns = array(
			array( 'db' => 'username', 'dt' => 0 ,'formatter' => function( $d, $row )
					{
						return '<a href="'.site_url('/adminmaster/edit/'.$row['Id']).'" >'.$row['username'].'</a>';
					},'field' => 'username'),			
			array( 'db' => 'contact_number',  'dt' => 1,'field' => 'contact_number' ),
			array( 'db' => 'email',  'dt' => 2,'field' => 'email' ),
			array( 'db' => 'rm.role_name','dt'=> 3,'field' => 'role_name' ),
			array( 'db' => 'Id',
					'dt' => 4,
					'formatter' => function( $d, $row ) {
						return '<a href="javascript:void(0);" onclick="delete_admin('.$d.')" class="fa fa-trash-o"></a>';
					},'field' => 'Id'
			),
		);
		$join1 = array(ROLE_MASTER.' as rm','rm.role_id = emp.sts_role_id');
		echo json_encode( SSP::simple( $post, EMPLOYEE.' as emp', "emp.Id", $columns, array($join1), "emp.status !='Inactive' AND emp.id != ".$this->session->userdata('user_session')['id'] ) );
		exit;
	}

	public function add() {
		$post = $this->input->post();
		if ($post) {			
			$is_unique_username = $this->adminmaster_model->isUnique(EMPLOYEE, 'username', trim($post['username']));						
			
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('<label class="form-error-msg"><i class="fa fa-times-circle-o"></i>', '</label><br/>');
			$this->form_validation->set_rules('username', 'Username', 'trim|required|alpha_dash|min_length[5]|max_length[12]');
			$this->form_validation->set_rules('email', 'Email Address', 'trim|required|valid_email');
			$this->form_validation->set_rules('contact_number', 'Contact no', 'trim|required|numeric|min_length[10]|max_length[10]');
			$this->form_validation->set_rules('role', 'Role', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			$this->form_validation->set_rules('address', 'Address', 'trim|required');
			$this->form_validation->set_rules('password', 'Password', 'trim|required|matches[re_password]');
			$this->form_validation->set_rules('re_password', 'Repeat Password', 'required');
			
			if ($this->form_validation->run()) {				
				if (!$is_unique_username) {
					$flash_arr = array('flash_type' => 'error',
							'flash_msg' => 'User name already exists.'
					);					
				} 				
				else {
					$data=array('first_name'=>$post['fname']
								,'last_name'=>$post['lname']
								,'sts_role_id'=>$post['role']
								,'email'=>$post['email']
								,'contact_number'=>$post['contact_number']
								,'address'=>$post['address']								
								,'username'=>$post['username']
								,'status' => $post['status']
						);
					
					$data['password'] = sha1(trim($post['password']));
					$ret = $this->adminmaster_model->insertData(EMPLOYEE, $data);
					
					if ($ret > 0) {						
						$flash_arr = array('flash_type' => 'success',
										'flash_msg' => 'Admin added successfully.'
									);
					}else{
						$flash_arr = array('flash_type' => 'error',
										'flash_msg' => 'An error occurred while processing.'
									);
					}
					$this->session->set_userdata('msg_session',$flash_arr);
					redirect("adminmaster/index");
				}
				$this->session->set_userdata('msg_session',$flash_arr);
			}
			$post=(object)$post;
			$data['admin']=array('0'=>$post);
		}
		$data['role_list']=$this->adminmaster_model->selectRoleData(ROLE_MASTER);
		$data['flash_msg'] = $this->msg_session;
		$data['view'] = "add_edit";
		$data['current_view'] = "add";
		$data['user_role'] = $this->user_session['role'];
		$this->load->view('content', $data);
	}
	
	public function edit($id) {
		if ($id == "" || $id <= 0) {
			redirect('adminmaster');
		}

		$where = 'id = '.$id;
		$is_error=0;
		$post = $this->input->post();
		
		if ($post) {			
			$is_unique_username = $this->adminmaster_model->isUnique(EMPLOYEE, 'username', trim($post['username']),$id);						
			$this->load->library('form_validation');
			$this->form_validation->set_error_delimiters('<label class="form-error-msg"><i class="fa fa-times-circle-o"></i>', '</label><br/>');
			$this->form_validation->set_rules('username', 'Username', 'trim|required|alpha_dash|min_length[5]|max_length[12]');
			$this->form_validation->set_rules('email', 'Email Address', 'trim|required|valid_email');
			$this->form_validation->set_rules('contact_number', 'Contact no', 'trim|required|numeric|min_length[10]|max_length[10]');
			$this->form_validation->set_rules('role', 'Role', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			$this->form_validation->set_rules('address', 'Address', 'trim|required');
			
			
			if ($this->form_validation->run()) {				
				if (!$is_unique_username) {
					$flash_arr = array('flash_type' => 'error',
							'flash_msg' => 'User name already exists.'
					);
					$is_error=1;
				} 				
				else
				{

				$data=array('first_name'=>$post['fname']
								,'last_name'=>$post['lname']
								,'sts_role_id'=>$post['role']
								,'email'=>$post['email']
								,'contact_number'=>$post['contact_number']
								,'address'=>$post['address']								
								,'username'=>$post['username']
								,'status' => $post['status']
						);
					$data['password'] = sha1(trim($post['password']));
					$ret = $this->adminmaster_model->updateData(EMPLOYEE, $data, $where);

				if ($ret > 0) {
					$flash_arr = array('flash_type' => 'success',
										'flash_msg' => 'Admin updated successfully.'
									);
				}else{
					$flash_arr = array('flash_type' => 'error',
										'flash_msg' => 'An error occurred while processing.'
									);
				}
				$this->session->set_userdata('msg_session',$flash_arr);
				redirect("adminmaster");
				}
			$this->session->set_userdata('msg_session',$flash_arr);
			}
		}
		$data['role_list']=$this->adminmaster_model->selectRoleData(ROLE_MASTER);
		$data['user'] = $user = $this->adminmaster_model->selectData(EMPLOYEE, '*', $where);
		
		if (empty($user)) {
			redirect('adminmaster/index');
		}
		$data['flash_msg'] = $this->msg_session;
		$data['view'] = "add_edit";
		$data['current_view'] = "edit";
		$this->load->view('content', $data);
		$this->session->set_userdata('msg_session','');		
	}

	public function delete() {
		$post = $this->input->post();
		$data=array("status"=>"Inactive");

		if ($post) {
			$ret = $this->adminmaster_model->updateData(EMPLOYEE, $data,array('Id' => $post['id'] ));
			//$ret = $this->adminmaster_model->deleteData(EMPLOYEE, array('Id' => $post['id'] ));
			if ($ret > 0) {
				echo "success";
				exit;
				#echo success_msg_box('User deleted successfully.');;
			}else{
				echo "error";
				exit;
				#echo error_msg_box('An error occurred while processing.');
			}
		}
	}

	public function changepassword(){
		$post = $this->input->post();
		if($post){
		$oldpass=$post['password'];	
		$newpassword=$post['newpassword'];
		$where = 'id = '.$this->user_session['id'].' and password = "'.sha1(trim($oldpass)).'"';
		$record = $this->adminmaster_model->selectData(EMPLOYEE, '*', $where);
			if(count($record)>0){
				$data=array('password'=>sha1(trim($newpassword)));
				$ret = $this->adminmaster_model->updateData(EMPLOYEE, $data, $where);
				if ($ret > 0) {
					$flash_arr = array('flash_type' => 'success',
										'flash_msg' => 'Password Change successfully.'
									);
				}else{
					$flash_arr = array('flash_type' => 'error',
										'flash_msg' => 'An error occurred while processing.'
									);
				}
				$this->session->set_userdata('msg_session',$flash_arr);
				redirect("adminmaster/changepassword");
			}
			else{
				$flash_arr = array('flash_type' => 'error',
									'flash_msg' => 'An error occurred while processing.'
								);
				$this->session->set_userdata('msg_session',$flash_arr);
				redirect("adminmaster/changepassword");
			}
		}
		$data['view'] = "changepassword";
		$this->load->view('content', $data);
	}

	public function adminprofile(){		
		$where = 'id = '.$this->user_session['id'];
		$user = $this->adminmaster_model->selectData(EMPLOYEE, '*', $where);
		$data['view'] = "adminprofile";
		$data['user'] = $user;

		$this->load->view('content', $data);
	}
}
