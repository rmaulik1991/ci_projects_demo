var oTable;
$(document).ready(function() {
    $( "#branch_name" ).change(function() {
        var branch=$('#branch_name').val();
      $('#storebranchTable').DataTable().destroy();  
	oTable = $('#storebranchTable').dataTable( {
		"processing": true,
		"serverSide": true,
		"ajax": {
			"url": base_path()+'storeproduct/ajax_list/'+branch,
			"type": "POST"
		},
		aoColumnDefs: [
		  {
			 bSortable: false,
			 aTargets: [ -1 ]
		  }
		]
    } );
	} );

	
	$('#storeFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		 fields: {
            store_name: {
                 message: 'The Store Name is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Store Name is required and cannot be empty'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The firstname can only consist of alphabetical'
                    // }
                }
            },
            branch_name: {
                 message: 'The Store Name is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Store Name is required and cannot be empty'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The firstname can only consist of alphabetical'
                    // }
                }
            },
            contact_person: {
                 message: 'The Contact Person is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Contact Person is required and cannot be empty'
                    },
                    stringLength: {
                        min: 2,
                        max: 30,
                        message: 'The Contact Person must be more than 2 and less than 30 characters long'
                    }
                    // ,regexp: {
                        // regexp: /^[a-zA-Z]+$/,
                        // message: 'The lastname can only consist of alphabetical'
                    // }
                }
            },
                       
            contact_number: {
                message: 'The contact no is not valid',
                validators: {
                    notEmpty: {
                        message: 'The contact no is required and cannot be empty'
                    },
                    stringLength: {
                        min: 10,
                        max: 10,
                        message: 'The contact no must be 10 digits'
                    },
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'The contact no can only number'
                    }
                }
            },
            status: {
                message: 'The status is not valid',
                validators: {
                    notEmpty: {
                        message: 'The status is required and cannot be empty'
                    }
                }
            }
		 }
    });
} );

function delete_storebranch(del_id) {
bootbox.confirm("Are you sure to delete branch?", function(result) {
	if(result){
	startLoading();
	$.ajax({
		type: 'post',
		url: base_path()+'storebranch/delete',
		data: 'id='+del_id,
		success: function (data) {
			if (data == "success") {
				oTable.fnClearTable(0);
				oTable.fnDraw();
				$("#flash_msg").html(success_msg_box ('Store deleted successfully.'));
			}else{
				$("#flash_msg").html(error_msg_box ('An error occurred while processing.'));
			}
			stopLoading();
		}
	});
	}
	});
}

$('#add_product').click(function(){
   var branch_id=$('#branch_name').val();
   if(branch_id!=''){
   window.location.href=base_path()+'storeproduct/assign_product/'+branch_id;
    }
    else{
        alert('Please Select branch to add product');
    }
})

function get_branch() {
    var store_id=$('#store_name').val();
    $('#branch_name')
    .find('option')
    .remove()
    .end()
    .append('<option value="">Select</option>');
    $.ajax({
        type: 'post',
        url: base_path()+'storeproduct/get_branch/'+store_id,
        success: function (data) {
            if(data['branch_list']!=''){
            var i=0;
             $.each(data['branch_list'], function(id, category_name) {
                $('#branch_name').append("<option value='" +data['branch_list'][i]['id'] + "'>" + data['branch_list'][i]['branch_name'] + "</option>");
                i++;
            });
         }
        }
    });
    
}