<section class="content-header">
    <h1>
        <?= translate('ADMIN_DASHBOARD_TITLE') ?>
    </h1>
    <?php
        $this->load->view("/template/bread_crumb");
    ?>
</section>
<section class="content">
    <div class="row">
        <div class="col-md-12">
			<div id="flash_msg" class="">
				<a href="javascript:void(0);" onclick="javascript:closemessage();" class="close-msg">X</a>
				<span id="msg_contant"></span>
			</div>
            
            <div id="list">
                <div class="row">
                        <div class="col-lg-4 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-aqua">
                                <div class="inner">
                                    <h3>
                                        <?php echo $total_emp; ?>
                                    </h3>
                                    <p>
                                        Total Employee
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-male"></i>
                                </div>
                                <a href="<?=base_url()?>adminmaster" class="small-box-footer">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div><!-- ./col -->
                        <div class="col-lg-4 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-green">
                                <div class="inner">
                                    <h3>
                                        <?php echo $total_store; ?>
                                    </h3>
                                    <p>
                                        Total Store
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-shopping-cart"></i>
                                </div>
                                <a href="<?=base_url()?>store" class="small-box-footer">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div><!-- ./col -->
                        <div class="col-lg-4 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-yellow">
                                <div class="inner">
                                    <h3>
                                        <?php echo $total_product; ?>
                                    </h3>
                                    <p>
                                        Total Product
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-list-ol"></i>
                                </div>
                                <a href="<?=base_url()?>product" class="small-box-footer">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div><!-- ./col -->
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-purple">
                                <div class="inner">
                                    <h3>
                                        <?php echo $total_branch; ?>
                                    </h3>
                                    <p>
                                        Total Branch
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-code-fork"></i>
                                </div>
                                <a href="<?=base_url()?>storebranch" class="small-box-footer">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div><!-- ./col -->
                        <div class="col-lg-4 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-light-blue">
                                <div class="inner">
                                    <h3>
                                        <?php echo $total_brands; ?>
                                    </h3>
                                    <p>
                                        Total Brands
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-dribbble"></i>
                                </div>
                                <a href="<?=base_url()?>brand" class="small-box-footer">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div><!-- ./col -->
                        <div class="col-lg-4 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-red">
                                <div class="inner">
                                    <h3>
                                        <?php echo $total_dp; ?>
                                    </h3>
                                    <p>
                                        Total Alerts
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-bell-o"></i>
                                </div>
                                <a href="<?=base_url()?>alerts" class="small-box-footer">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div><!-- ./col -->
                    </div>
			</div>

</section>




