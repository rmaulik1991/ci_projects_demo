<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Example
 *

*/

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
require APPPATH.'/libraries/REST_Controller.php';

error_reporting(E_ERROR | E_PARSE | E_NOTICE);
class Example extends REST_Controller
{
	
    
    function mydata_post()
    {

    	header('Content-Type: application/json');
        $name = $this->post('name');

        $message=$this->post('name');
        //$this->some_model->updateUser( $this->get('id') );
        //$message = array('id' => $this->get('id'), 'name' => $this->post('name'), 'email' => $this->post('email'), 'message' => 'ADDED!');

        
        
        $this->response($name, 200); // 200 being the HTTP response code
    }
    
    
    
   
}