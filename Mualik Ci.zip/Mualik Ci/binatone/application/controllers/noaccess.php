<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Noaccess extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->front_session = $this->session->userdata('front_session');
	}

	public function index()
	{
		
		$data['view'] = "index";
		$this->load->view('noaccess', $data);
	}
	
}

/* End of file noaccess.php */
/* Location: ./application/controllers/noaccess.php */
