var oTable;
$(document).ready(function() {

	
	$('#sendEmailFrm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		 fields: {
            emailSubject: {
                message: 'The Email Subject no is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Email Subject is required and cannot be empty'
                    }
                }
            },
			
			emailContent: {
                message: 'The Email contect no is not valid',
                validators: {
                    notEmpty: {
                        message: 'The Email content is required and cannot be empty'
                    }
                }
            }
		 }
    });
	
} );
